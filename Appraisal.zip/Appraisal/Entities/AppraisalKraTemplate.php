<?php

namespace Modules\Appraisal\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppraisalKraTemplate extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $fillable = ['user_id','department_id','category'];
        
    /**
     * AppraisalKraDetail
     *
     * @return void
     */
    public function AppraisalKraDetail()
    {
        return $this->hasMany(AppraisalKraTemplateDetail::class,'appraisal_kra_template_id');
    }

    protected static function newFactory()
    {
        return \Modules\Appraisal\Database\factories\AppraisalKraTemplateFactory::new();
    }
}
