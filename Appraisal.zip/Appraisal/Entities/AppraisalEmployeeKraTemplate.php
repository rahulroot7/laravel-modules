<?php

namespace Modules\Appraisal\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppraisalEmployeeKraTemplate extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = ['appraisee_id', 'appraiser_id', 'department_id', 'reviewer_id', 'category_id', 'financial_year'];

    /**
     * employeeKraDetail
     *
     * @return void
     */
    public function employeeKraDetail()
    {
        return $this->hasMany(AppraisalEmployeeKraDetail::class, 'employee_kra_template_id');
    }

    /**
     * AppraisalKraId
     *
     * @return void
     */
    public function AppraisalKraId()
    {
        return $this->hasMany(AppraisalTracker::class, 'kra_id');
    }

    protected static function newFactory()
    {
        return \Modules\Appraisal\Database\factories\AppraisalEmployeeKraTemplateFactory::new();
    }
}
