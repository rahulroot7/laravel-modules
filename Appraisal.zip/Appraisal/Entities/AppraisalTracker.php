<?php

namespace Modules\Appraisal\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppraisalTracker extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = ['user_id', 'department_id', 'appraiser_id', 'reviewer_id', 'type', 'kra_id', 'country_id', 'state_id', 'projects_assigned', 'description', 'total_weightage', 'total_weighted_score', 'total_appraiser_weightrd_score', 'final_weighted_score', 'competencies_self_total', 'competencies_appraiser_total', 'total_competencies', 'total_performance_score'];


    /**
     * employeeKraDetail
     * join with appraisal employee kra
     * @return void
     */
    public function employeeKraDetail()
    {
        return $this->hasMany(AppraisalEmployeeKra::class, 'appraisal_tracker_id');
    }

    /**
     * appraisalCompetenciesDetail
     *
     * @return void
     */
    public function appraisalCompetenciesDetail()
    {
        return $this->hasMany(AppraisalCompetencies::class, 'appraisal_tracker_id');
    }

    /**
     * appraisalTrainingDetail
     *
     * @return void
     */
    public function appraisalTrainingDetail()
    {
        return $this->hasMany(AppraisalTrainingIdentification::class, 'appraisal_tracker_id');
    }

    /**
     * commentDetail
     *
     * @return void
     */
    public function commentDetail()
    {
        return $this->hasMany(AppraisalComment::class, 'appraisal_tracker_id');
    }

    /**
     * strengthLimitationDetail
     *
     * @return void
     */
    public function strengthLimitationDetail()
    {
        return $this->hasMany(AppraisalStrengthLimitation::class, 'appraisal_tracker_id');
    }

    /**
     * strengthLImprovementDetail
     *
     * @return void
     */
    public function strengthImprovementDetail()
    {
        return $this->hasMany(AppraisalStrengthImprovement::class, 'appraisal_tracker_id');
    }

    /**
     * performanceDialogueDetail
     *
     * @return void
     */
    public function performanceDialogueDetail()
    {
        return $this->hasMany(AppraisalPerformanceDialogue::class, 'appraisal_tracker_id');
    }

    protected static function newFactory()
    {
        return \Modules\Appraisal\Database\factories\AppraisalTrackerFactory::new();
    }
}
