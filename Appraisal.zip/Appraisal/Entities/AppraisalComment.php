<?php

namespace Modules\Appraisal\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class AppraisalComment extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = ['appraisal_tracker_id'];
    
    protected static function newFactory()
    {
        return \Modules\Appraisal\Database\factories\AppraisalCommentFactory::new();
    }
}
