<?php

namespace Modules\Appraisal\Helper;

use Modules\Appraisal\Entities\AppraisalEmployeeKraTemplate;
use Modules\Appraisal\Entities\AppraisalEmployeeKraDetail;
use Illuminate\Support\Facades\Auth;
use App\Models\LeaveAuthority;
use Modules\Appraisal\Entities\AppraisalTracker;
use Modules\Appraisal\Entities\AppraisalEmployeeKra;

class Helpers
{
  #Get AppraisalEmployeeKraTemplate Data From AppraisalEmployeeKraTemplate Model
  static function getEmployeeKraTemplate()
  {
    $data = AppraisalEmployeeKraTemplate::distinct()->get(['Appraisee_id']);
    return $data;
  }


  /**
   * checkHod
   *
   * @return void
   */
  static function checkHod()
  {
    $user_id = Auth::id();
    $hodData = LeaveAuthority::where('user_id', $user_id)->where('priority', '2')->get();
    return $hodData;
  }


  /**
   * financialYear
   *
   * @return void
   */
  static function financialYear()
  {
    // Start Year
    $start_year = 2021;
    //End Year
    $end_year = date("Y");

    $all_years = range($start_year, $end_year);
    array_walk($all_years, function (&$year) {
      $year = $year . '-' . str_pad((substr($year, -2) + 1), 2, "0", STR_PAD_LEFT);
    });
    return $all_years;
  }
}
