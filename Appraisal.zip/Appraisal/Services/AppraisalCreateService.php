<?php

namespace Modules\Appraisal\Services;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Modules\Appraisal\Entities\AppraisalKraTemplateDetail;
use Modules\Appraisal\Entities\AppraisalKraTemplate;

class AppraisalCreateService
{

    /**
     * createAppresailTemplate
     *
     * @param  mixed $request
     * @return void
     */
    static function createAppresailTemplate($request)
    {
        $authUser  = Auth::user();
        $userId    = $authUser['id'];
        $kraTemplate = AppraisalKraTemplate::where('department_id', $request->department)->get();
        if ($kraTemplate->count()) {
            foreach ($kraTemplate as $kraTemplateDetail) {
                $kraCategory = $kraTemplateDetail->category;
                if ($kraCategory == $request->category) {
                    return '401';
                } else {
                    $AppraisalTemplateId = AppraisalKraTemplate::create([
                        'user_id'    =>  $userId,
                        'department_id' =>  $request->department,
                        'category'      =>  $request->category,
                    ])->id;

                    $count = count($request->name);

                    for ($i = 0; $i < $count; $i++) {
                        $task = new AppraisalKraTemplateDetail();
                        $task->appraisal_kra_template_id = $AppraisalTemplateId;
                        $task->name = $request->name[$i];
                        $task->target = $request->target[$i];
                        $task->weight = $request->weight[$i];
                        $task->save();
                    }
                    if ($task->save()) {
                        return '200';
                    } else {
                        return '400';
                    }
                }
            }
        } else {
            $AppraisalTemplateId = AppraisalKraTemplate::create([
                'user_id'    =>  $userId,
                'department_id' =>  $request->department,
                'category'      =>  $request->category,
            ])->id;

            $count = count($request->name);

            for ($i = 0; $i < $count; $i++) {
                $task = new AppraisalKraTemplateDetail();
                $task->appraisal_kra_template_id = $AppraisalTemplateId;
                $task->name = $request->name[$i];
                $task->target = $request->target[$i];
                $task->weight = $request->weight[$i];
                $task->save();
            }
            if ($task->save()) {
                return '200';
            } else {
                return '400';
            }
        }
    }

    /**
     * updateAppresailTemplate
     *
     * @param  mixed $request
     * @return void
     */
    static function updateAppresailTemplate($request, $id)
    {
        $authUser  = Auth::user();
        $userId    = $authUser['id'];
        // print_r($id);die;
        $Appraisalupdate = AppraisalKraTemplate::where('user_id', $userId)->where('id', $id)->update([
            'user_id'    =>  $userId,
            'department_id' =>  $request->department,
            'category'      =>  $request->category,
        ]);
        $KraTemplateDetail = AppraisalKraTemplateDetail::where('appraisal_kra_template_id', $id)->get();
        foreach ($KraTemplateDetail as $key => $templateDetail) {
            $templateId = $templateDetail->id;
            $Appraisalupdate = AppraisalKraTemplateDetail::where('appraisal_kra_template_id', $id)->where('id', $templateId)->update([
                'appraisal_kra_template_id' => $id,
                'name' =>  $request->uodate_name[$key],
                'target' =>  $request->update_target[$key],
                'weight' => $request->update_weight[$key],
            ]);
        }
        if (isset($request->name['0'])) {
            $count = count($request->name);
            for ($i = 0; $i < $count; $i++) {
                $task = new AppraisalKraTemplateDetail();
                $task->appraisal_kra_template_id = $id;
                $task->name = $request->name[$i];
                $task->target = $request->target[$i];
                $task->weight = $request->weight[$i];
                $task->save();
            }
        }
        if ($Appraisalupdate) {
            return '200';
        } else {
            return '400';
        }
    }
}
