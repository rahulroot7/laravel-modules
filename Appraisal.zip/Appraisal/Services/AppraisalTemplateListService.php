<?php

namespace Modules\Appraisal\Services;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Modules\Appraisal\Entities\AppraisalKraTemplateDetail;
use Modules\Appraisal\Entities\AppraisalKraTemplate;
use App\Models\Employee;
use App\Models\EmployeeProfile;
use Modules\Master\Entities\Department;
use Modules\Appraisal\Entities\AppraisalEmployeeKraTemplate;
use Modules\Appraisal\Entities\AppraisalEmployeeKraDetail;
use Modules\RolePermission\Entities\UserRole;
use Modules\RolePermission\Entities\Role;
use Modules\RolePermission\Entities\RolePermission;
use App\Models\LeaveAuthority;


class AppraisalTemplateListService
{
    /**
     * KraCategoryFilterList
     *
     * @return void
     */
    static function KraCategoryFilterList($request)
    {
        $categoryId = $request->category;
        $userId = Auth::id();
        $output = "";
        $count = 0;
        $employee = Employee::Where('user_id', $userId)->get();
        foreach ($employee as $emp) {
            $empId = $emp->id;
        }
        $emp_profile = EmployeeProfile::Where('id', $empId)->get();
        foreach ($emp_profile as $profile) {
            $departmentId = $profile->department_id;
        }
        $kraList = AppraisalKraTemplate::with('AppraisalKraDetail')
            ->where(['department_id' =>  [$departmentId]])
            ->where(['id' => [$categoryId]])
            ->get()->toArray();
        foreach ($kraList as $filterList) {
            foreach ($filterList['appraisal_kra_detail'] as $key => $kraDetail) {
                $count++;
                $output .= '<tr>' .
                    '<td>' . $count . '</td>' .
                    '<td class="align-middle">' .
                    '<input type="text" name="name[' . $key . ']" class="form-control name kra-count" value="' . $kraDetail['name'] . '" placeholder="Enter KRA Name" required>' .
                    '</td>' .
                    '<td class="align-middle">' .
                    '<input type="text" name="target[' . $key . ']" class="form-control name" value="' . $kraDetail['target'] . '" placeholder="Enter KRA Name" required>' .
                    '</td>' .
                    '<td class="align-middle">' .
                    '<input type="text" name="weight[' . $key . ']" class="form-control kra_sum" value="' . $kraDetail['weight'] . '" data-parsley-trigger="keyup" placeholder="Enater Weight" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' .
                    '</td>' .
                    '<td class="align-middle">' .
                    '<a href="javascript:void(0)" class="remove_expense">' .
                    '<i class="fa fa-minus a_r_style a_r_style_red"></i>' .
                    '</a>' .
                    '</td>' .
                    '</tr>';
            }
            $output .= '<tr>' .
                '<td class="align-middle">' .
                '<input type="hidden" name="[' . $count . ']" class="form-control name" value="' . $count . '" id="counter">' .
                '</td>' .
                '</tr>';
        }
        return $output;
    }


    /**
     * kraEmployeeFormStore
     *
     * @param  mixed $request
     * @return void
     */
    static function kraEmployeeFormStore($request, $appraisee_id)
    {
        $appraiser_id = $user_id = Auth::id();
        $appraisalTemplateDeatail = AppraisalEmployeeKraTemplate::where('appraisee_id', $request->appraisee_id)->get();
        if ($appraisalTemplateDeatail->count()) {
            foreach ($appraisalTemplateDeatail as $detail) {
                $status = $detail->financial_year;
                if ($status == $request->financial_year) {
                    return '204';
                } else {
                    $AppraisalTemplateId = AppraisalEmployeeKraTemplate::create(
                        [
                            'appraisee_id'    =>  $appraisee_id = $request->appraisee_id,
                            'appraiser_id' =>  $appraiser_id,
                            'reviewer_id' => $request->reviewer_id,
                            'department_id'      =>  $request->department,
                            'category_id'      =>  $request->category,
                            'financial_year' => $request->financial_year,
                        ]
                    )->id;

                    foreach ($request->name as $key => $kraData) {
                        $task = new AppraisalEmployeeKraDetail();
                        $task->employee_kra_template_id = $AppraisalTemplateId;
                        $task->kra = $request->name[$key];
                        $task->target = $request->target[$key];
                        $task->weightage = $request->weight[$key];
                        $task->save();
                    }
                }
            }
        } else {
            $AppraisalTemplateId = AppraisalEmployeeKraTemplate::create(
                [
                    'appraisee_id'    =>  $appraisee_id = $request->appraisee_id,
                    'appraiser_id' =>  $appraiser_id,
                    'department_id'      =>  $request->department,
                    'reviewer_id' => $request->reviewer_id,
                    'category_id'      =>  $request->category,
                    'financial_year' => $request->financial_year,
                ]
            )->id;

            foreach ($request->name as $key => $kraData) {
                $task = new AppraisalEmployeeKraDetail();
                $task->employee_kra_template_id = $AppraisalTemplateId;
                $task->kra = $request->name[$key];
                $task->target = $request->target[$key];
                $task->weightage = $request->weight[$key];
                $task->save();
            }
        }
        return '200';
    }

    /**
     * financialYearFilterList
     *
     * @param  mixed $request
     * @return void
     */
    static function financialYearFilterList($request)
    {
        $logInUserId = Auth::id();
        $financialYear = $request->financial;
        $status = $request->status;
        if (isset($financialYear) && $status == 'assign') {
            $userId = Auth::id();
            $data = AppraisalEmployeeKraTemplate::Where('appraiser_id', $userId)->where('financial_year', $financialYear)->get();
            $output = "";
            $count = 0;
            foreach ($data as $emp) {
                $userId = $emp->appraisee_id;
                $DepartmentId = $emp->department_id;
                $emp_profile = Employee::Where('user_id', $userId)->get();
                foreach ($emp_profile as $filterList) {
                    $user_id = $filterList->user_id;
                    $empId = $filterList->employee_id;
                    $name = $filterList->full_name;
                    $count++;
                    $output .= '<tr>' .
                        '<td>' . $count . '</td>' .
                        '<td class="align-middle">' . $empId . '</td>' .
                        '<td class="align-middle">' . $name . '</td>' .
                        ' <td>' .
                        '<a class="btn btn-success" href="javascript:void()">Assigned</a>' .
                        '</td>' .
                        '</tr>';
                }
            }
            // end access for reviewer

        } elseif (isset($financialYear) && $status == 'non-assign') {
            $user_id = Auth::id();
            $data = AppraisalEmployeeKraTemplate::Where('appraiser_id', $user_id)->where('financial_year', $financialYear)->get();
            $output = "";
            $count = 0;
            foreach ($data as $emp) {
                $userId[] = $emp->appraisee_id;
                $DepartmentId = $emp->department_id;
            }
            // print_r($userId);
            // $projectId = config('appraisal.projectId');
            $projectId = ['1', '2', '18', '19', '121'];
            $query = DB::table('employees as emp')
                ->join('users as u', 'emp.user_id', '=', 'u.id')
                ->join('employee_profiles as empp', 'empp.employee_id', '=', 'emp.id')
                ->where(['empp.department_id' => [$DepartmentId]])
                ->where(['empp.project_id' => [$projectId]])
                ->where(['empp.is_active' => '1']);
            $employees = $query->select('u.*', 'emp.*')
                ->orderBy('emp.created_at', 'DESC')
                ->whereNotIn('emp.user_id', $userId)
                ->get();
            // print_r($employees);
            foreach ($employees as $filterList) {
                $user_id = $filterList->user_id;
                $empId = $filterList->employee_id;
                $name = $filterList->full_name;
                $count++;
                $output .= '<tr>' .
                    '<td>' . $count . '</td>' .
                    '<td class="align-middle">' . $empId . '</td>' .
                    '<td class="align-middle">' . $name . '</td>' .
                    ' <td>' .
                    '<a class="btn btn-success" target="_blank" href="' . route('employee-kra', $user_id) . '">Assign KRA</a>' .
                    '</td>' .
                    '</tr>';
            }

            // only access for reviewer;
            $userRoleDetail = UserRole::where('user_id', $logInUserId)->get();
            foreach ($userRoleDetail as $userDetail) {
                $roleId = $userDetail->role_id;
                $roleDetail = Role::where('name', 'Reviewer')->where('id', $roleId)->get();
                foreach ($roleDetail as $roleData) {
                    $check = RolePermission::where('role_id', $roleData->id)->where('permission_id', '2')->get();
                    if ($check->count()) {
                        $hodData = LeaveAuthority::where('manager_id', $logInUserId)->where('priority', '2')->get();
                        foreach ($hodData as $key => $hodDetail) {
                            $hodUserId = $hodDetail->user_id;
                            if ($userId['0'] == $hodUserId) {
                            } else {
                                $employeeHod = Employee::Where('user_id', $hodUserId)->where('is_active', '1')->get();
                                foreach ($employeeHod as $employeeHodDetail) {
                                    $count++;
                                    $output .= '<tr>' .
                                        '<td>' . $count . '</td>' .
                                        '<td class="align-middle">' . $employeeHodDetail->employee_id . '</td>' .
                                        '<td class="align-middle">' . ucwords(
                                            $employeeHodDetail->full_name
                                        ) . '</td>' .
                                        ' <td>' .
                                        '<a class="btn btn-success" target="_blank" href="' . route('employee-kra', $employeeHodDetail->user_id) . '">Assign KRA</a>' .
                                        '</td>' .
                                        '</tr>';
                                }
                            }
                        }
                    }
                }
            }
            // end access for reviewer

        } else {
            $financialYear = $request->financial;
            $status = $request->status;
            if (isset($financialYear) && $status == 'all') {
                $assignUserId = Auth::id();
                $data = AppraisalEmployeeKraTemplate::Where('appraiser_id', $assignUserId)->where('financial_year', $financialYear)->get();
                $output = "";
                $count = 0;
                foreach ($data as $emp) {
                    $assignUserId = $emp->appraisee_id;
                    $DepartmentId = $emp->department_id;
                    $emp_profile = Employee::Where('user_id', $assignUserId)->get();
                    foreach ($emp_profile as $filterList) {
                        $user_id = $filterList->user_id;
                        $empId = $filterList->employee_id;
                        $name = $filterList->full_name;
                        $count++;
                        $output .= '<tr>' .
                            '<td>' . $count . '</td>' .
                            '<td class="align-middle">' . $empId . '</td>' .
                            '<td class="align-middle">' . $name . '</td>' .
                            ' <td>' .
                            '<a class="btn btn-success" href="javascript:void()">Assigned</a>' .
                            '</td>' .
                            '</tr>';
                    }
                }

                foreach ($data as $emp) {
                    $userId[] = $emp->appraisee_id;
                    $DepartmentId = $emp->department_id;
                }
                // print_r($userId);
                // $projectId = config('appraisal.projectId');
                $projectId = ['1', '2', '18', '19', '121'];
                $query = DB::table('employees as emp')
                    ->join('users as u', 'emp.user_id', '=', 'u.id')
                    ->join('employee_profiles as empp', 'empp.employee_id', '=', 'emp.id')
                    ->where(['empp.department_id' => [$DepartmentId]])
                    ->where(['empp.project_id' => [$projectId]])
                    ->where(['empp.is_active' => '1']);
                $employees = $query->select('u.*', 'emp.*')
                    ->orderBy('emp.created_at', 'DESC')
                    ->whereNotIn('emp.user_id', $userId)
                    ->get();
                foreach ($employees as $filterList) {
                    $user_id = $filterList->user_id;
                    $empId = $filterList->employee_id;
                    $name = $filterList->full_name;
                    $count++;
                    $output .= '<tr>' .
                        '<td>' . $count . '</td>' .
                        '<td class="align-middle">' . $empId . '</td>' .
                        '<td class="align-middle">' . $name . '</td>' .
                        ' <td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-kra', $user_id) . '">Assign KRA</a>' .
                        '</td>' .
                        '</tr>';
                }
            }
            // only access for reviewer;
            $department = Department::get();
            $userRoleDetail = UserRole::where('user_id', $logInUserId)->get();
            foreach ($userRoleDetail as $userDetail) {
                $roleId = $userDetail->role_id;
                $roleDetail = Role::where('name', 'Reviewer')->where('id', $roleId)->get();
                foreach ($roleDetail as $roleData) {
                    $check = RolePermission::where('role_id', $roleData->id)->where('permission_id', '2')->get();
                    if ($check->count()) {
                        $hodData = LeaveAuthority::where('manager_id', $logInUserId)->where('priority', '2')->get();
                        foreach ($hodData as $key => $hodDetail) {
                            $hodUserId = $hodDetail->user_id;
                            if ($userId['0'] == $hodUserId) {
                            } else {
                                $employeeHod = Employee::Where('user_id', $hodUserId)->where('is_active', '1')->get();
                                foreach ($employeeHod as $employeeHodDetail) {
                                    $count++;
                                    $output .= '<tr>' .
                                        '<td>' . $count . '</td>' .
                                        '<td class="align-middle">' . $employeeHodDetail->employee_id . '</td>' .
                                        '<td class="align-middle">' . ucwords(
                                            $employeeHodDetail->full_name
                                        ) . '</td>' .
                                        ' <td>' .
                                        '<a class="btn btn-success" target="_blank" href="' . route('employee-kra', $employeeHodDetail->user_id) . '">Assign KRA</a>' .
                                        '</td>' .
                                        '</tr>';
                                }
                            }
                        }
                    }
                }
            }
            // end access for reviewer
        }
        return $output;
    }
}
