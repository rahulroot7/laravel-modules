@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  .add_more {
    text-align: center;
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">Employee
      @foreach($employeeDetail as $empDetail)
      [ {{$empDetail->full_name}} ]
      @endforeach
    </h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Employee Kra Form</li>
    </ol>
  </div>

</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        <form method="post" action="{{ route('appraisal-kra-form.save') }}" id="pre_expense_approval_form" onsubmit="return show_messages(this)" enctype="multipart/form-data" autocomplete="off">
          @csrf
          <div class="box-body">
            <div class="row">
              <div class="col-lg-6 col-md-6">
                <div class="col-lg-4 col-md-6">
                  @foreach($reviewerDetail as $reviewer)
                  <input type="hidden" name="reviewer_id" value="{{$reviewer->user_id}}" class="form-control mb-4">
                  @endforeach
                </div>
                <div class="mb-3" id="department">
                  @foreach($employeeDetail as $empDetail)
                  <input type="hidden" class="form-control mb-4" name="appraisee_id" value="{{$empDetail->user_id}}">
                  @endforeach
                  <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                  @foreach ($department as $departmentName)
                  <input class="form-control mb-4" name="department" value="{{$departmentName['id']}}" placeholder="{{$departmentName['name']}}" readonly="" type="hidden">
                  <input class="form-control mb-4" placeholder="{{$departmentName['name']}}" readonly="" type="text">
                  @endforeach
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="mb-3">
                  <label class="fw-bold mb-0">Category <span style="color:red">*</span></label>
                  <select name="category" id="category" class="form-select form-control select2-show-search" data-parsley-errors-container="#category" data-parsley-required-message="Please Select category" required>
                    <option value="" selected disabled>Select Category</option>
                    @foreach ($kraList as $kraData)
                    <option value="{{ $kraData['id'] }}">{{ $kraData['category'] }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              @php
              $financialYear = \Modules\Appraisal\Helper\Helpers::financialYear()
              @endphp
              <div class="col-lg-6 col-md-6">
                <div class="mb-3">
                  <label class="fw-bold mb-0">Financial Year</label>
                  <select name="financial_year" id="financial_year" class="form-select form-control select2-show-search" data-parsley-errors-container="#financial_year" data-parsley-required-message="Please Select financial year" required>
                    @foreach($financialYear as $year)
                    <option value="{{$year}}" selected>{{$year}}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div class="table-responsive my-3">
            <table class="table table-bordered border text-nowrap text-md-nowrap" id="myTable">
              <thead class="bg-primary">
                <tr>
                  <th class="text-white">S. No.</th>
                  <th class="text-white">KRA Name</th>
                  <th class="text-white">Target (Has no empact on <br> calculation max-100%)</th>
                  <th class="text-white">Weightage (sum of all KRA<br> should be 100 %)</th>
                  <th class="text-white">&nbsp;</th>
                </tr>
              </thead>
              <tbody class="kra_filter-data">
              </tbody>
              <tbody id="p_a_e_t_b">
              </tbody>
              <tbody class="kra_filter_data2">

              </tbody>
              <tbody class="kra_filter-data1">

              </tbody>
            </table>
          </div>

          <div class="text-center mt-3 max-kra">

          </div>

          <div class="text-center mt-3">
            <button class="button button_onboarding" type="submit" onclick="return show_message();">Submit</button>
          </div>
      </div>
      </form>
    </div>
  </div>
</div>
</div>

<!-- /.content-wrapper ends here -->
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

<!-- Custom script starts here -->
@section('script')
<script>
  //   filter kra by category
  // filter active and In Active
  $(document).on('change', '#category', function() {
    let category = $(this).val();
    // alert(category);
    $.ajax({
      type: "GET",
      url: '{{ url("appraisal") }}/kra-filter',
      data: {
        'category': category
      },
      success: function(data) {
        // console.log(data);
        $("#p_a_e_t_b").empty();
        $(".kra_filter-data").html(data);
        $(".kra_filter-data1").html('<tr><td class="align-middle"></td><td class="align-middle"></td><td class="align-middle add_more"><a href="javascript:void(0)" class="add_kra"><i class="fa fa-plus a_r_style a_r_style_green"> Add More</i></a></td></tr>');
        $(".kra_filter_data2").html('<tr><th class="align-middle"><b>TOTAL</b></th><th class="align-middle"></th><th class="align-middle"></th><th class="align-middle"><input type="text" name="appraisee_total_weightage" id="total_kra_weightage" class="form-control name" min="100" max="100" data-parsley-validation-threshold="1" readonly=""></th></tr>');

        var totalSum = 0;
        $('.kra_sum').each(function() {
          totalSum += parseFloat(this.value);
        });
        $("#total_kra_weightage").val(totalSum);
      }
    });
  });
  // end filter category

  $(document).ready(function() {

    $("#myTable").on('input', '.kra_sum', function() {
      var calculated_total_sum = 0;
      $("#myTable .kra_sum").each(function() {
        var get_textbox_value = $(this).val();
        if ($.isNumeric(get_textbox_value)) {
          calculated_total_sum += parseFloat(get_textbox_value);
        }
      });
      $("#total_kra_weightage").val(calculated_total_sum);
    });
  });



  $(document).ready(function() {
    $('#pre_expense_approval_form').parsley();

    $(document).on('click', '.add_kra', function() {
      var countTD = $(".kra-count").length;
      if (countTD >= 15) {
        $('.max-kra').html('<p class="alert alert-danger text-center"> Maximum of 15 KRAs complete  !</p>');
      } else {
        var counter = $('#counter').val();
        let html = '<tr >' +
          '<td class="align-middle rownumber"></td>' +

          '<td class="align-middle">' +
          '<input type="text" name="name[' + counter + ']" class="form-control name kra-count" data-name="name" placeholder="Enter KRA Name" required>' +
          '</td>' +

          '<td class="align-middle">' +
          '<input type="text" name="target[' + counter + ']" class="form-control target" data-name="target" placeholder="Enter Target" min="0" max="100" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' +
          '</td>' +
          '<td class="align-middle">' +
          '<input type="text" class="form-control mb-2 weight kra_sum" name="weight[' + counter + ']" data-name="weight" data-parsley-trigger="keyup" placeholder="Enter Weight" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' +
          '</td>' +

          '<td class="align-middle">' +
          '<a href="javascript:void(0)" class="remove_expense">' +
          '<i class="fa fa-minus a_r_style a_r_style_red"></i>' +
          '</a>' +
          '</td>' +

          '</tr>';

        $('#p_a_e_t_b').append(html);

        renumberRows();
        renumberNameAttr('#p_a_e_t_b');
      }
    });

    $(document).on('click', '.remove_expense', function() {
      $(this).closest('tr').remove();
      renumberRows();
      renumberNameAttr('#p_a_e_t_b');
      // remove tr add weighted kra sum 
      var calculated_total_sum = 0;
      $("#myTable .kra_sum").each(function() {
        var get_textbox_value = $(this).val();
        if ($.isNumeric(get_textbox_value)) {
          calculated_total_sum += parseFloat(get_textbox_value);
        }
      });
      $("#total_kra_weightage").val(calculated_total_sum);
    });

    // Update Table Counters
    function renumberRows() {
      $('#p_a_e_t_b .rownumber').each(function(i) {
        var counter = $('#counter').val();
        $(this).text(i + 1 + parseInt(counter));
      });
    }

    // Renumber Name Attribute
    function renumberNameAttr(tbody) {

      var counter = $('#counter').val();
      // alert(counter);
      let count = counter;
      $(tbody).find('tr').each(function(i) {
        if (i > 0) {
          count++;
          $(this).find('input').each(function() {
            let dataNameAttrValue = $(this).attr('data-name');
            let nameAttrValue = dataNameAttrValue + '[' + count + ']';
            $(this).attr('name', nameAttrValue);
          });
        }
      });
    }

    $(document).on('input', '.input_amount', function() {
      totalRowSum($(this));
    });


  });

  // conformation form submit
  function show_messages() {
    var countTD = $(".kra-count").length;
    if (countTD < 5) {
      $('.max-kra').html('<p class="alert alert-danger text-center"> There should be a minimum of 5 KRAs !</p>');
      $('.max-kra').html('<p class="alert alert-danger text-center"> Please select category template AND There should be a minimum of 5 KRAs </p>');
      return false;
    } else {
      alert("Do you really want to submit the form?");
      return true;
    }

  }
</script>
@endsection
<!-- Custom script ends here -->

@endsection