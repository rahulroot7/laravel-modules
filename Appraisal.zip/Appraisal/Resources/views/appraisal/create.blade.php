@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  .category-exist {
    color: red;
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">Appraisal Template Form</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Appraisal Template Form</li>
    </ol>
  </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        <form method="post" action="{{ route('appraisal.save') }}" id="pre_expense_approval_form" enctype="multipart/form-data" autocomplete="off">
          @csrf
          <div class="box-body">
            <div class="row">
              <div class="col-lg-6 col-md-6">
                <div class="mb-3" id="department">
                  <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                  @foreach ($departments as $departmentName)
                  <input class="form-control mb-4" name="department" value="{{$departmentName['id']}}" placeholder="{{$departmentName['name']}}" readonly="" type="hidden">
                  <input class="form-control mb-4" placeholder="{{$departmentName['name']}}" readonly="" type="text">
                  @endforeach
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="mb-3" id="category">
                  <label class="fw-bold mb-0">Category <span style="color:red">*</span></label>
                  <input type="text" name="category" id="category" placeholder="Enter Category" class="form-control" data-parsley-required-message="Enter Category" required>
                  @if (session('CategoryExist'))
                  <p class="category-exist">{{ session('CategoryExist') }}</p>
                </div>
                @endif
              </div>
            </div>

            <div class="table-responsive my-3">
              <table class="table table-bordered border text-nowrap text-md-nowrap" id="p_a_e_t">
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">S. No.</th>
                    <th class="text-white">KRA Name</th>
                    <th class="text-white">Target (Has no impact on <br> calculation max-100%)</th>
                    <th class="text-white">Weightage (sum of all KRA<br> should be 100 %)</th>
                    <th class="text-white">&nbsp;</th>
                  </tr>
                </thead>
                <tbody id="p_a_e_t_b">

                  <tr>
                    <td class="align-middle rownumber">1</td>
                    <td class="align-middle">
                      <input type="text" name="name[0]" class="form-control name" placeholder="Enter KRA Name" required>
                    </td>
                    <td class="align-middle">
                      <input type="text" name="target[0]" class="form-control target" placeholder="Enter Target" min="0" max="100" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>
                    </td>

                    <td class="align-middle">
                      <input type="text" class="form-control mb-2 weight" name="weight[0]" data-parsley-trigger="keyup" placeholder="Enter Weightage" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>
                    </td>

                    <td class="align-middle">
                      <a href="javascript:void(0)" id="add_expense">
                        <i class="fa fa-plus a_r_style a_r_style_green"></i>
                      </a>
                    </td>
                  </tr>

                </tbody>
              </table>
            </div>

            <div class="text-center mt-3">
              <button class="button button_onboarding" type="submit">Submit</button>
            </div>
          </div>
        </form>
      </div>

      <div class="card-body">
        <table class="table table-bordered table-striped table-hover data-table">
          <thead class="bg-primary">
            <tr>
              <th class="fw-bold text-white">S.No.</th>
              <th class="fw-bold text-white">Category Name</th>
              <th class="fw-bold text-white">Action</th>
            </tr>
          </thead>
          <tbody class="employee-list-data">
            @foreach ($appraisalKraDetail as $templateKraDetail)
            <tr>
              <td>{{ @$loop->iteration }}</td>
              <td>{{ $templateKraDetail->category }}</td>
              <td>
                <a class="btn btn-sm btn-primary" target="blank" href="{{ route('template.edit',$templateKraDetail->id) }}"><i class="fa fa-edit"></i> Edit</a>
                <a class="btn btn-sm btn-secondary" target="blank" href="{{ route('template.view',$templateKraDetail->id) }}"><i class="fa fa-info-circle"></i> View</a>
              </td>
            </tr>
            @endforeach
          </tbody>
          <tbody class="employee-filter-data">
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- /.content-wrapper ends here -->
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

<!-- Custom script starts here -->
@section('script')
<script>
  $(document).ready(function() {
    $('#pre_expense_approval_form').parsley();

    $('#add_expense').on('click', function() {
      let html = '<tr >' +
        '<td class="align-middle rownumber"></td>' +

        '<td class="align-middle">' +
        '<input type="text" name="name[]" class="form-control name" data-name="name" placeholder="Enter KRA Name" required>' +
        '</td>' +

        '<td class="align-middle">' +
        '<input type="text" name="target[]" class="form-control target" data-name="target" placeholder="Enter Target" min="0" max="100" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' +
        '</td>' +
        '<td class="align-middle">' +
        '<input type="text" class="form-control mb-2 weight" name="weight[]" data-name="weight" data-parsley-trigger="keyup" placeholder="Enter Weight" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' +
        '</td>' +

        '<td class="align-middle">' +
        '<a href="javascript:void(0)" class="remove_expense">' +
        '<i class="fa fa-minus a_r_style a_r_style_red"></i>' +
        '</a>' +
        '</td>' +

        '</tr>';

      $('#p_a_e_t_b').append(html);

      renumberRows();
      renumberNameAttr('#p_a_e_t_b');
    });

    $(document).on('click', '.remove_expense', function() {
      $(this).closest('tr').remove();
      renumberRows();
      renumberNameAttr('#p_a_e_t_b');
    });
    // Update Table Counters
    function renumberRows() {
      $('#p_a_e_t_b .rownumber').each(function(i) {
        $(this).text(i + 1);
      });
    }

    // Renumber Name Attribute
    function renumberNameAttr(tbody) {
      let count = 0;
      $(tbody).find('tr').each(function(i) {
        if (i > 0) {
          count++;
          $(this).find('input').each(function() {
            let dataNameAttrValue = $(this).attr('data-name');
            let nameAttrValue = dataNameAttrValue + '[' + count + ']';
            $(this).attr('name', nameAttrValue);
          });
        }
      });
    }

    $(document).on('input', '.input_amount', function() {
      totalRowSum($(this));
    });


  });

  // datatable 
  $(".data-table").DataTable({
    "columnDefs": [{
      orderable: false,
    }],
  });
</script>
@endsection
<!-- Custom script ends here -->

@endsection