@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  .category-exist {
    color: red;
  }

  .add_more {
    text-align: center;
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">Appraisal Template Form Edit</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Appraisal Template Form Edit</li>
    </ol>
  </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        @foreach($appraisalKraDetail as $appraisalKraData)
        <form method="post" action="{{ route('template.update',$appraisalKraData->id) }}" id="pre_expense_approval_form" enctype="multipart/form-data">
          @csrf
          @endforeach
          <div class="box-body">
            <div class="row">
              <div class="col-lg-6 col-md-6">
                <div class="mb-3" id="department">
                  <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                  @foreach ($departments as $departmentName)
                  <input class="form-control mb-4" name="department" value="{{$departmentName['id']}}" placeholder="{{$departmentName['name']}}" readonly="" type="hidden">
                  <input class="form-control mb-4" placeholder="{{$departmentName['name']}}" readonly="" type="text">
                  @endforeach
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="mb-3" id="category">
                  @foreach ($appraisalKraDetail as $appraisalKraData)
                  <label class="fw-bold mb-0">Category <span style="color:red">*</span></label>
                  <input type="hidden" name="category_id" value="{{$appraisalKraData->id}}" id="category" class="form-control" readonly="">
                  <input type="text" name="category" value="{{$appraisalKraData->category}}" id="category" class="form-control" readonly="">
                  @endforeach
                </div>
              </div>
            </div>

            <div class="table-responsive my-3">
              <table class="table table-bordered border text-nowrap text-md-nowrap" id="p_a_e_t">
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">S. No.</th>
                    <th class="text-white">KRA Name</th>
                    <th class="text-white">Target (Has no impact on <br> calculation max-100%)</th>
                    <th class="text-white">Weightage (sum of all KRA<br> should be 100 %)</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $count = 0;
                  ?>
                  @foreach($appraisalKraDetail as $appraisalKraData)
                  @foreach($appraisalKraData->AppraisalKraDetail as $key => $KraData)
                  <?php $count++; ?>
                  <tr>
                    <td class="align-middle rownumber">{{ $count }}</td>
                    <td class="align-middle">
                      <input type="text" name="uodate_name[{{$key}}]" value="{{$KraData->name}}" class="form-control name" placeholder="Enter KRA Name" required>
                    </td>
                    <td class="align-middle">
                      <input type="text" name="update_target[{{$key}}]" value="{{$KraData->target}}" class="form-control target" placeholder="Enter Target" min="0" max="100" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>
                    </td>

                    <td class="align-middle">
                      <input type="text" name="update_weight[{{$key}}]" class="form-control mb-2 weight" value="{{$KraData->weight}}" data-parsley-trigger="keyup" placeholder="Enater Weightage" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>
                    </td>
                  </tr>
                  @endforeach
                  @endforeach
                </tbody>
                <tbody id="add-extra-kra">

                  <tr>
                    <td class="align-middle rownumber">{{$count+1}}</td>
                    <td class="align-middle">
                      <input type="text" name="name[0]" class="form-control name" placeholder="Enter KRA Name">
                    </td>
                    <td class="align-middle">
                      <input type="text" name="target[0]" class="form-control target" placeholder="Enter Target" min="0" max="100" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number">
                    </td>

                    <td class="align-middle">
                      <input type="text" name="weight[0]" class="form-control mb-2 weight" data-parsley-trigger="keyup" placeholder="Enter Weightage" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number">
                    </td>

                    <td class="align-middle">
                      <a href="javascript:void(0)" id="add_expense">
                        <i class="fa fa-plus a_r_style a_r_style_green"></i>
                      </a>
                    </td>
                  </tr>

                </tbody>
              </table>
            </div>

            <div class="text-center mt-3">
              <button class="button button_onboarding" type="submit">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- /.content-wrapper ends here -->
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

<!-- Custom script starts here -->
@section('script')
<script>
  $(document).ready(function() {
    $('#pre_expense_approval_form').parsley();
    var counter = '<?php echo $count; ?>';
    $('#add_expense').on('click', function() {
      let html = '<tr >' +
        '<td class="align-middle rownumber"></td>' +

        '<td class="align-middle">' +
        '<input type="text" name="name[]" class="form-control name" data-name="name" placeholder="Enter KRA Name" required>' +
        '</td>' +

        '<td class="align-middle">' +
        '<input type="text" name="target[]" class="form-control target" data-name="target" placeholder="Enter Target" min="0" max="100" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' +
        '</td>' +
        '<td class="align-middle">' +
        '<input type="text" class="form-control mb-2 weight" name="weight[]" data-name="weight" data-parsley-trigger="keyup" placeholder="Enter Weight" min="10" max="30" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" required>' +
        '</td>' +

        '<td class="align-middle">' +
        '<a href="javascript:void(0)" class="remove_expense">' +
        '<i class="fa fa-minus a_r_style a_r_style_red"></i>' +
        '</a>' +
        '</td>' +

        '</tr>';

      $('#add-extra-kra').append(html);

      renumberRows();
      renumberNameAttr('#add-extra-kra');
    });

    $(document).on('click', '.remove_expense', function() {
      $(this).closest('tr').remove();
      renumberRows();
      renumberNameAttr('#add-extra-kra');
    });
    // Update Table Counters
    function renumberRows() {
      $('#add-extra-kra .rownumber').each(function(i) {
        $(this).text(i + 1 + parseInt(counter));
      });
    }

    // Renumber Name Attribute
    function renumberNameAttr(tbody) {
      let count = counter;
      $(tbody).find('tr').each(function(i) {
        if (i > 0) {
          count++;
          $(this).find('input').each(function() {
            let dataNameAttrValue = $(this).attr('data-name');
            let nameAttrValue = dataNameAttrValue + '[' + count + ']';
            $(this).attr('name', nameAttrValue);
          });
        }
      });
    }

    $(document).on('input', '.input_amount', function() {
      totalRowSum($(this));
    });


  });
</script>
@endsection
<!-- Custom script ends here -->

@endsection