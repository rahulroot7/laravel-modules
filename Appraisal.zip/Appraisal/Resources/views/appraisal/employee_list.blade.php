@extends('layouts.app')

@section('style')

@endsection
@push('style-scripts')

@endpush
@section('content')
<div class="page-header">
    <div>
        <h1 class="page-title">Employee List</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Employee List</li>
        </ol>
    </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="box-body">
                    <div class="row">
                        @php
                        $financialYear = \Modules\Appraisal\Helper\Helpers::financialYear()
                        @endphp
                        <div class="col-lg-6 col-md-6">
                            <div class="mb-3" id="department">
                                <label class="fw-bold mb-0">Financial Year</label>
                                <select name="financial" id="financial" class="form-select form-control select2-show-search" data-parsley-errors-container="#financial" data-parsley-required-message="Please Select financial" required>
                                    @foreach($financialYear as $year)
                                    <option value="{{$year}}" selected>{{$year}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="mb-3">
                                <label class="fw-bold mb-0">KRA Status <span style="color:red">*</span></label>
                                <select name="status" id="status" class="form-select form-control select2-show-search" data-parsley-errors-container="#status" data-parsley-required-message="Please Select status" required>
                                    <option value="all" selected>All</option>
                                    <option value="assign">Assigned</option>
                                    <option value="non-assign">Un-Assign</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive my-3">
                    <table id="dtTable" class="table table-bordered table-striped table-hover data-employee">
                        <thead class="bg-primary">
                            <tr>
                                <th class="fw-bold text-white">S.No.</th>
                                <th class="fw-bold text-white">Employee Code</th>
                                <th class="fw-bold text-white">Name</th>
                                <th class="fw-bold text-white">Action</th>
                            </tr>
                        </thead>
                        <tbody class="employee-list-data">
                            @if(empty($output))
                            @php
                            $count = '1';
                            @endphp
                            @if(!empty($employeeHod))
                            @foreach ($employeeHod as $key => $employeeHodDetail)
                            @php
                            $count++;
                            @endphp
                            <tr>
                                <td>{{ @$loop->iteration }}</td>
                                <td>{{ $employeeHodDetail['0']['employee_id']}}</td>
                                <td>{{ $employeeHodDetail['0']['full_name'] }}</td>
                                <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-kra',$employeeHodDetail['0']['user_id']) }}">Assign KRA</a>
                                </td>
                            </tr>
                            @endforeach
                            @foreach ($employees as $employee)
                            <tr>
                                <td>{{$count++}}</td>
                                <td>{{ $employee->employee_code }}</td>
                                <td>{{ $employee->full_name }}</td>
                                <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-kra',$employee->user_id) }}">Assign KRA</a>
                                </td>
                            </tr>
                            @endforeach
                            @else
                            @foreach ($employees as $employee)
                            <tr>
                                <td>{{$count++}}</td>
                                <td>{{ $employee->employee_code }}</td>
                                <td>{{ $employee->full_name }}</td>
                                <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-kra',$employee->user_id) }}">Assign KRA</a>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                            @else
                            <?php echo $output; ?>
                            @endif
                        </tbody>
                        <tbody class="filter-data">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>
@section('script')

@endsection
@push('js-scripts')
<script>
    // filter financial year
    $(document).on('change', '#financial,#status', function() {
        let financialYear = $('#financial').val();
        let status = $('#status').val();
        $(".employee-list-data").remove();
        $('#dtTable').DataTable().destroy();
        $.ajax({
            type: "GET",
            url: '{{ url("appraisal") }}/financial-year',
            data: {
                'financial': financialYear,
                'status': status
            },
            success: function(data) {
                $('.filter-data').html(data);
                $("#dtTable").DataTable({
                    "columnDefs": [{
                        orderable: false,
                    }],
                });
            }
        });
    });
    // end filter Financial year


    // datatable 
    $("#dtTable").DataTable({
        "columnDefs": [{
            orderable: false,
        }],
    });
</script>
@endpush