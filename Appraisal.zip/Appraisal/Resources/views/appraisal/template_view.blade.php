@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  .category-exist {
    color: red;
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">Appraisal Template Form</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Appraisal Template Form</li>
    </ol>
  </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        <form method="post" action="{{ route('appraisal.save') }}" id="pre_expense_approval_form" enctype="multipart/form-data">
          @csrf
          <div class="box-body">
            <div class="row">
              <div class="col-lg-6 col-md-6">
                <div class="mb-3" id="department">
                  <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                  <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                  @foreach ($departments as $departmentName)
                  <input class="form-control mb-4" name="department" value="{{$departmentName['id']}}" placeholder="{{$departmentName['name']}}" readonly="" type="hidden">
                  <input class="form-control mb-4" placeholder="{{$departmentName['name']}}" readonly="" type="text">
                  @endforeach
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
                <div class="mb-3" id="category">
                  @foreach ($appraisalKraDetail as $appraisalKraData)
                  <label class="fw-bold mb-0">Category <span style="color:red">*</span></label>
                  <input type="text" name="category" value="{{$appraisalKraData->category}}" id="category" class="form-control" readonly="">
                  @endforeach
                </div>
              </div>

              <div class="table-responsive my-3">
                <table class="table table-bordered border text-nowrap text-md-nowrap" id="p_a_e_t">
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">S. No.</th>
                      <th class="text-white">KRA Name</th>
                      <th class="text-white">Target (Has no empact on <br> calculation max-100%)</th>
                      <th class="text-white">Weightage (sum of all KRA<br> should be 100 %)</th>
                    </tr>
                  </thead>
                  <tbody id="p_a_e_t_b">
                    @foreach($appraisalKraDetail as $appraisalKraData)
                    @foreach($appraisalKraData->AppraisalKraDetail as $key => $KraData)
                    <tr>
                      <td class="align-middle rownumber">{{ @$loop->iteration }}</td>
                      <td class="align-middle">
                        <input type="text" name="name[{{$key}}]" class="form-control name" value="{{$KraData->name}}" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="target[{{$key}}]" class="form-control target" value="{{$KraData->target}}" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" class="form-control mb-2 weight" name="weight[{{$key}}]" value="{{$KraData->weight}}" data-parsley-trigger="keyup" readonly="">
                      </td>
                    </tr>
                    @endforeach
                    @endforeach

                  </tbody>
                </table>
              </div>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- /.content-wrapper ends here -->
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

<!-- Custom script starts here -->
@section('script')
<script>
</script>
@endsection
<!-- Custom script ends here -->

@endsection