@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  th.text-white.text-size {
    font-size: 12px;
  }

  .bg-text {
    background-color: #bfbfbf69;
    padding: 3px;
    text-align: center
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">APPRAISAL KRA FORM</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Appraisal Kra Form</li>
    </ol>
  </div>
  <div class="ms-auto pageheader-btn">
    <button class="btn btn-info mt-3" data-bs-toggle="modal" data-bs-target="#largemodal">Rating Detail</button>
  </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        <form method="post" action="{{ route('appraisal-employee-form.update') }}" id="pre_expense_approval_form" enctype="multipart/form-data" autocomplete="off">
          @csrf
          <div class="box-body">
            <div class="row">
              <div class="row">
                <input type="hidden" name="type" value="2" class="form-control mb-4">
                @foreach($employeeDetail as $empDetail)
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3" id="name">
                    <label class="fw-bold mb-0">Name <span style="color:red">*</span></label>
                    <input type="text" name="name" class="form-control mb-4" value="{{$empDetail->full_name}}" readonly="">
                  </div>
                </div>
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3" id="employee_id">
                    <label class="fw-bold mb-0">Employee ID <span style="color:red">*</span></label>
                    <input type="hidden" name="employee_id" value="{{$empDetail->user_id}}" class="form-control mb-4" readonly="">
                    <input type="text" placeholder="{{$empDetail->employee_id}}" class="form-control mb-4" readonly="">
                  </div>
                </div>
                <div class="col-lg-4 col-md-6">
                  @foreach($department as $departmentDetail)
                  <div class="mb-3" id="department_id">
                    <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                    <input type="hidden" name="department_id" value="{{$departmentDetail->id}}" class="form-control mb-4" readonly="">
                    <input type="text" placeholder="{{$departmentDetail->name}}" class="form-control mb-4" readonly="">
                  </div>
                  @endforeach
                </div>
              </div>
              <div class="row">
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3">
                    @foreach($country as $countryDetail)
                    <label class="fw-bold mb-0">Country <span style="color:red">*</span></label>
                    <input type="hidden" name="country_id" value="{{$countryDetail->id}}" class="form-control mb-4" readonly="">
                    <input type="text" placeholder="{{$countryDetail->name}}" class="form-control mb-4" readonly="">
                    @endforeach
                  </div>
                </div>
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3">
                    @foreach($state as $address)
                    <label class="fw-bold mb-0">State <span style="color:red">*</span></label>
                    <input type="hidden" name="state_id" value="{{$address->id}}" class="form-control mb-4">
                    <input type="text" placeholder="{{$address->name}}" class="form-control mb-4" readonly="">
                    @endforeach
                  </div>
                </div>

                <div class="col-lg-4 col-md-6">
                  <div class="mb-3">
                    @foreach($appraisalKra as $kraData)
                    <label class="fw-bold mb-0">Projects assigned</label>
                    <input type="hidden" name="kra_id" value="{{$kraData['kra_id']}}" class="form-control mb-4">
                    <input type="text" name="projects_assigned" value="{{$kraData['projects_assigned']}}" class="form-control mb-4">
                    @endforeach
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-4 col-md-6">
                  @foreach($appraiser as $appraiserDetail)
                  <div class="mb-3" id="appraiser :">
                    <label class="fw-bold mb-0">Name Of Appraiser <span style="color:red">*</span></label>
                    <input type="hidden" name="appraiser_id" value="{{$appraiserDetail->id}}" class="form-control mb-4">
                    <input type="text" placeholder="{{$appraiserDetail->full_name}}" class="form-control mb-4" readonly="">
                  </div>
                  @endforeach
                </div>
                <div class="col-lg-4 col-md-6">
                  @foreach($reviewerDetail as $reviewer)
                  <div class="mb-3" id="reviewer">
                    <label class="fw-bold mb-0">Name Of Reviewer <span style="color:red">*</span></label>
                    <input type="hidden" name="reviewer_id" value="{{$reviewer->user_id}}" class="form-control mb-4">
                    <input type="text" placeholder="{{$reviewer->full_name}}" class="form-control mb-4" readonly="">
                  </div>
                  @endforeach
                </div>
              </div>
              @endforeach
              <div class="table-responsive my-3">
                <table class="table table-bordered border text-nowrap text-md-nowrap" id="myTable">
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white text-size">KEY RESULT AREAS<br>(Performance <br>Objectives)*</th>
                      <th class="text-white text-size">Target (%)</th>
                      <th class="text-white text-size">weightage (%) </th>
                      <th class="text-white text-size">Achievement<br>(To be<br>filled <br>Appraisee)</th>
                      <th class="text-white text-size">Score<br>by<br>Appraisee (1-5)</th>
                      <th class="text-white text-size">Weighted<br>Score</th>
                      <th class="text-white text-size">Remarks by<br>Appraiser</th>
                      <th class="text-white text-size">Score<br>by<br>Appraiser<br>(1-5)</th>
                      <th class="text-white text-size">Appraiser<br>Weighted<br>Score</th>
                    </tr>
                    <tr>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $TotalWeatage = 0; ?>
                    @foreach($appraisalKra as $kraData)
                    @foreach($kraData['employee_kra_detail'] as $key => $kradetail)
                    <tr>
                      <td class="align-middle">
                        <input type="text" name="kra[{{$key}}]" value="{{$kradetail['kra']}}" class="form-control name" data-name="kra" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="target[{{$key}}]" value="{{$kradetail['target']}}" class="form-control name" data-name="target" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="weightage[{{$key}}]" value="{{$kradetail['weightage']}}" class="form-control weightage" data-name="weightage" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="achievement[{{$key}}]" value="{{$kradetail['achievement']}}" class="form-control name" data-name="achievement" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="score_by_appraisee[{{$key}}]" value="{{$kradetail['score_by_appraisee']}}" class="form-control" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="score_by_appraisee" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="weighted_score[{{$key}}]" value="{{$kradetail['weighted_score']}}" class="form-control" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="weighted_score" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="remark[{{$key}}]" value="{{$kradetail['remark']}}" class="form-control name" placeholder="Remark" data-name="remark" required>
                      </td>
                      <td class="align-middle">
                        <!-- <input type="text" name="score_by_appraiser[{{$key}}]" value="{{$kradetail['score_by_appraiser']}}" class="form-control weighted_score score_appraiser" min="0" max="5" data-name="score_by_appraiser" required> -->
                        <select name="score_by_appraiser[{{$key}}]" class="form-control weighted_score score_appraiser" data-parsley-required-message="Please Select appraiser" required>
                          <option value="{{$kradetail['score_by_appraiser']}}">{{$kradetail['score_by_appraiser']}}</option>
                          <option value="5">5</option>
                          <option value="4.5">4.5</option>
                          <option value="4">4</option>
                          <option value="3.5">3.5</option>
                          <option value="3">3</option>
                          <option value="2.5">2.5</option>
                          <option value="2">2</option>
                          <option value="1.5">1.5</option>
                          <option value="1">1</option>
                        </select>
                      </td>
                      <td class="align-middle">
                        <input type="text" name="appraiser_weighted_score[{{$key}}]" value="{{$kradetail['appraiser_weighted_score']}}" class="form-control total_appraiser_score total" data-name="appraiser_weighted_score" required>
                      </td>

                    </tr>
                    <?php
                    $TotalWeatage += $kradetail['weightage'];
                    ?>
                    @endforeach
                    <tr>
                      <th class="align-middle">
                        <b>TOTAL</b>
                      </th>
                      <th class="align-middle">
                        <b></b>
                      </th>
                      <th class="align-middle">
                        <input type="text" name="total_weightage" value="{{$TotalWeatage}}" class="form-control" readonly="">
                      </th>
                      <th class="align-middle">
                        <b></b>
                      </th>
                      <th class="align-middle">
                        <b></b>
                      </th>
                      <!-- score and weightage for appraiseee -->
                      <th class="align-middle">
                        <input type="text" name="appraisee_total_weightage" value="{{$kraData['total_weighted_score']}}" id="total_sum_value" class="form-control name" min="0" max="5" data-parsley-validation-threshold="1" readonly="">
                      </th>
                      <th class="align-middle">
                        <b></b>
                      </th>
                      <!-- score and weightage for appraiser -->
                      <th class="align-middle">
                        <b></b>
                      </th>
                      <th class="align-middle">
                        <input type="text" name="appraiser_total_weightage" value="{{$kraData['total_appraiser_weighted_score']}}" id="total_appraiser_value" class="form-control name" min="0" max="5" data-parsley-validation-threshold="1" readonly="">
                      </th>
                    <tr>
                  </tbody>
                </table>
                <!-- Appraisal Comment  -->
                <table class="table table-bordered border text-nowrap text-md-nowrap">
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">Appraisee's Comment</th>
                      <th class="text-white">Appraiser Comment</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($kraData['comment_detail'] as $key => $comment)
                    <tr>
                      <td class="align-middle">
                        <textarea class="form-control" cols="30" rows="3" readonly="">{{$comment['comment']}}</textarea>
                      </td>
                      <td class="align-middle">
                        <textarea name="appraiser_comment" id="appraiser_comment" class="form-control" cols="30" rows="3" placeholder="Please enter the comment about appraisal form.">{{$comment['appraiser_comment']}}</textarea>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
                <!-- end apprasal comment -->
                <!-- Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS  -->
                <table class="table table-bordered border text-nowrap text-md-nowrap">
                  <h3 class="bg-text">Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS</h3>
                  <p class="bg-text">Describe the important factors (personal, organisational, external) affecting your performance.</p>
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">FACILITATING</th>
                      <th class="text-white">HINDERING</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($kraData['strength_limitation_detail'] as $key => $limitation)
                    <tr>
                      <td class="align-middle">
                        <input type="text" value="{{$limitation['facilitating']}}" class="form-control" data-name="factors" readonly>
                      </td>
                      <td class="align-middle">
                        <input type="text" value="{{$limitation['hindering']}}" class="form-control" data-name="factors" readonly>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
                <!-- end Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS -->

                <!-- Section 2: COMPETENCIES REVIEW  -->
                <table class="table table-bordered border text-nowrap text-md-nowrap" id="section_appraiser">
                  <h3 class="bg-text">Section 2: COMPETENCIES REVIEW</h3>
                  <p class="bg-text">Employee is to be assessed on a 5 point scale with 5 as "highest" and 1 as "lowest". Please note that 6 Factors are mentioned below, the other 4 factors may be chosen from grid in Section 6 depending on appraisee's designation</p>
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">S.No.</th>
                      <th class="text-white">PERSONAL EFFECTIVENESS FACTORS <br>(There should be <br>total 10 factors mandatory)</th>
                      <th class="text-white">Self (1-5)</th>
                      <th class="text-white">Appraiser (1-5)</th>
                    </tr>
                  </thead>
                  <tbody id="section_3">
                    @foreach($kraData['appraisal_competencies_detail'] as $key => $competencies)
                    <tr>
                      <td class="align-middle">{{ @$loop->iteration }}</td>
                      <td class="align-middle">
                        <input type="text" name="factors[{{$key}}]" value="{{$competencies['factors']}}" class="form-control" data-name="factors" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="self[{{$key}}]" value="{{$competencies['self']}}" class="form-control self_score" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="self" readonly="">
                      </td>
                      <td class="align-middle">
                        <!-- <input type="text" name="appraiser[{{$key}}]" value="{{$competencies['appraiser']}}" class="form-control appraiser_score" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="self" required> -->
                        <select name="appraiser[{{$key}}]" class="form-control appraiser_score" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="self" required>
                          <option value="{{$competencies['appraiser']}}">{{$competencies['appraiser']}}</option>
                          <option value="5">5</option>
                          <option value="4.5">4.5</option>
                          <option value="4">4</option>
                          <option value="3.5">3.5</option>
                          <option value="3">3</option>
                          <option value="2.5">2.5</option>
                          <option value="2">2</option>
                          <option value="1.5">1.5</option>
                          <option value="1">1</option>
                        </select>
                      </td>
                      <!-- <td class="align-middle">
                        <a href="javascript:void(0)" id="add_section_3">
                          <i class="fa fa-plus a_r_style a_r_style_green"></i>
                        </a>
                      </td>                                   -->
                    </tr>
                    @endforeach
                  </tbody>
                  <tr>
                    <th class="align-middle">
                      <b>TOTAL</b>
                    </th>
                    <th class="align-middle">
                      <b></b>
                    </th>
                    <th class="align-middle">
                      <input type="text" name="total_self" id="total_self" value="{{$kraData['competencies_self_total']}}" class="form-control" readonly="">
                    </th>
                    </th>
                    <th class="align-middle">
                      <input type="text" name="total_appraiser" id="total_appraiser" value="{{$kraData['competencies_appraiser_total']}}" class="form-control" readonly="">
                    </th>
                  </tr>
                </table>
                <!-- end Section 2: COMPETENCIES REVIEW -->
                <!-- Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS  -->
                <table class="table table-bordered border text-nowrap text-md-nowrap">
                  <h3 class="bg-text">Section 3: AREAS OF IMPROVEMENT</h3>
                  <p class="bg-text"> SPECIFIC STRENGTHS / AREAS OF IMPROVEMENT OF THE EMPLOYEE AFFECTING HIS/HER PERFORMANCE
                    (To be filled by appraiser)</p>
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">AREA OF STRENGTH</th>
                      <th class="text-white">AREA OF IMPROVEMENT<br>(If the above score is less than 3)</th>
                    </tr>
                  </thead>
                  <tbody>
                    @if(!empty($kraData['strength_improvement_detail']))
                    @foreach($kraData['strength_improvement_detail'] as $key => $strengthDetail)
                    <tr>
                      <td class="align-middle">
                        <input type="text" name="area_strength[{{$key}}]" value="{{$strengthDetail['area_of_strength']}}" placeholder="Enter Strength" class="form-control" data-name="area_strength" required>
                      </td>
                      <td class="align-middle">
                        <input type="text" name="area_improvement[{{$key}}]" value="{{$strengthDetail['area_of_improvement']}}" placeholder="Enter Improvement" class="form-control" data-name="area_improvement" required>
                      </td>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                      <td class="align-middle">
                        <input type="text" name="area_strength[0]" placeholder="Enter Strength" class="form-control" data-name="area_strength" required><br>
                        <input type="text" placeholder="Enter Strength" name="area_strength[1]" class="form-control" data-name="area_strength" required><br>
                        <input type="text" name="area_strength[2]" placeholder="Enter Strength" class="form-control" data-name="area_strength" required><br>
                      </td>
                      <td class="align-middle">
                        <input type="text" name="area_improvement[0]" placeholder="Enter Improvement" class="form-control" data-name="area_improvement" required><br>
                        <input type="text" name="area_improvement[1]" placeholder="Enter Improvement" class="form-control" data-name="area_improvement" required><br>
                        <input type="text" name="area_improvement[2]" placeholder="Enter Improvement" class="form-control" data-name="area_improvement" required><br>
                      </td>
                    </tr>
                    @endif
                  </tbody>
                </table>
                <!-- end Section 3: ANALYSIS OF STRENGTHS AND LIMITATIONS -->

                <!-- Section 4: Section 5 : PERFORMANCE DIALOGUE  -->
                <table class="table table-bordered border text-nowrap text-md-nowrap">
                  <h3 class="bg-text">Section 4 : PERFORMANCE DIALOGUE</h3>
                  <p class="bg-text"> Appraiser's comments on the appraisal discussion held with the Appraisee</p>
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">Appraiser's comments</th>
                      <th class="text-white">Appraisee Name & Signature</th>
                      <th class="text-white">Appraiser Name & Signature</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      @if($dialogue->count())
                      @foreach($dialogue as $key => $dialogueDetail)
                      <td class="align-middle">
                        <textarea name="performance_appraiser_comment" id="performance_appraiser_comment" class="form-control" cols="30" rows="5" placeholder="Please enter comments on the appraisal discussion held with the Appraisee">{{$dialogueDetail->comment}}</textarea>
                      </td>
                      @endforeach
                      @else
                      <td class="align-middle">
                        <textarea name="performance_appraiser_comment" id="performance_appraiser_comment" class="form-control" cols="30" rows="5" placeholder="Please enter comments on the appraisal discussion held with the Appraisee"></textarea>
                      </td>
                      @endif
                      @foreach($employeeDetail as $empDetail)
                      <td class="align-middle">
                        <textarea name="performance_appraisee_comment" id="appraiser_comment" class="form-control" cols="30" rows="5" placeholder="Please enter the comment about appraisal form." readonly="">{{$empDetail->full_name}}</textarea>
                      </td>
                      @endforeach
                      @foreach($appraiser as $appraiserDetail)
                      <td class="align-middle">
                        <input type="hidden" name="performance_appraiser_sign" value="Appraiser">
                        <textarea id="performance_appraiser_sign" class="form-control" cols="30" rows="5" placeholder="Please enter appraiser name" readonly="">{{$appraiserDetail->full_name}}</textarea>
                      </td>
                      @endforeach
                    </tr>
                  </tbody>
                </table>
                <!-- end Section 4: PERFORMANCE DIALOGUE -->

                <!-- Section 5: TRAINING NEEDS IDENTIFICATION  -->
                <table class="table table-bordered border text-nowrap text-md-nowrap">
                  <h3 class="bg-text">Section 5: TRAINING NEEDS IDENTIFICATION</h3>
                  <h5 class="bg-text">TO BE FILLED BY THE APPRAISER / HEAD OF THE DEPARTMENT</h5>
                  <p class="bg-text"> Indicate specific needs for development, recommend training programmes and prioritize.</p>
                  <thead class="bg-primary">
                    <tr>
                      <th class="text-white">AREAS OF TRAINING<br>(Please refer to Training Program<br>List for Specific Trainings)</th>
                      <th class="text-white">SUGGESTED BY APPRAISEE</th>
                      <th class="text-white">RECOMMENDED BY APPRAISER</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($kraData['appraisal_training_detail'] as $key => $trainingDetail)
                    <tr>
                      <td class="align-middle">
                        <input type="text" name="Job[{{$key}}]" value="{{$trainingDetail['traning_type']}}" class="form-control" readonly="">
                      </td>
                      <td class="align-middle">
                        <input type="text" name="appraisee_Job_function[{{$key}}]" value="{{$trainingDetail['suggested_by_appraisee']}}" class="form-control" readonly="">
                      </td>
                      @if(empty($trainingDetail['recommended_by_appraiser']))
                      <td class="align-middle">
                        <select name="appraiser_msg[{{$key}}]" id="appraiser_msg" class="form-select form-control select2-show-search" data-parsley-required-message="Select Option" required>
                          <option value="non" selected>Select Option</option>
                          <option value="Recommended">Recommended</option>
                          <option value="Non-Recommended">Non-Recommended</option>
                        </select>
                      </td>
                      @else
                      <td class="align-middle">
                        <select name="appraiser_msg[{{$key}}]" id="appraiser_msg" class="form-select form-control" data-parsley-required-message="Select Option" readonly="">
                          <option value="non" selected>{{$trainingDetail['recommended_by_appraiser']}}</option>
                        </select>
                      </td>
                      @endif
                    </tr>
                    @endforeach
                  </tbody>
                </table>
                <!-- end Section 5:TRAINING NEEDS IDENTIFICATION -->


              </div>
              @endforeach
              @if($kraData['type'] < 2) <div class="text-center mt-3">
                <button class="button button_onboarding" type="submit" onclick="show_message();">Submit</button>
            </div>
            @else
            <p class="alert alert-danger text-center">Form Already Submmited !</p>
            @endif

          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="largemodal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg " role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Appraisal Form Details</h5>
        <button class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-bordered border text-nowrap text-md-nowrap" id="section_appraiser">
          <h3 class="bg-text">PERFORMANCE SCORE</h3>
          <thead class="bg-primary">
            <tr>
              <th class="text-white">Rating</th>
              <th class="text-white">Description</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="align-middle">5</td>
              <td class="align-middle">Outstanding. Excellent, setting standard for others to follow</td>
            </tr>
            <tr>
              <td class="align-middle">4</td>
              <td class="align-middle">Very Good. Exceeded expectations. Achieved greater-than-expected results</td>
            </tr>
            <tr>
              <td class="align-middle">3</td>
              <td class="align-middle">Good. Met expectations. Satisfactory</td>
            </tr>
            <tr>
              <td class="align-middle">2</td>
              <td class="align-middle">Average. Met expectations sometimes only. Improvement needed.</td>
            </tr>
            <tr>
              <td class="align-middle">1</td>
              <td class="align-middle">Below Average/Poor. Did Not meet Expectations</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- /.content-wrapper ends here -->
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

<!-- Custom script starts here -->
@section('script')
<script>
  $(document).ready(function() {
    $('#pre_expense_approval_form').parsley();
  });


  // total appraisee sum value
  $(document).ready(function() {
    $("#myTable").on('change', '.weighted_score', function() {
      var calculated_total_sum = 0;

      $("#myTable .total_appraiser_score").each(function() {
        var get_textbox_value = $(this).val();
        if ($.isNumeric(get_textbox_value)) {
          calculated_total_sum += parseFloat(get_textbox_value);
        }
      });
      // $("#total_sum_value").html(calculated_total_sum);
      var totalValue = calculated_total_sum.toFixed(2);
      $('#total_appraiser_value').val(totalValue);
    });

  });

  $(document).ready(function() {
    $('.weightage, .score_appraiser').change(function() {
      var parent = $(this).closest('tr')
      let weightage = parseFloat(parent.find('.weightage').val())
      let score_appraisee = parseFloat($(this).val())

      let totalVal = weightage / 100 * score_appraisee
      totalVal = totalVal.toFixed(2)
      parent.find('.total').val(totalVal)
    });
  });

  // add self COMPETENCIES REVIEW
  $(document).ready(function() {

    $("#section_appraiser").on('input', '.appraiser_score', function() {
      var calculated_total_sum = 0;
      $("#section_appraiser .appraiser_score").each(function() {
        var get_textbox_value = $(this).val();
        if ($.isNumeric(get_textbox_value)) {
          calculated_total_sum += parseFloat(get_textbox_value);
        }
      });
      $("#total_appraiser").val(calculated_total_sum);
    });
  });

  // conformation form submit
  function show_message() {
    alert("Do you really want to submit the form?");
  }
</script>
@endsection
<!-- Custom script ends here -->

@endsection