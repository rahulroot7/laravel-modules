@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  .bg-text {
    background-color: #bfbfbf69;
    padding: 3px;
    text-align: center;
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">APPRASIEE KRA FORM</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Appraisal Kra Form</li>
    </ol>
  </div>
  <div class="ms-auto pageheader-btn">
    <button class="btn btn-info mt-3" data-bs-toggle="modal" data-bs-target="#largemodal">Rating Detail</button>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="largemodal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg " role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Appraisal Form Details</h5>
        <button class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-bordered border text-nowrap text-md-nowrap" id="section_appraiser">
          <h3 class="bg-text">PERFORMANCE SCORE</h3>
          <thead class="bg-primary">
            <tr>
              <th class="text-white">Rating</th>
              <th class="text-white">Description</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="align-middle">5</td>
              <td class="align-middle">Outstanding. Excellent, setting standard for others to follow</td>
            </tr>
            <tr>
              <td class="align-middle">4</td>
              <td class="align-middle">Very Good. Exceeded expectations. Achieved greater-than-expected results</td>
            </tr>
            <tr>
              <td class="align-middle">3</td>
              <td class="align-middle">Good. Met expectations. Satisfactory</td>
            </tr>
            <tr>
              <td class="align-middle">2</td>
              <td class="align-middle">Average. Met expectations sometimes only. Improvement needed.</td>
            </tr>
            <tr>
              <td class="align-middle">1</td>
              <td class="align-middle">Below Average/Poor. Did Not meet Expectations</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        <form method="post" action="{{ route('appraisal-employee-kra-form.save') }}" id="pre_expense_approval_form" enctype="multipart/form-data" autocomplete="off">
          @csrf
          <div class="box-body">
            <div class="row">
              <div class="row">
                <input type="hidden" name="type" value="1" class="form-control mb-4">
                @foreach($employeeDetail as $empDetail)
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3" id="name">
                    <label class="fw-bold mb-0">Name <span style="color:red">*</span></label>
                    @foreach($employeeKraData as $kraID)
                    <input type="hidden" name="kra_id" value="{{$kraID['id']}}" class="form-control mb-4" readonly="">
                    @endforeach
                    <input type="text" name="name" class="form-control mb-4" value="{{$empDetail->full_name}}" readonly="">
                  </div>
                </div>
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3" id="employee_id">
                    <label class="fw-bold mb-0">Employee ID <span style="color:red">*</span></label>
                    <input type="hidden" name="employee_id" value="{{$empDetail->user_id}}" class="form-control mb-4" readonly="">
                    <input type="text" placeholder="{{$empDetail->employee_id}}" class="form-control mb-4" readonly="">
                  </div>
                </div>
                <div class="col-lg-4 col-md-6">
                  @foreach($department as $departmentDetail)
                  <div class="mb-3" id="department_id">
                    <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                    <input type="hidden" name="department_id" value="{{$departmentDetail->id}}" class="form-control mb-4" readonly="">
                    <input type="text" placeholder="{{$departmentDetail->name}}" class="form-control mb-4" readonly="">
                  </div>
                  @endforeach
                </div>
              </div>
              <div class="row">
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3">
                    @foreach($country as $countryDetail)
                    <label class="fw-bold mb-0">Country <span style="color:red">*</span></label>
                    <input type="hidden" name="country_id" value="{{$countryDetail->id}}" class="form-control mb-4" readonly="">
                    <input type="text" placeholder="{{$countryDetail->name}}" class="form-control mb-4" readonly="">
                    @endforeach
                  </div>
                </div>
                <div class="col-lg-4 col-md-6">
                  <div class="mb-3">
                    @foreach($state as $address)
                    <label class="fw-bold mb-0">State <span style="color:red">*</span></label>
                    <input type="hidden" name="state_id" value="{{$address->id}}" class="form-control mb-4">
                    <input type="text" placeholder="{{$address->name}}" class="form-control mb-4" readonly="">
                    @endforeach
                  </div>
                </div>

                <div class="col-lg-4 col-md-6">
                  @foreach($appraiser as $appraiserDetail)
                  <div class="mb-3" id="appraiser :">
                    <label class="fw-bold mb-0">Name Of Appraiser <span style="color:red">*</span></label>
                    <input type="hidden" name="appraiser_id" value="{{$appraiserDetail->id}}" class="form-control mb-4">
                    <input type="text" placeholder="{{$appraiserDetail->full_name}}" class="form-control mb-4" readonly="">
                  </div>
                  @endforeach
                </div>

                <!-- <div class="col-lg-4 col-md-6">
                    <div class="mb-3">
                        <label class="fw-bold mb-0">Projects assigned <span style="color:red">*</span></label>
                        <input type="text" name="projects_assigned" class="form-control mb-4"> 
                    </div>
                </div> -->
              </div>
              <!-- <div class="col-lg-4 col-md-6">
                    <div class="mb-3" id="reviewer">                    
                        <label class="fw-bold mb-0">Name Of Reviewer <span style="color:red">*</span></label>
                        <input type="text" name="reviewer" class="form-control mb-4"> 
                    </div>
                </div> -->
            </div>
            @endforeach

            @if(empty($appraisalKra))
            <div class="table-responsive my-3">
              <table class="table table-bordered border text-nowrap text-md-nowrap" id="myTable">
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">KEY RESULT AREAS<br>(Performance <br>Objectives)*</th>
                    <th class="text-white">Target (%)</th>
                    <th class="text-white">WEIGHTAGE (%)- (A)</th>
                    <th class="text-white">Achievement<br>(To be<br>filled <br>Appraisee)</th>
                    <th class="text-white">Score<br>by<br>Appraisee (1-5) -(B)</th>
                    <th class="text-white">Weighted<br>Score (C=A/100xB)</th>

                  </tr>
                  <tr>
                  </tr>
                </thead>
                <tbody>
                  <?php $TotalWeatage = 0; ?>
                  @foreach($employeeKraData as $kraData)
                  @foreach($kraData['employee_kra_detail'] as $key => $kradetail)
                  <tr>
                    <td class="align-middle">
                      <input type="text" name="kra[{{$key}}]" value="{{$kradetail['kra']}}" class="form-control name" data-name="kra" readonly="">
                    </td>
                    <td class="align-middle">
                      <input type="text" name="target[{{$key}}]" value="{{$kradetail['target']}}" class="form-control name" data-name="target" readonly="">
                    </td>
                    <td class="align-middle">
                      <input type="text" name="weightage[{{$key}}]" value="{{$kradetail['weightage']}}" class="form-control weightage" data-name="weightage" readonly="">
                    </td>
                    <td class="align-middle">
                      <input type="text" name="achievement[{{$key}}]" class="form-control name" data-name="achievement" placeholder="Enter achievement" required>
                    </td>
                    <td class="align-middle">
                      <!-- <input type="text" name="score_by_appraisee[{{$key}}]" class="form-control weighted_score score_appraisee" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="score_by_appraisee" required> -->
                      <select name="score_by_appraisee[{{$key}}]" class="form-select form-control weighted_score score_appraisee" data-parsley-required-message="Please Select status" required>
                        <option value="5">select score</option>
                        <option value="5">5</option>
                        <option value="4.5">4.5</option>
                        <option value="4">4</option>
                        <option value="3.5">3.5</option>
                        <option value="3">3</option>
                        <option value="2.5">2.5</option>
                        <option value="2">2</option>
                        <option value="1.5">1.5</option>
                        <option value="1">1</option>
                      </select>
                    </td>
                    <td class="align-middle">
                      <input type="text" name="weighted_score[{{$key}}]" class="form-control total_weighted_score total" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="weighted_score" required>
                    </td>
                  </tr>
                  <?php
                  $TotalWeatage += $kradetail['weightage'];
                  ?>
                  @endforeach
                  <tr>
                    <th class="align-middle">
                      <b>TOTAL</b>
                    </th>
                    <th class="align-middle">
                      <b></b>
                    </th>
                    <th class="align-middle">
                      <input type="text" name="total_weightage" value="{{$TotalWeatage}}" class="form-control" readonly="">
                    </th>
                    <th class="align-middle">
                      <b></b>
                    </th>
                    <th class="align-middle">
                      <b></b>
                    </th>
                    <th class="align-middle">
                      <input type="text" name="appraisee_total_weightage" id="total_sum_value" class="form-control name" min="0" max="5" data-parsley-validation-threshold="1" readonly="">
                    </th>
                </tbody>
              </table>
              <!-- Appraisal Comment  -->
              <table class="table table-bordered border text-nowrap text-md-nowrap">
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">Appraisee's Comment</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle">
                      <textarea name="appraisee_comment" id="appraisee_comment" class="form-control" cols="30" rows="5" placeholder="Please enter the comment about appraisal form."></textarea>
                    </td>
                  </tr>
                </tbody>
              </table>
              <!-- end apprasal comment -->

              <!-- Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS  -->
              <table class="table table-bordered border text-nowrap text-md-nowrap">
                <h3 class="bg-text">Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS</h3>
                <p class="bg-text">Describe the important factors (personal, organisational, external) affecting your performance.</p>
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">FACILITATING</th>
                    <th class="text-white">HINDERING</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="align-middle">
                      <input type="text" name="facilitating[0]" class="form-control" data-name="factors" placeholder="Enter facilitating" required><br>
                      <input type="text" name="facilitating[1]" class="form-control" data-name="factors" placeholder="Enter Facilitating" required><br>
                      <input type="text" name="facilitating[2]" class="form-control" data-name="factors" placeholder="Enter Facilitating" required><br>
                      <input type="text" name="facilitating[3]" class="form-control" data-name="factors" placeholder="Enter Facilitating" required><br>
                    </td>
                    <td class="align-middle">
                      <input type="text" name="hindering[0]" class="form-control" data-name="factors" placeholder="Enter hindering" required><br>
                      <input type="text" name="hindering[1]" class="form-control" data-name="factors" placeholder="Enter hindering" required><br>
                      <input type="text" name="hindering[2]" class="form-control" data-name="factors" placeholder="Enter hindering" required><br>
                      <input type="text" name="hindering[3]" class="form-control" data-name="factors" placeholder="Enter hindering" required><br>
                    </td>
                  </tr>
                </tbody>
              </table>
              <!-- end Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS -->

              <!-- Section 3: COMPETENCIES REVIEW  -->
              <table class="table table-bordered border text-nowrap text-md-nowrap" id="section_competencies_review">
                <h3 class="bg-text">Section 3: COMPETENCIES REVIEW</h3>
                <p class="bg-text">Employee is to be assessed on a 5 point scale with 5 as "highest" and 1 as "lowest". Please note that 6 Factors are mentioned below, the other 4 factors may be chosen from grid in Section 6 depending on appraisee's designation</p>
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">S.No.</th>
                    <th class="text-white">PERSONAL EFFECTIVENESS FACTORS <br>(There should be <br>total 10 factors mandatory)</th>
                    <th class="text-white">Self (1-5)</th>
                    <th class="text-white">&nbsp;</th>
                  </tr>
                </thead>
                <tbody id="section_3">
                  <?php $count = '0'; ?>
                  <?php
                  // print_r($compentencies);
                  // die;
                  ?>

                  @foreach($compentenciesBand as $compentenciesDetail)
                  <?php $count++; ?>
                  <tr>
                    @if($compentenciesDetail['is_fixed'] == '1')
                    <td class="align-middle">{{$count}}</td>
                    <td class="align-middle">
                      <input type="text" name="factors[{{$compentenciesDetail['id']}}]" value="{{$compentenciesDetail['name']}}" class="form-control" data-name="factors" readonly="">
                    </td>
                    <td class="align-middle">
                      <!-- <input type="text" name="self[{{$compentenciesDetail['id']}}]" class="form-control self_score" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="self" maxlength="1" required> -->
                      <select name="self[{{$compentenciesDetail['id']}}]" class="form-control self_score" data-parsley-required-message="Please Select Score" data-name="self" required>
                        <option>Select Score</option>
                        <option value="5">5</option>
                        <option value="4.5">4.5</option>
                        <option value="4">4</option>
                        <option value="3.5">3.5</option>
                        <option value="3">3</option>
                        <option value="2.5">2.5</option>
                        <option value="2">2</option>
                        <option value="1.5">1.5</option>
                        <option value="1">1</option>
                      </select>
                    </td>
                    @endif
                  </tr class="not-fixed">
                  @if($compentenciesDetail['is_fixed'] == '0')
                  <td class="align-middle">
                    <input type="checkbox" name="factors_fixed[{{$count}}][is_active]" class="band-check checkbox_1">
                  </td>
                  <td class="align-middle">

                    <input type="text" name="factors_fixed[{{$count}}][factor_id]" value="{{$compentenciesDetail['name']}}" class="form-control" id="band" data-name="factors" readonly="" required>
                  </td>
                  <td class="align-middle">
                    <input type="text" name="factors_fixed[{{$count}}][score]" class="form-control self_score self" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="self" maxlength="1" readonly="">
                  </td>
                  @endif
                  </tr>
                  @endforeach
                </tbody>
                <tr>
                  <th class="align-middle">
                    <b>TOTAL</b>
                  </th>
                  <th class="align-middle">
                    <b></b>
                  </th>
                  <th class="align-middle">
                    <input type="text" name="total_self" id="total_self" class="form-control" readonly="">
                  </th>
                </tr>
              </table>
              <!-- end Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS -->
              <!-- Section 5: ANALYSIS OF STRENGTHS AND LIMITATIONS  -->
              <table class="table table-bordered border text-nowrap text-md-nowrap" id="p_a_e_t">
                <h3 class="bg-text">Section 4: TRAINING NEEDS IDENTIFICATION</h3>
                <h5 class="bg-text">TO BE FILLED BY THE APPRAISER / HEAD OF THE DEPARTMENT</h5>
                <p class="bg-text"> Indicate specific needs for development, recommend training programmes and prioritize.</p>
                <thead class="bg-primary">
                  <tr>
                    <th class="text-white">S.No.</th>
                    <th class="text-white">AREAS OF TRAINING<br>(Please refer to Training Program<br>List for Specific Trainings)</th>
                    <th class="text-white">SUGGESTED BY APPRAISEE</th>
                    <th class="text-white">&nbsp;</th>
                  </tr>
                </thead>
                <tbody id="training_section">

                  <tr>
                    <td class="align-middle rownumber">1</td>
                    <td class="align-middle">
                      <select name="training[0]" id="training" class="form-select form-control select2-show-search" data-parsley-required-message="Select Training" required>
                        <option value="non" selected disabled>Select Traning</option>
                        <option value="Job">Job / Function Related</option>
                        <option value="Behaviour">Behavioural</option>
                      </select>
                    </td>
                    <td class="align-middle">
                      <input name="appraisee_training_area[0]" id="appraisee_Job_function" class="form-control">
                    </td>

                    <td class="align-middle">
                      <a href="javascript:void(0)" id="add_training">
                        <i class="fa fa-plus a_r_style a_r_style_green"></i>
                      </a>
                    </td>
                  </tr>

                </tbody>
              </table>
              <!-- end Section 5: ANALYSIS OF STRENGTHS AND LIMITATIONS -->


            </div>
            @endforeach
            <?php
            if ($checkFormStatus == array()) { ?>
              <div class="text-center mt-3">
                <button class="button button_onboarding" type="submit" onclick="show_message();">Submit</button>
              </div>
            <?php
            } else { ?>
              <p class="alert alert-danger text-center">Form Already Submmited !</p>
            <?php } ?>

          </div>
        </form>
      </div>
      <!-- show form after submmited -->
      @else
      <div class="table-responsive my-3">
        <table class="table table-bordered border text-nowrap text-md-nowrap" id="myTable">
          <thead class="bg-primary">
            <tr>
              <th class="text-white text-size">KEY RESULT AREAS<br>(Performance <br>Objectives)*</th>
              <th class="text-white text-size">Target (%)</th>
              <th class="text-white text-size">weightage (%) </th>
              <th class="text-white text-size">Achievement<br>(To be<br>filled <br>Appraisee)</th>
              <th class="text-white text-size">Score<br>by<br>Appraisee (1-5)-B</th>
              <th class="text-white text-size">Weighted<br>Score (C=A/100xB)</th>
            </tr>
            <tr>
            </tr>
          </thead>
          <tbody>
            <?php $TotalWeatage = 0; ?>
            @foreach($appraisalKra as $kraData)
            @foreach($kraData['employee_kra_detail'] as $key => $kradetail)
            <tr>
              <td class="align-middle">
                <input type="text" name="kra[{{$key}}]" value="{{$kradetail['kra']}}" class="form-control name" data-name="kra" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="target[{{$key}}]" value="{{$kradetail['target']}}" class="form-control name" data-name="target" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="weightage[{{$key}}]" value="{{$kradetail['weightage']}}" class="form-control weightage" data-name="weightage" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="achievement[{{$key}}]" value="{{$kradetail['achievement']}}" class="form-control name" data-name="achievement" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="score_by_appraisee[{{$key}}]" value="{{$kradetail['score_by_appraisee']}}" class="form-control" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="score_by_appraisee" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="weighted_score[{{$key}}]" value="{{$kradetail['weighted_score']}}" class="form-control" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="weighted_score" readonly="">
              </td>
            </tr>
            <?php
            $TotalWeatage += $kradetail['weightage'];
            ?>
            @endforeach
            <tr>
              <th class="align-middle">
                <b>TOTAL</b>
              </th>
              <th class="align-middle">
                <b></b>
              </th>
              <th class="align-middle">
                <input type="text" name="total_weightage" value="{{$TotalWeatage}}" class="form-control" readonly="">
              </th>
              <th class="align-middle">
                <b></b>
              </th>
              <th class="align-middle">
                <b></b>
              </th>
              <!-- score and weightage for appraiseee -->
              <th class="align-middle">
                <input type="text" name="appraisee_total_weightage" value="{{$kraData['total_weighted_score']}}" id="total_sum_value" class="form-control name" min="0" max="5" data-parsley-validation-threshold="1" readonly="">
              </th>
              <!-- score and weightage for appraiser -->
              <th class="align-middle">
                <b></b>
              </th>
            <tr>
          </tbody>
          <!-- Appraisal Comment  -->
          <table class="table table-bordered border text-nowrap text-md-nowrap">
            <thead class="bg-primary">
              <tr>
                <th class="text-white">Appraisee's Comment</th>
              </tr>
            </thead>
            <tbody>
              @foreach($kraData['comment_detail'] as $key => $comment)
              <tr>
                <td class="align-middle">
                  <textarea class="form-control" cols="30" rows="3" readonly="">{{$comment['comment']}}</textarea>
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
          <!-- end apprasal comment -->
        </table>
        <!-- Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS  -->
        <table class="table table-bordered border text-nowrap text-md-nowrap">
          <h3 class="bg-text">Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS</h3>
          <p class="bg-text">Describe the important factors (personal, organisational, external) affecting your performance.</p>
          <thead class="bg-primary">
            <tr>
              <th class="text-white">FACILITATING</th>
              <th class="text-white">HINDERING</th>
            </tr>
          </thead>
          <tbody>
            @foreach($kraData['strength_limitation_detail'] as $key => $limitation)
            <tr>
              <td class="align-middle">
                <input type="text" value="{{$limitation['facilitating']}}" class="form-control" data-name="factors" readonly>
              </td>
              <td class="align-middle">
                <input type="text" value="{{$limitation['hindering']}}" class="form-control" data-name="factors" readonly>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
        <!-- end Section 2: ANALYSIS OF STRENGTHS AND LIMITATIONS -->
        <!-- Section 2: COMPETENCIES REVIEW  -->
        <table class="table table-bordered border text-nowrap text-md-nowrap">
          <h3 class="bg-text">Section 3: COMPETENCIES REVIEW</h3>
          <p class="bg-text">Employee is to be assessed on a 5 point scale with 5 as "highest" and 1 as "lowest". Please note that 6 Factors are mentioned below, the other 4 factors may be chosen from grid in Section 6 depending on appraisee's designation</p>
          <thead class="bg-primary">
            <tr>
              <th class="text-white">S.No.</th>
              <th class="text-white">PERSONAL EFFECTIVENESS FACTORS <br>(There should be <br>total 10 factors mandatory)</th>
              <th class="text-white">Self (1-5)</th>
            </tr>
          </thead>
          <tbody id="section_3">
            @foreach($kraData['appraisal_competencies_detail'] as $key => $competencies)
            <tr>
              <td class="align-middle">{{ @$loop->iteration }}</td>
              <td class="align-middle">
                <input type="text" name="factors[{{$key}}]" value="{{$competencies['factors']}}" class="form-control" data-name="factors" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="self[{{$key}}]" value="{{$competencies['self']}}" class="form-control self_score" min="0" max="5" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" data-parsley-type="number" data-name="self" readonly="">
              </td>
              <!-- <td class="align-middle">
                        <a href="javascript:void(0)" id="add_section_3">
                          <i class="fa fa-plus a_r_style a_r_style_green"></i>
                        </a>
                      </td> -->
            </tr>
            @endforeach
          </tbody>
          <tr>
            <th class="align-middle">
              <b>TOTAL</b>
            </th>
            <th class="align-middle">
              <b></b>
            </th>
            <th class="align-middle">
              <input type="text" name="total_self" id="total_self" value="{{$kraData['competencies_self_total']}}" class="form-control" readonly="">
            </th>
            </th>
          </tr>
        </table>
        <!-- end Section 2: COMPETENCIES REVIEW -->
        <!-- Section 5: TRAINING NEEDS IDENTIFICATION  -->
        <table class="table table-bordered border text-nowrap text-md-nowrap">
          <h3 class="bg-text">Section 4: TRAINING NEEDS IDENTIFICATION</h3>
          <h5 class="bg-text">TO BE FILLED BY THE APPRAISER / HEAD OF THE DEPARTMENT</h5>
          <p class="bg-text"> Indicate specific needs for development, recommend training programmes and prioritize.</p>
          <thead class="bg-primary">
            <tr>
              <th class="text-white">AREAS OF TRAINING<br>(Please refer to Training Program<br>List for Specific Trainings)</th>
              <th class="text-white">SUGGESTED BY APPRAISEE</th>
            </tr>
          </thead>
          <tbody>
            @foreach($kraData['appraisal_training_detail'] as $key => $trainingDetail)
            <tr>
              <td class="align-middle">
                <input type="text" name="Job[{{$key}}]" value="{{$trainingDetail['traning_type']}}" class="form-control" readonly="">
              </td>
              <td class="align-middle">
                <input type="text" name="appraisee_Job_function[{{$key}}]" value="{{$trainingDetail['suggested_by_appraisee']}}" class="form-control" readonly="">
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
        <!-- end Section 5:TRAINING NEEDS IDENTIFICATION -->
      </div>
      @endforeach
      <p class="alert alert-danger text-center">Form Already Submmited !</p>
      @endif
    </div>
  </div>
</div>

<!-- /.content-wrapper ends here -->
<script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

<!-- Custom script starts here -->
@section('script')
<script>
  $(document).ready(function() {

    function checkboxCounter(currentCheckbox) {
      var numberOfChecked = $('#section_competencies_review').find('input:checkbox:checked').length;
      console.log(numberOfChecked);

      if (numberOfChecked > 4) {
        alert('Maximum 10 Compentencies complete !');
        currentCheckbox.prop('checked', false);
      } else if (numberOfChecked <= 4) {
        currentCheckbox.closest('tr').find('.self').prop('readonly', false);
        currentCheckbox.closest('tr').find('.self').val('');
        var calculated_total_sum = 0;
        $("#section_competencies_review .self_score").each(function() {
          var get_textbox_value = $(this).val();
          if ($.isNumeric(get_textbox_value)) {
            calculated_total_sum += parseFloat(get_textbox_value);
          }
        });
        $("#total_self").val(calculated_total_sum);

      }
    }


    $('.checkbox_1').on('change', function() {
      if ($(this).is(':checked')) {
        checkboxCounter($(this));
      } else {
        $(this).closest('tr').find('.self').prop('readonly', true);
        $(this).closest('tr').find('.self').val('');
        var calculated_total_sum = 0;
        $("#section_competencies_review .self_score").each(function() {
          var get_textbox_value = $(this).val();
          if ($.isNumeric(get_textbox_value)) {
            calculated_total_sum += parseFloat(get_textbox_value);
          }
        });
        $("#total_self").val(calculated_total_sum);

      }
    })
  });

  $(document).ready(function() {
    $('#pre_expense_approval_form').parsley();


    // Renumber Name Attribute
    function renumberNameAttr(tbody) {
      let count = 0;
      $(tbody).find('tr').each(function(i) {
        if (i > 0) {
          count++;
          $(this).find('input').each(function() {
            let dataNameAttrValue = $(this).attr('data-name');
            let nameAttrValue = dataNameAttrValue + '[' + count + ']';
            $(this).attr('name', nameAttrValue);
          });
        }
      });
    }

    $(document).on('input', '.input_amount', function() {
      totalRowSum($(this));
    });


  });



  // total appraisee sum value
  $(document).ready(function() {
    $("#myTable").on('change', '.weighted_score', function() {
      var calculated_total_sum = 0;

      $("#myTable .total_weighted_score").each(function() {
        var get_textbox_value = $(this).val();
        if ($.isNumeric(get_textbox_value)) {
          calculated_total_sum += parseFloat(get_textbox_value);
        }
      });
      // $("#total_sum_value").html(calculated_total_sum);
      var totalValue = calculated_total_sum.toFixed(2);
      $('#total_sum_value').val(totalValue);
    });

  });

  $(document).ready(function() {
    $('.weightage, .score_appraisee').change(function() {
      var parent = $(this).closest('tr')
      let weightage = parseFloat(parent.find('.weightage').val())
      let score_appraisee = parseFloat($(this).val())

      let totalVal = weightage / 100 * score_appraisee
      totalVal = totalVal.toFixed(2)
      parent.find('.total').val(totalVal)
    });
  });


  // add self compentencies limitation
  $(document).ready(function() {

    $("#section_competencies_review").on('input', '.self_score', function() {
      var calculated_total_sum = 0;
      $("#section_competencies_review .self_score").each(function() {
        var get_textbox_value = $(this).val();
        if ($.isNumeric(get_textbox_value)) {
          calculated_total_sum += parseFloat(get_textbox_value);
        }
      });
      $("#total_self").val(calculated_total_sum);
    });
  });

  // add training field add more
  $(document).ready(function() {
    $('#pre_expense_approval_form').parsley();

    $('#add_training').on('click', function() {
      let html = '<tr >' +
        '<td class="align-middle rownumber"></td>' +

        '<td class="align-middle">' +
        '<select name="training[]" class="form-select form-control select2-show-search" data-name="appraisee_training_area" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" required><option value="Job">Job / Function Related</option><option value="Behaviour">Behavioural</option></select>' +
        '</td>' +

        '<td class="align-middle">' +
        '<input type="text" name="appraisee_training_area[]" class="form-control appraisee_training_area" data-name="appraisee_training_area" data-parsley-validation-threshold="1" data-parsley-trigger="keyup" required>' +
        '</td>' +
        '<td class="align-middle">' +
        '<a href="javascript:void(0)" class="remove_expense">' +
        '<i class="fa fa-minus a_r_style a_r_style_red"></i>' +
        '</a>' +
        '</td>' +

        '</tr>';

      $('#training_section').append(html);

      renumberRows();
      renumberNameAttr('#training_section');
    });

    $(document).on('click', '.remove_expense', function() {
      $(this).closest('tr').remove();
      renumberRows();
      renumberNameAttr('#training_section');
    });
    // Update Table Counters
    function renumberRows() {
      $('#training_section .rownumber').each(function(i) {
        $(this).text(i + 1);
      });
    }

    // Renumber Name Attribute
    function renumberNameAttr(tbody) {
      let count = 0;
      $(tbody).find('tr').each(function(i) {
        if (i > 0) {
          count++;
          $(this).find('input').each(function() {
            let dataNameAttrValue = $(this).attr('data-name');
            let nameAttrValue = dataNameAttrValue + '[' + count + ']';
            $(this).attr('name', nameAttrValue);
          });
        }
      });
    }

    $(document).on('input', '.input_amount', function() {
      totalRowSum($(this));
    });


  });

  // conformation form submit
  function show_message() {
    alert("Do you really want to submit the form?");
  }
</script>
@endsection
<!-- Custom script ends here -->

@endsection