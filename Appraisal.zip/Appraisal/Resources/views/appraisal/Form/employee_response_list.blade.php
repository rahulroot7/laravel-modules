@extends('layouts.app')

@section('style')
<style>
    .process_bg {
        width: 240px;
        height: 3px;
        border-radius: 10px;
        background-color: lightgrey;
        position: relative;
        top: -10px;
    }

    .process_bar_circle {
        width: 12px;
        height: 12px;
        background-color: darkgrey;
        position: relative;
        top: 20px;
        margin-bottom: 20px;
    }

    .performance-score {
        text-align: center;
    }

    .steps-sucess {
        background: green !important;
    }
</style>
@endsection
@push('style-scripts')

@endpush
@section('content')
<div class="page-header">
    <div>
        <h1 class="page-title">Employees Response</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Employees Response</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div>
                <div class="card-body">
                    <div class="box-body">
                        <div class="row">
                            <!-- show only reviewer -->
                            <?php
                            foreach ($appraiserList as $list) {
                                $reviewer_id = $list['reviewer_id'];
                                $appraiser_id = $list['appraiser_id'];
                            }
                            ?>
                            @can('ReviewerRole',Modules\Appraisal\Entities\AppraisalEmployeeKra::class)
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="fw-bold mb-0">Department</label>
                                    <select name="department" id="department" class="form-select form-control select2-show-search" data-parsley-errors-container="#department" data-parsley-required-message="Please Select department">
                                        <option value="1" selected>Select Department</option>
                                        @foreach($department as $departmentData)
                                        <option value="{{$departmentData->id}}">{{$departmentData->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                @php
                                $financialYear = \Modules\Appraisal\Helper\Helpers::financialYear()
                                @endphp
                                <div class="mb-3">
                                    <label class="fw-bold mb-0">Financial Year</label>
                                    <select name="financial" id="financial" class="form-select form-control select2-show-search" data-parsley-errors-container="#financial" data-parsley-required-message="Please Select financial year" required>
                                        @foreach($financialYear as $year)
                                        <option value="{{$year}}" selected>{{$year}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="fw-bold mb-0">Status <span style="color:red">*</span></label>
                                    <select name="status" id="status" class="form-select form-control select2-show-search" data-parsley-errors-container="#status" data-parsley-required-message="Please Select status" required>
                                        <option value="1" selected>Select status</option>
                                        <option value="2">New</option>
                                        <option value="3">Approved</option>
                                    </select>
                                </div>
                            </div>
                            @endcan

                            <!-- appraisal filter -->
                            @can('AppraiserRole',Modules\Appraisal\Entities\AppraisalEmployeeKra::class)
                            <!-- <input type="hidden" name="appraiser_department" id="appraiser_department" value="2"> -->
                            <div class="col-lg-6 col-md-6">
                                @php
                                $financialYear = \Modules\Appraisal\Helper\Helpers::financialYear()
                                @endphp
                                <div class="mb-3">
                                    <label class="fw-bold mb-0">Financial Year</label>
                                    <select name="appraiser_financial" id="appraiser_financial" class="form-select form-control select2-show-search" data-parsley-errors-container="#appraiser_financial" data-parsley-required-message="Please Select financial year" required>
                                        @foreach($financialYear as $year)
                                        <option value="{{$year}}" selected>{{$year}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="fw-bold mb-0">Status <span style="color:red">*</span></label>
                                    <select name="appraiser_status" id="appraiser_status" class="form-select form-control select2-show-search" data-parsley-errors-container="#appraiser_status" data-parsley-required-message="Please Select status" required>
                                        <option value="1" selected>Select status</option>
                                        <option value="1">New</option>
                                        <option value="3">Approved</option>
                                    </select>
                                </div>
                            </div>
                            @endcan
                        </div>
                    </div>
                </div>

                <div class="table-responsive my-3">
                    <table class="table table-bordered table-striped table-hover data-table" id="example2">
                        <thead class="bg-primary">
                            <tr>
                                <th class="fw-bold text-white">S.No.</th>
                                <th class="fw-bold text-white">Employee Code</th>
                                <th class="fw-bold text-white">Name</th>
                                <th class="fw-bold text-white">Progress</th>
                                <th class="fw-bold text-white">Rating</th>
                                <th class="fw-bold text-white">Action</th>
                            </tr>
                        </thead>
                        <tbody class="employee-list-response">
                            <?php
                            $appraiser_id = '';
                            $reviewer_id = '';
                            foreach ($appraiserList as $list) {;
                                $appraiser_id = $list['appraiser_id'];
                                $reviewer_id = $list['reviewer_id'];
                            }
                            ?>
                            @foreach($appraiserList as $key => $kraTemplate)

                            <tr>
                                <td>{{ @$loop->iteration }}</td>
                                <td>{{ $kraEmployeeList[$key]['employee_id'] }}</td>
                                <td>{{ $kraEmployeeList[$key]['name'] }}</td>

                                <!-- <td>{{ $kraTemplate->type }}</td> -->
                                <td class="align-middle">
                                    <div class="d-flex justify-content-between align-items-center process_bg mx-3">
                                        @if($kraTemplate->type == 1)
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraisee</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle bg-warning rounded"></div>
                                            <span>Appraiser</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle bg-warning rounded"></div>
                                            <span>Reveiwer</span>
                                        </div>
                                        @endif
                                        @if($kraTemplate->type == 2)
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraisee</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraiser</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle bg-warning rounded"></div>
                                            <span>Reveiwer</span>
                                        </div>
                                        @endif
                                        @if($kraTemplate->type == 3)
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraisee</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraiser</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Reveiwer</span>
                                        </div>
                                        @endif
                                    </div>
                                </td>
                                <!-- Classes: bg-warning, bg-info, bg-danger, bg-success -->

                                <!-- Performance score Star rating -->
                                <td>
                                    <div class="progress-bg">
                                        <progress class="progress-bar" id="file" value="{{$kraTemplate->total_performance_score}}" max="5"></progress>
                                        <p class="performance-score">{{ $kraTemplate->total_performance_score }}/5</p>
                                        @if($kraTemplate->total_performance_score <= '1' ) <b>Below Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Below Average/Poor. Did Not meet Expectations." aria-hidden="true"></i>
                                                @elseif($kraTemplate->total_performance_score <= '2.5' && $kraTemplate->total_performance_score>= '1.5' )
                                                    <b>Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Average. Met expectations sometimes only. Improvement needed." aria-hidden="true"></i>
                                                            @elseif($kraTemplate->total_performance_score <= '3.5' && $kraTemplate->total_performance_score>= '2.5' )
                                                                <b>Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Good. Met expectations. Satisfactory." aria-hidden="true"></i>
                                                                        @elseif($kraTemplate->total_performance_score <= '4.5' && $kraTemplate->total_performance_score>= '3.5' )
                                                                            <b>Very Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Very Good. Exceeded expectations. Achieved greater-than-expected results." aria-hidden="true"></i>
                                                                                    @elseif($kraTemplate->total_performance_score <= '5' && $kraTemplate->total_performance_score>= '4.5' )
                                                                                        <b>Outstanding<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Outstanding. Excellent, setting standard for others to follow." aria-hidden="true"></i>
                                                                                                @endif
                                    </div>
                                </td>

                                <!-- <td>{{ $kraTemplate->total_performance_score }}</td> -->
                                @can('AppraiserRole',Modules\Appraisal\Entities\AppraisalEmployeeKra::class)
                                @if($kraTemplate->appraiser_id == Auth::user()->id)
                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate->user_id && $kraTemplate->type == '3')
                                <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-kra-response',$kraTemplate['kra_id']) }}">Final View</a><br><br>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-performance-score',$kraTemplate['kra_id']) }}">View Performance Score</a>
                                </td>
                                @endif
                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate->user_id && $kraTemplate->type == '1') <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-kra-response',$kraTemplate['kra_id']) }}">Add Review</a>
                                </td>
                                @endif
                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate->user_id && $kraTemplate->type == '2' ) <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-kra-response',$kraTemplate['kra_id']) }}">Preview</a>
                                </td>
                                @endif
                                @endif
                                @endcan

                                <!-- reviewer view  -->
                                @can('ReviewerRole',Modules\Appraisal\Entities\AppraisalEmployeeKra::class)
                                @if($kraTemplate->appraiser_id == Auth::user()->id || $kraTemplate->reviewer_id == Auth::user()->id )

                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate->user_id && $kraTemplate->type == '3')
                                <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-reviewer-response',$kraTemplate['kra_id']) }}">Final View</a><br><br>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-performance-score',$kraTemplate['kra_id']) }}">View Performance Score</a>
                                </td>
                                @endif
                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate->user_id && $kraTemplate->type < '3' ) <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-reviewer-response',$kraTemplate['kra_id']) }}">Add Review</a>
                                    </td>
                                    @endif
                                    @endif
                                    @endcan
                            </tr>
                            @endforeach
                        </tbody>
                        <tbody class="filter-response">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')

@endsection
@push('js-scripts')
<script>
    // filter reviewer year
    $(document).on('change', '#department,#status,#financial', function() {
        let department = $('#department').val();
        let status = $('#status').val();
        let financialyear = $('#financial').val();
        $(".employee-list-response").remove();
        $('#example2').DataTable().destroy();
        $.ajax({
            type: "GET",
            url: '{{ url("appraisal") }}/employee-reviewer-filter',
            data: {
                'department': department,
                'status': status,
                'financial': financialyear
            },
            success: function(data) {
                $('.filter-response').html(data);
                $(".data-table").DataTable({
                    "columnDefs": [{
                        orderable: false,
                    }],
                });
            }
        });
    });

    // filter appraiser year
    $(document).on('change', '#appraiser_status,#appraiser_financial', function() {
        // let department = $('#appraiser_department').val();
        let status = $('#appraiser_status').val();
        let financialyear = $('#appraiser_financial').val();
        $(".employee-list-response").remove();
        $('#example2').DataTable().destroy();
        $.ajax({
            type: "GET",
            url: '{{ url("appraisal") }}/employee-appraiser-filter',
            data: {
                'status': status,
                'financial': financialyear
            },
            success: function(data) {
                $('.filter-response').html(data);
                $(".data-table").DataTable({
                    "columnDefs": [{
                        orderable: false,
                    }],
                });
            }
        });
    });
    // datatable 
    $(".data-table").DataTable({
        "columnDefs": [{
            orderable: false,
        }],
    });
</script>
@endpush