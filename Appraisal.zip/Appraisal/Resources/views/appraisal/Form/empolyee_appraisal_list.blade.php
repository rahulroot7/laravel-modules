@extends('layouts.app')

@section('style')
<style>
    .process_bg {
        width: 240px;
        height: 3px;
        border-radius: 10px;
        background-color: lightgrey;
        position: relative;
        top: -10px;
    }

    .process_bar_circle {
        width: 12px;
        height: 12px;
        background-color: darkgrey;
        position: relative;
        top: 20px;
        margin-bottom: 20px;
    }

    .performance-score {
        text-align: center;
    }

    .steps-sucess {
        background: green !important;
    }
</style>
@endsection
@push('style-scripts')

@endpush
@section('content')
<div class="page-header">
    <div>
        <h1 class="page-title">Employees Response</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">Employees Response</li>
        </ol>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="col-lg-6 col-md-6">
                    @php
                    $financialYear = \Modules\Appraisal\Helper\Helpers::financialYear()
                    @endphp
                    <div class="mb-3">
                        <label class="fw-bold mb-0">Financial Year</label>
                        <select name="financial" id="financial" class="form-select form-control select2-show-search" data-parsley-errors-container="#financial" data-parsley-required-message="Please Select financial year" required>
                            @foreach($financialYear as $year)
                            <option value="{{$year}}" selected>{{$year}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="box-body">

                </div>
                <div class="table-responsive my-3">
                    <table class="table table-bordered table-striped table-hover data-table" id="example3">
                        <thead class="bg-primary">
                            <tr>
                                <th class="fw-bold text-white">S.No.</th>
                                <th class="fw-bold text-white">Employee Code</th>
                                <th class="fw-bold text-white">Name</th>
                                <th class="fw-bold text-white">Progress</th>
                                <th class="fw-bold text-white">Performance</th>
                                <th class="fw-bold text-white">Action</th>
                            </tr>
                        </thead>
                        <tbody class="employee-list-response">
                            @php
                            $count = '0';
                            @endphp
                            @foreach($appraiserTeamplate as $key => $kraTemplate)
                            @if(!empty($kraTemplate['appraisal_kra_id']))
                            @foreach($kraTemplate['appraisal_kra_id'] as $trakerData)
                            @php
                            $count++;
                            @endphp

                            <tr>
                                <td>{{ $count}}</td>
                                <td>{{ $kraEmployeeList[$key]['employee_id'] }}</td>
                                <td>{{ $kraEmployeeList[$key]['name'] }}</td>
                                <td class="align-middle">
                                    <div class="d-flex justify-content-between align-items-center process_bg mx-3">
                                        @if($trakerData['type'] == 1)
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraisee</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle bg-warning rounded"></div>
                                            <span>Appraiser</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle bg-warning rounded"></div>
                                            <span>Reveiwer</span>
                                        </div>
                                        @endif
                                        @if($trakerData['type'] == 2)
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraisee</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraiser</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle bg-warning rounded"></div>
                                            <span>Reveiwer</span>
                                        </div>
                                        @endif
                                        @if($trakerData['type'] == 3)
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraisee</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Appraiser</span>
                                        </div>
                                        <div class="d-flex flex-column align-items-center">
                                            <div class="process_bar_circle steps-sucess rounded"></div>
                                            <span>Reveiwer</span>
                                        </div>
                                        @endif
                                    </div>
                                </td>
                                <!-- Performance score Star rating -->
                                <td>
                                    <div class="progress-bg">
                                        <progress class="progress-bar" id="file" value="{{$trakerData['total_performance_score']}}" max="5"></progress>
                                        <p class="performance-score">{{ $trakerData['total_performance_score']}}/5</p>
                                        @if($trakerData['total_performance_score'] <= '1' ) <b>Below Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Below Average/Poor. Did Not meet Expectations." aria-hidden="true"></i>
                                                @elseif($trakerData['total_performance_score'] <= '2.5' && $trakerData['total_performance_score']>= '1.5' )
                                                    <b>Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Average. Met expectations sometimes only. Improvement needed." aria-hidden="true"></i>
                                                            @elseif($trakerData['total_performance_score'] <= '3.5' && $trakerData['total_performance_score']>= '2.5' )
                                                                <b>Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Good. Met expectations. Satisfactory." aria-hidden="true"></i>
                                                                        @elseif($trakerData['total_performance_score'] <= '4.5' && $trakerData['total_performance_score']>= '3.5' )
                                                                            <b>Very Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Very Good. Exceeded expectations. Achieved greater-than-expected results." aria-hidden="true"></i>
                                                                                    @elseif($trakerData['total_performance_score'] <= '5' && $trakerData['total_performance_score']>= '4.5' )
                                                                                        <b>Outstanding<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Outstanding. Excellent, setting standard for others to follow." aria-hidden="true"></i>
                                                                                                @endif
                                    </div>
                                </td>
                                </td>
                                @foreach($kraTemplate['appraisal_kra_id'] as $kraFinal)
                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate['appraisee_id'] && $kraFinal['type'] == '3')
                                <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('kra-form',$kraTemplate['id']) }}">Final View</a><br><br>
                                    <a class="btn btn-success" target="_blank" href="{{ route('employee-performance-score',$kraTemplate['id']) }}">View Performance Score</a>
                                </td>
                                @endif
                                @if($kraEmployeeList[$key]['user_id'] == $kraTemplate['appraisee_id'] && $kraFinal['type'] <= '2' ) <td>
                                    <a class="btn btn-success" target="_blank" href="{{ route('kra-form',$kraTemplate['id']) }}">Preview</a>
                                    </td>
                                    @endif
                                    @endforeach
                                    @if(empty($kraTemplate['appraisal_kra_id']))
                                    <td>
                                        <a class="btn btn-success" target="_blank" href="{{ route('kra-form',$kraTemplate['id']) }}">Add Review</a>
                                    </td>
                                    @endif


                            </tr>
                            @endforeach
                            @else
                            <td>{{ $count}}</td>
                            <td>{{ $kraEmployeeList[$key]['employee_id'] }}</td>
                            <td>{{ $kraEmployeeList[$key]['name'] }}</td>
                            <td class="align-middle">
                                <div class="d-flex justify-content-between align-items-center process_bg mx-3">
                                    <div class="d-flex flex-column align-items-center">
                                        <div class="process_bar_circle bg-warning rounded"></div>
                                        <span>Appraisee</span>
                                    </div>
                                    <div class="d-flex flex-column align-items-center">
                                        <div class="process_bar_circle bg-warning rounded"></div>
                                        <span>Appraiser</span>
                                    </div>
                                    <div class="d-flex flex-column align-items-center">
                                        <div class="process_bar_circle bg-warning rounded"></div>
                                        <span>Reveiwer</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                0/5
                            </td>
                            <td>
                                <a class="btn btn-success" target="_blank" href="{{ route('kra-form',$kraTemplate['id']) }}">Add Review</a>
                            </td>
                            @endif
                            @endforeach

                        </tbody>
                        <tbody class="filter-response">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')

@endsection
@push('js-scripts')
<script>
    // filter financial 
    $(document).on('change', '#financial', function() {
        let financialyear = $('#financial').val();
        $(".employee-list-response").remove();
        $('#example3').DataTable().destroy();
        $.ajax({
            type: "GET",
            url: '{{ url("appraisal") }}/employee-appraisee-filter',
            data: {
                'financial': financialyear
            },
            success: function(data) {
                $('.filter-response').html(data);
                $(".data-table").DataTable({
                    "columnDefs": [{
                        orderable: false,
                    }],
                });
            }
        });
    });

    $(".data-table").DataTable({
        "columnDefs": [{
            orderable: false,
        }],
    });
</script>
@endpush