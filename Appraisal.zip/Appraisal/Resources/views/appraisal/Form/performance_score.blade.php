@extends('layouts.app')

@section('style')
<style>
  table thead tr th,
  table tbody tr td {
    padding: 8px !important;
  }

  th.text-white.text-size {
    font-size: 12px;
  }

  .bg-text {
    background-color: #bfbfbf69;
    padding: 3px;
  }
</style>
@endsection

@section('content')

<div class="page-header">
  <div>
    <h1 class="page-title">APPRAISAL KRA FORM</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Appraisal Kra Form</li>
    </ol>
  </div>
</div>
<!-- show success and unsuccess message -->
@if (session('success'))
<p class="alert alert-success text-center">{{ session('success') }}</p>
@endif
@if (session('unsuccess'))
<p class="alert alert-danger text-center">{{ session('unsuccess') }}</p>
@endif
<!-- End show success and unsuccess message -->
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="card">
      <div class="card-body">
        <div class="box-body">
          <div class="row">
            <div class="row">
              <input type="hidden" name="type" value="2" class="form-control mb-4">
              @foreach($employeeDetail as $empDetail)
              <div class="col-lg-4 col-md-6">
                <div class="mb-3" id="name">
                  <label class="fw-bold mb-0">Name <span style="color:red">*</span></label>
                  <input type="text" name="name" class="form-control mb-4" value="{{$empDetail->full_name}}" readonly="">
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="mb-3" id="employee_id">
                  <label class="fw-bold mb-0">Employee ID <span style="color:red">*</span></label>
                  <input type="hidden" name="employee_id" value="{{$empDetail->user_id}}" class="form-control mb-4" readonly="">
                  <input type="text" placeholder="{{$empDetail->employee_id}}" class="form-control mb-4" readonly="">
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                @foreach($department as $departmentDetail)
                <div class="mb-3" id="department_id">
                  <label class="fw-bold mb-0">Department <span style="color:red">*</span></label>
                  <input type="hidden" name="department_id" value="{{$departmentDetail->id}}" class="form-control mb-4" readonly="">
                  <input type="text" placeholder="{{$departmentDetail->name}}" class="form-control mb-4" readonly="">
                </div>
                @endforeach
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-6">
                <div class="mb-3">
                  @foreach($country as $countryDetail)
                  <label class="fw-bold mb-0">Country <span style="color:red">*</span></label>
                  <input type="hidden" name="country_id" value="{{$countryDetail->id}}" class="form-control mb-4" readonly="">
                  <input type="text" placeholder="{{$countryDetail->name}}" class="form-control mb-4" readonly="">
                  @endforeach
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="mb-3">
                  @foreach($state as $address)
                  <label class="fw-bold mb-0">State <span style="color:red">*</span></label>
                  <input type="hidden" name="state_id" value="{{$address->id}}" class="form-control mb-4">
                  <input type="text" placeholder="{{$address->name}}" class="form-control mb-4" readonly="">
                  @endforeach
                </div>
              </div>

              <div class="col-lg-4 col-md-6">
                <div class="mb-3">
                  @foreach($appraisalKra as $kraData)
                  <label class="fw-bold mb-0">Projects assigned <span style="color:red">*</span></label>
                  <input type="text" name="projects_assigned" value="{{$kraData['projects_assigned']}}" class="form-control mb-4" readonly="">
                  @endforeach
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-6">
                @foreach($appraiser as $appraiserDetail)
                <div class="mb-3" id="appraiser :">
                  <label class="fw-bold mb-0">Name Of Appraiser <span style="color:red">*</span></label>
                  <input type="hidden" name="appraiser_id" value="{{$appraiserDetail->id}}" class="form-control mb-4">
                  <input type="text" value="{{$appraiserDetail->full_name}}" class="form-control mb-4" readonly="">
                </div>
                @endforeach
              </div>
              <div class="col-lg-4 col-md-6">
                @foreach($reviewerDetail as $reviewer)
                <div class="mb-3" id="reviewer">
                  <label class="fw-bold mb-0">Name Of Reviewer <span style="color:red">*</span></label>
                  <input type="hidden" name="reviewer_id" value="{{$reviewer->user_id}}" class="form-control mb-4">
                  <input type="text" placeholder="{{$reviewer->full_name}}" class="form-control mb-4" readonly="">
                </div>
                @endforeach
              </div>
            </div>
            @endforeach
            <!-- Section 6: PERFORMANCE SCORE  -->
            <table class="table table-bordered border text-nowrap text-md-nowrap">
              <h3 class="bg-text">Section 6: PERFORMANCE SCORE</h3>
              <thead class="bg-primary">
                <tr>
                  <th class="text-white">BY APPRAISER</th>
                  <th class="text-white">SCROE [A] <br> (From Previous Sheets)</th>
                  <th class="text-white">WEIGHTAGE [B]</th>
                  <th class="text-white">FINAL<br>SCORE [a x b] / 100</th>
                </tr>
              </thead>
              <tbody>
                @foreach($performanceRecord as $performance)
                <tr>
                  <td class="align-middle">
                    <textarea class="form-control" cols="30" rows="2" readonly>{{$performance->by_appraiser}}</textarea>
                  </td>
                  <td class="align-middle">
                    <textarea name="score_performance[0]" class="form-control" id="total_ferformance_final_value" cols="30" rows="2" readonly>{{$performance->score}}</textarea>
                  </td>
                  <td class="align-middle">
                    <textarea name="performance_weightage[0]" class="form-control" cols="30" rows="2" readonly>{{$performance->weightage}}</textarea>
                  </td>
                  <td class="align-middle">
                    <textarea name="final_performance[0]" class="form-control" id="final_performance_competencies_weighted" cols="30" rows="2" readonly>{{$performance->final}}</textarea>
                  </td>
                </tr>
                @endforeach
                <tr>
                  <td class="align-middle" colspan="3">
                    <textarea class="form-control" cols="30" rows="2" readonly>OVERALL SCORE (Final Score of Performance Evaluation + Final Score of Competencies)</textarea><br>
                  </td>
                  @foreach($appraisalKra as $kraData)
                  <td class="align-middle">
                    <textarea name="total_performance_score" class="form-control" id="total_performance_score" cols="30" rows="2" readonly>{{$kraData['total_performance_score']}}</textarea><br>
                  </td>
                  @endforeach
                </tr>
              </tbody>
            </table>
            <h4> Rating </h4>
            @foreach($appraisalKra as $kraData)
            @if($kraData['total_performance_score'] <= '1' ) <p>Below Average/Poor. Did Not meet Expectations</p>
              @elseif($kraData['total_performance_score'] <= '2.5' && $kraData['total_performance_score']>= '1.5' )
                <p>Average. Met expectations sometimes only. Improvement needed.</p>
                @elseif($kraData['total_performance_score'] <= '3.5' && $kraData['total_performance_score']>= '2.5' )
                  <p>Good. Met expectations. Satisfactory</p>
                  @elseif($kraData['total_performance_score'] <= '4.5' && $kraData['total_performance_score']>= '3.5' )
                    <p>Very Good. Exceeded expectations. Achieved greater-than-expected results</p>
                    @elseif($kraData['total_performance_score'] <= '5' && $kraData['total_performance_score']>= '4.5' )
                      <p>Outstanding. Excellent, setting standard for others to follow</p>
                      @endif
                      @endforeach
                      <!-- end Section 5:PERFORMANCE SCORE -->
          </div>
        </div>
      </div>
    </div>

    <!-- /.content-wrapper ends here -->
    <script src="{!! asset('plugins/sweetalert/sweetalert.min.js') !!}"></script>

    <!-- Custom script starts here -->
    @section('script')

    @endsection
    <!-- Custom script ends here -->

    @endsection