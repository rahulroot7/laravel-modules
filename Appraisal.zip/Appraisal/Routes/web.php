<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('appraisal')->group(function () {
    Route::get('/create', 'AppraisalController@index');
    Route::get('/list', 'AppraisalController@kraEmployeeList');
    Route::post('/save', 'AppraisalController@store')->name('appraisal.save');
    Route::get('/employee-kra/{id}', 'AppraisalController@employeeKraCreate')->name('employee-kra');
    Route::get('/kra-filter', 'AppraisalController@KraCategoryFilter');
    Route::post('/kra-form-save', 'AppraisalController@kraFormStore')->name('appraisal-kra-form.save');
    Route::get('/template-edit/{id}', 'AppraisalController@templateEdit')->name('template.edit');
    Route::post('/template-update/{id}', 'AppraisalController@templateUpdate')->name('template.update');
    Route::get('/template-view/{id}', 'AppraisalController@view')->name('template.view');
    Route::get('/financial-year', 'AppraisalController@employeeFinancialyearListFilter');
    // employee kar form 
    Route::get('/response-list', 'AppraisalFormController@employeeResponselist');
    Route::get('/kra-form/{id}', 'AppraisalFormController@kraAppraisalForm')->name('kra-form');
    Route::post('/employee-kra-save', 'AppraisalFormController@create')->name('appraisal-employee-kra-form.save');
    Route::get('/employee-response', 'AppraisalFormController@employeeResponse');
    Route::get('/employee-appraisee-filter', 'AppraisalFormController@appraisalAppraiseeFilter');
    Route::get('/employee-reviewer-filter', 'AppraisalFormController@appraisalReviewerfilter');
    Route::get('/employee-appraiser-filter', 'AppraisalFormController@appraisalAppraiserfilter');
    Route::get('/employee-kra-response/{id}', 'AppraisalFormController@appraisalEmployeeForm')->name('employee-kra-response');
    Route::post('/appraiser-kra-update', 'AppraisalFormController@appraisalEmployeeFormUpdate')->name('appraisal-employee-form.update');
    Route::get('/employee-reviewer-response/{id}', 'AppraisalFormController@appraisalReviewerForm')->name('employee-reviewer-response');
    Route::post('/reviewer-kra-update', 'AppraisalFormController@appraisalReviewerFormUpdate')->name('appraisal-reviewer-form.update');
    Route::get('/performance-score/{id}', 'AppraisalFormController@performanceScore')->name('employee-performance-score');
    // Hr progress
    Route::get('/progress', 'AppraisalProgressController@Hrprogress');
    Route::get('/final-view/{id}', 'AppraisalProgressController@appraisalFinalView')->name('final-view');
    Route::get('/final-filter', 'AppraisalProgressController@finalFilter');
    Route::get('/generate-pdf/{id}', 'AppraisalProgressController@downloadPdf')->name('generate-pdf');
});
