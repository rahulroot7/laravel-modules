<?php

namespace Modules\Appraisal\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Modules\RolePermission\Entities\UserRole;
use Modules\RolePermission\Entities\Role;
use Modules\RolePermission\Entities\RolePermission;
use Modules\Appraisal\Entities\AppraisalEmployeeKra;

class AppraisalEmployeeKraPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function AppraiserRole(User $user)
    {
        $userRoleDetail = UserRole::where('user_id', $user->id)->get();
        foreach ($userRoleDetail as $userDetail) {
            $roleId = $userDetail->role_id;
            $roleDetail = Role::where('name', 'Appraiser')->where('id', $roleId)->get();
            foreach ($roleDetail as $roleData) {
                $userRoleId = $roleData->id;
            }
        }
        if (isset($userRoleId)) {
            $check =  RolePermission::where('role_id', $userRoleId)->where('permission_id', '2')->get();
            if ($check->count()) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    // access for reviewer
    public function ReviewerRole(User $user)
    {
        $userRoleDetail = UserRole::where('user_id', $user->id)->get();
        foreach ($userRoleDetail as $userDetail) {
            $roleId = $userDetail->role_id;
            $roleDetail = Role::where('name', 'Reviewer')->where('id', $roleId)->get();
            foreach ($roleDetail as $roleData) {
                $userRoleId = $roleData->id;
            }
        }
        if (isset($userRoleId)) {
            $check =  RolePermission::where('role_id', $userRoleId)->where('permission_id', '2')->get();
            if ($check->count()) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    // only access for head of HR
    public function HrRole(User $user)
    {
        $userRoleDetail = UserRole::where('user_id', $user->id)->get();
        foreach ($userRoleDetail as $userDetail) {
            $roleId = $userDetail->role_id;
            $roleDetail = Role::where('name', 'HR Appraisal')->where('id', $roleId)->get();
            foreach ($roleDetail as $roleData) {
                $userRoleId = $roleData->id;
            }
        }
        if (isset($userRoleId)) {
            $check =  RolePermission::where('role_id', $userRoleId)->where('permission_id', '1')->get();
            if ($check->count()) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}
