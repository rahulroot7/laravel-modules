<?php

namespace Modules\Appraisal\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Routing\Controller;
use App\Models\Employee;
use App\Models\EmployeeProfile;
use App\Models\LeaveAuthority;
use Modules\Master\Entities\Department;
use Modules\Appraisal\Entities\AppraisalKraTemplate;
use Modules\Appraisal\Services\AppraisalCreateService;
use Modules\Appraisal\Services\AppraisalTemplateListService;
use Modules\Appraisal\Entities\AppraisalEmployeeKraTemplate;
use Modules\RolePermission\Entities\UserRole;
use Modules\RolePermission\Entities\Role;
use Modules\RolePermission\Entities\RolePermission;
use PhpParser\Node\Expr\Print_;

class AppraisalController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $userId = Auth::id();
        $departmentHead = Employee::Where('user_id', $userId)->get(); //Department Head 
        $appraisalKraDetail = AppraisalKraTemplate::where('user_id', $userId)->get();
        foreach ($departmentHead as $emp) {
            $empId = $emp->id;
        }
        $empProfile = EmployeeProfile::Where('id', $empId)->get();
        foreach ($empProfile as $profile) {
            $departmentId = $profile->department_id;
        }
        $departments = Department::where('id', $departmentId)->get();
        return view('appraisal::appraisal.create', compact('departments', 'appraisalKraDetail'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('appraisal::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $message = AppraisalCreateService::createAppresailTemplate($request);
        if ($message == '200') {
            return redirect()->back()->with('success', 'Appraisal KRA save successfull');
        } elseif ($message == '401') {
            return redirect()->back()->with('CategoryExist', 'Category already exist !');
        } else {
            return redirect()->back()->with('unsuccess', 'Opps Something wrong!');
        }
    }

    /**
     * kraEmployeeList
     * show all employee of specific Department 
     * @return void
     */
    public function kraEmployeeList()
    {
        $logInUserId = Auth::id();
        $checkKRAassig = AppraisalEmployeeKraTemplate::Where('appraiser_id', $logInUserId)->get();
        foreach ($checkKRAassig as $detail) {
            $financialYear = $detail->financial_year;
        }
        $status = 'all';
        if ($checkKRAassig->count()) {
            $data = AppraisalEmployeeKraTemplate::Where('appraiser_id', $logInUserId)->where('financial_year', $financialYear)->get();
            $output = "";
            $count = 0;
            foreach ($data as $emp) {
                $assignUserId = $emp->appraisee_id;
                $DepartmentId = $emp->department_id;
                $emp_profile = Employee::Where('user_id', $assignUserId)->get();
                foreach ($emp_profile as $filterList) {
                    $user_id = $filterList->user_id;
                    $empId = $filterList->employee_id;
                    $name = $filterList->full_name;
                    $count++;
                    $output .= '<tr>' .
                        '<td>' . $count . '</td>' .
                        '<td class="align-middle">' . $empId . '</td>' .
                        '<td class="align-middle">' . $name . '</td>' .
                        ' <td>' .
                        '<a class="btn btn-success" href="javascript:void()">Assigned</a>' .
                        '</td>' .
                        '</tr>';
                }
            }
            foreach ($data as $emp) {
                $userId[] = $emp->appraisee_id;
                $DepartmentId = $emp->department_id;
            }
            // print_r($userId);
            // $projectId = config('appraisal.projectId');
            $projectId = ['1', '2', '18', '19', '121'];
            $query = DB::table('employees as emp')
                ->join('users as u', 'emp.user_id', '=', 'u.id')
                ->join('employee_profiles as empp', 'empp.employee_id', '=', 'emp.id')
                ->where(['empp.department_id' => [$DepartmentId]])
                ->where(['empp.project_id' => [$projectId]])
                ->where(['empp.is_active' => '1']);
            $employees = $query->select('u.*', 'emp.*')
                ->orderBy('emp.created_at', 'DESC')
                ->whereNotIn('emp.user_id', $userId)
                ->get();
            foreach ($employees as $filterList) {
                $user_id = $filterList->user_id;
                $empId = $filterList->employee_id;
                $name = $filterList->full_name;
                $count++;
                $output .= '<tr>' .
                    '<td>' . $count . '</td>' .
                    '<td class="align-middle">' . $empId . '</td>' .
                    '<td class="align-middle">' . ucwords($name) . '</td>' .
                    ' <td>' .
                    '<a class="btn btn-success" target="_blank" href="' . route('employee-kra', $user_id) . '">Assign KRA</a>' .
                    '</td>' .
                    '</tr>';
            }
            // only access for reviewer;
            $department = Department::get();
            $userRoleDetail = UserRole::where('user_id', $logInUserId)->get();
            foreach ($userRoleDetail as $userDetail) {
                $roleId = $userDetail->role_id;
                $roleDetail = Role::where('name', 'Reviewer')->where('id', $roleId)->get();
                foreach ($roleDetail as $roleData) {
                    $check = RolePermission::where('role_id', $roleData->id)->where('permission_id', '2')->get();
                    if ($check->count()) {
                        $hodData = LeaveAuthority::where('manager_id', $logInUserId)->where('priority', '2')->get();
                        foreach ($hodData as $key => $hodDetail) {
                            $hodUserId = $hodDetail->user_id;
                            if ($userId['0'] == $hodUserId) {
                            } else {
                                $employeeHod = Employee::Where('user_id', $hodUserId)->where('is_active', '1')->get();
                                foreach ($employeeHod as $employeeHodDetail) {
                                    $count++;
                                    $output .= '<tr>' .
                                        '<td>' . $count . '</td>' .
                                        '<td class="align-middle">' . $employeeHodDetail->employee_id . '</td>' .
                                        '<td class="align-middle">' . ucwords(
                                            $employeeHodDetail->full_name
                                        ) . '</td>' .
                                        ' <td>' .
                                        '<a class="btn btn-success" target="_blank" href="' . route('employee-kra', $employeeHodDetail->user_id) . '">Assign KRA</a>' .
                                        '</td>' .
                                        '</tr>';
                                }
                            }
                        }
                    }
                }
            }
            // end access for reviewer
            return view('appraisal::appraisal.employee_list', compact('output'));
        } else {
            $userId = Auth::id();
            $employee = Employee::Where('user_id', $userId)->get();
            foreach ($employee as $emp) {
                $empId = $emp->id;
            }
            $empProfile = EmployeeProfile::Where('id', $empId)->get();
            foreach ($empProfile as $profile) {
                $departmentId = $profile->department_id;
            }
            // only access for reviewer
            $userRoleDetail = UserRole::where('user_id', $logInUserId)->get();
            foreach ($userRoleDetail as $userDetail) {
                $roleId = $userDetail->role_id;
                $roleDetail = Role::where('name', 'Reviewer')->where('id', $roleId)->get();
                foreach ($roleDetail as $roleData) {
                    $check = RolePermission::where('role_id', $roleData->id)->where('permission_id', '2')->get();
                    if ($check->count()) {
                        $hodData = LeaveAuthority::where('manager_id', $logInUserId)->where('priority', '2')->get();
                        foreach ($hodData as $hodDetail) {
                            $hodUserId = $hodDetail->user_id;
                            $employeeHod[] = Employee::Where('user_id', $hodUserId)->get()->toArray();
                        }
                    }
                }
            }
            // end access for reviewer
            if ($roleDetail->count()) {
                $projectId = ['1', '2', '18', '19', '121'];
                $query = DB::table('employees as emp')
                    ->join('users as u', 'emp.user_id', '=', 'u.id')
                    ->join('employee_profiles as empp', 'empp.employee_id', '=', 'emp.id')
                    ->where(['empp.department_id' => [$departmentId]])
                    ->where(['empp.project_id' => [$projectId]])
                    ->where(['empp.is_active' => '1']);
                $employees = $query->select('u.*', 'emp.*')
                    ->orderBy('emp.created_at', 'DESC')
                    ->get();
                return view('appraisal::appraisal.employee_list', compact('employees', 'employeeHod'));
            } else {
                $projectId = ['1', '2', '18', '19', '121'];
                $query = DB::table('employees as emp')
                    ->join('users as u', 'emp.user_id', '=', 'u.id')
                    ->join('employee_profiles as empp', 'empp.employee_id', '=', 'emp.id')
                    ->where(['empp.department_id' => [$departmentId]])
                    ->where(['empp.project_id' => [$projectId]])
                    ->where(['empp.is_active' => '1']);
                $employees = $query->select('u.*', 'emp.*')
                    ->orderBy('emp.created_at', 'DESC')
                    ->get();
                return view('appraisal::appraisal.employee_list', compact('employees'));
            }
        }
    }

    /**
     * AppraisalEmployeeFilter
     *
     * @param  mixed $request
     * @return void
     */
    /**
     * employeeKraCreate
     *
     * @return void
     */
    public function employeeKraCreate($id)
    {

        $userId = Auth::id();
        $departmentHead = Employee::Where('user_id', $userId)->get(); //Department Head 
        foreach ($departmentHead as $emp) {
            $empId = $emp->id;
        }
        $emp_profile = EmployeeProfile::Where('id', $empId)->get();
        foreach ($emp_profile as $profile) {
            $departmentId = $profile->department_id;
        }
        $employeeDetail = Employee::Where('user_id', $id)->get(); //employee id 
        $department = Department::where('id', $departmentId)->get();
        $kraList = AppraisalKraTemplate::with('AppraisalKraDetail')->where('department_id',  $departmentId)->get()->toArray();
        $reviewerData = LeaveAuthority::where('user_id', $userId)->where('priority', '4')->get();
        foreach ($reviewerData as $reviewer) {
            $reviewerId = $reviewer['manager_id'];
        }
        $reviewerDetail = Employee::where('user_id', $reviewerId)->get();
        // print_r($reviewerDetail);
        // die;
        return view('appraisal::appraisal.create_employee_kra', compact('kraList', 'department', 'employeeDetail', 'reviewerDetail'));
    }

    /**
     * KraCategoryFilter
     * filter kra list data by category 
     * @param  mixed $request
     * @return void
     */
    public function KraCategoryFilter(Request $request)
    {
        $output = AppraisalTemplateListService::KraCategoryFilterList($request);
        if ($output) {
            return Response($output);
        } else {
            return redirect()->back()->with('unsuccess', 'Opps Something wrong!');
        }
    }

    /**
     * kraFormStore
     * store kra list data.
     * @param  mixed $request
     * @return void
     */
    public function kraFormStore(Request $request)
    {
        $appraisee_id = $request->appraisee_id;
        $message = AppraisalTemplateListService::kraEmployeeFormStore($request, $appraisee_id);
        if ($message == '200') {
            return redirect('appraisal/list')->with('success', 'KRA Assign successfull');
        } else {
            return redirect()->back()->with('unsuccess', 'KRA Already Assigned this year !');
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function view($id)
    {
        $userId = Auth::id();
        $departmentHead = Employee::Where('user_id', $userId)->get(); //Department Head 
        $appraisalKraDetail = AppraisalKraTemplate::with('AppraisalKraDetail')
            ->where('user_id', $userId)->where('id', $id)->get();
        foreach ($departmentHead as $emp) {
            $empId = $emp->id;
        }
        $empProfile = EmployeeProfile::Where('id', $empId)->get();
        foreach ($empProfile as $profile) {
            $departmentId = $profile->department_id;
        }
        $departments = Department::where('id', $departmentId)->get();
        return view('appraisal::appraisal.template_view', compact('departments', 'appraisalKraDetail'));
    }

    /**
     * templateEdit
     *
     * @param  mixed $id
     * @return void
     */
    public function templateEdit($id)
    {
        $userId = Auth::id();
        $departmentHead = Employee::Where('user_id', $userId)->get(); //Department Head 
        $appraisalKraDetail = AppraisalKraTemplate::with('AppraisalKraDetail')
            ->where('user_id', $userId)->where('id', $id)->get();
        foreach ($departmentHead as $emp) {
            $empId = $emp->id;
        }
        $empProfile = EmployeeProfile::Where('id', $empId)->get();
        foreach ($empProfile as $profile) {
            $departmentId = $profile->department_id;
        }
        $departments = Department::where('id', $departmentId)->get();
        return view('appraisal::appraisal.template_edit', compact('departments', 'appraisalKraDetail'));
    }

    /**
     * templateUpdate
     *
     * @return void
     */
    public function templateUpdate(Request $request, $id)
    {
        // print_r($request->all());
        // die;
        $message = AppraisalCreateService::updateAppresailTemplate($request, $id);
        if ($message == '200') {
            return redirect()->back()->with('success', 'Appraisal KRA update successfull');
        } else {
            return redirect()->back()->with('unsuccess', 'Opps Something wrong!');
        }
    }

    /**
     * employeeFinancialyearListFilter
     *
     * @param  mixed $request
     * @return void
     */
    public function employeeFinancialyearListFilter(Request $request)
    {
        $output = AppraisalTemplateListService::financialYearFilterList($request);
        if ($output) {
            return Response($output);
        }
    }
}
