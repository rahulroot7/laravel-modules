<?php

namespace Modules\Appraisal\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Appraisal\Entities\AppraisalEmployeeKraTemplate;
use Modules\Appraisal\Entities\AppraisalEmployeeKraDetail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Employee;
use App\Models\EmployeeProfile;
use App\Models\EmployeeAddress;
use App\Models\LeaveAuthority;
use Modules\Master\Entities\Department;
use Modules\Master\Entities\Country;
use Modules\Master\Entities\State;
use Modules\Master\Entities\Designation;
use Modules\Appraisal\Entities\AppraisalTracker;
use Modules\Appraisal\Entities\AppraisalEmployeeKra;
use Modules\Appraisal\Entities\AppraisalComment;
use Modules\Appraisal\Entities\AppraisalStrengthLimitation;
use Modules\Appraisal\Entities\AppraisalCompetencies;
use Modules\Appraisal\Entities\AppraisalTrainingIdentification;
use Modules\Appraisal\Entities\AppraisalStrengthImprovement;
use Modules\Appraisal\Entities\AppraisalPerformanceDialogue;
use Modules\Appraisal\Entities\AppraisalPerformanceScore;
use Modules\Appraisal\Entities\AppraisalRecordCompentencies;

class AppraisalFormController extends Controller
{

    public function employeeResponselist()
    {
        $userId = Auth::id();
        $appraiserList = AppraisalTracker::where('user_id', $userId)->orWhere('reviewer_id', $userId)->get();
        $appraiserTeamplate = AppraisalEmployeeKraTemplate::with('AppraisalKraId')->where('appraisee_id', $userId)->get()->toArray();
        foreach ($appraiserTeamplate as $list) {
            $employeeId = $list['appraisee_id'];
            $kraEmployee = Employee::where('user_id', $employeeId)->get();
            $kraEmployeeList[] = array(
                "name" => $kraEmployee[0]->full_name,
                "employee_id" => $kraEmployee[0]->employee_id,
                "user_id" => $kraEmployee[0]->user_id,
            );
        }
        // print_r($appraiserTeamplate);
        // die;
        return view('appraisal::appraisal.Form.empolyee_appraisal_list', compact('kraEmployeeList', 'appraiserList', 'appraiserTeamplate'));
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function kraAppraisalForm($id)
    {
        $userId = Auth::id();
        $checkFormStatus = AppraisalTracker::where('kra_id', $id)->get()->toArray();
        $employeeDetail = Employee::where('user_id', $userId)->get();
        foreach ($employeeDetail as $empList) {
            $countryId = $empList->country_id;
            $employeeId = $empList->id;
        }
        $employeeKraData = AppraisalEmployeeKraTemplate::with('employeeKraDetail')->where('id', $id)->get()->toArray();
        foreach ($employeeKraData as $empKraList) {
            $departnameId = $empKraList['department_id'];
            $appraiserId = $empKraList['appraiser_id'];
        }
        $appraisalKra = AppraisalTracker::with('employeeKraDetail')
            ->with('commentDetail')
            ->with('strengthLimitationDetail')
            ->with('appraisalCompetenciesDetail')
            ->with('appraisalTrainingDetail')
            ->where('kra_id', $id)->get()->toArray();

        $employeeProfile = EmployeeProfile::where('employee_id', $employeeId)->get();
        foreach ($employeeProfile as $profileDetail) {
            $designationId = $profileDetail->designation_id;
        }

        $designationData = Designation::where('id', $designationId)->get();
        foreach ($designationData as $designationDetail) {
            $bandId = $designationDetail->band_id;
        }

        $compentenciesBand = AppraisalRecordCompentencies::where('band_id', $bandId)->get()->toArray();
        // print_r($employeeId);
        // die;

        $employeeAddress = EmployeeAddress::where('employee_id', $employeeId)->get();
        foreach ($employeeAddress as $address) {
            $stateId = $address->state_id;
        }
        $department = Department::where('id', $departnameId)->get();
        $appraiser = Employee::where('user_id', $appraiserId)->get();
        $country = Country::where('id', $countryId)->get();
        $state = State::where('id', $stateId)->get();
        return view('appraisal::appraisal.Form.kra_create', compact('employeeKraData', 'employeeDetail', 'department', 'appraiser', 'country', 'state', 'checkFormStatus', 'appraisalKra', 'compentenciesBand'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create(Request $request)
    {
        // print_r($request->kra_id);
        // die;

        $AppraisalTrakerId = AppraisalTracker::create(
            [
                'user_id'    => $request->employee_id,
                'department_id' => $request->department_id,
                'country_id'      =>  $request->country_id,
                'state_id'      =>  $request->state_id,
                'appraiser_id'      =>  $request->appraiser_id,
                'type' => $request->type,
                'kra_id' => $request->kra_id,
                'total_weightage' => $request->total_weightage,
                'total_weighted_score' => $request->appraisee_total_weightage,
                'competencies_self_total' => $request->total_self,
            ]
        )->id;

        foreach ($request->kra as $key => $employeeKRA) {
            $task = new AppraisalEmployeeKra();
            $task->appraisal_tracker_id = $AppraisalTrakerId;
            $task->kra = $request->kra[$key];
            $task->target = $request->target[$key];
            $task->weightage = $request->weightage[$key];
            $task->achievement = $request->achievement[$key];
            $task->score_by_appraisee = $request->score_by_appraisee[$key];
            $task->weighted_score = $request->weighted_score[$key];
            $task->save();
        }

        // save comment
        if (isset($request->appraisee_comment)) {
            $task = new AppraisalComment();
            $task->appraisal_tracker_id = $AppraisalTrakerId;
            $task->user_id = $request->employee_id;
            $task->comment = $request->appraisee_comment;
            $task->save();
        }
        // save FACILITATING and HINDERING
        foreach ($request->facilitating as $key => $limitation) {
            $task = new AppraisalStrengthLimitation();
            $task->appraisal_tracker_id = $AppraisalTrakerId;
            $task->facilitating = $request->facilitating[$key];
            $task->hindering = $request->hindering[$key];
            $task->save();
        }
        //   save COMPETENCIES REVIEW
        foreach ($request->factors as $key => $facror) {
            $task = new AppraisalCompetencies();
            $task->appraisal_tracker_id = $AppraisalTrakerId;
            $task->factors = $request->factors[$key];
            $task->self = $request->self[$key];
            $task->save();
        }
        foreach ($request->factors_fixed as $key => $fixed) {
            if (isset($fixed['is_active'])) {
                $task = new AppraisalCompetencies();
                $task->appraisal_tracker_id = $AppraisalTrakerId;
                $task->factors = $fixed['factor_id'];
                $task->self = $fixed['score'];
                $task->save();
            }
        }
        //   save TRAINING NEEDS IDENTIFICATION
        if (isset($request->appraisee_training_area['0'])) {
            foreach ($request->appraisee_training_area as $key => $training) {
                $task = new AppraisalTrainingIdentification();
                $task->appraisal_tracker_id = $AppraisalTrakerId;
                $task->traning_type = $request->training[$key];
                $task->suggested_by_appraisee = $request->appraisee_training_area[$key];
                $task->save();
            }
        }
        if ($task->save()) {
            return redirect()->back()->with('success', 'Data save successfull');
        } else {
            return redirect()->back()->with('unsuccess', 'Opps Something wrong!');
        }
    }


    /**
     * employeeResponse
     *
     * @param  mixed $request
     * @return void
     */
    public function employeeResponse(Request $request)
    {

        $userId = Auth::id();
        $appraiserList = AppraisalTracker::where('appraiser_id', $userId)->orWhere('reviewer_id', $userId)->get();
        if ($appraiserList->count()) {
            foreach ($appraiserList as $list) {
                $employeeId = $list->user_id;
                $kraEmployee = Employee::where('user_id', $employeeId)->get();
                $kraEmployeeList[] = array(
                    "name" => $kraEmployee[0]->full_name,
                    "employee_id" => $kraEmployee[0]->employee_id,
                    "user_id" => $kraEmployee[0]->user_id,
                );
            }
            $department = Department::get();
            return view('appraisal::appraisal.Form.employee_response_list', compact('kraEmployeeList', 'appraiserList', 'department'));
        } else {
            return redirect('appraisal/list')->with('unsuccess', 'No Response Data !');
        }
    }

    public function appraisalAppraiseeFilter(Request $request)
    {
        $userId = Auth::id();
        $output = "";
        $count = 0;
        $appraiserTeamplate = AppraisalEmployeeKraTemplate::with('AppraisalKraId')->where('appraisee_id', $userId)->where('financial_year', $request->financial)->get()->toArray();
        foreach ($appraiserTeamplate as $list) {
            $employeeId = $list['appraisee_id'];
            $kraEmployee = Employee::where('user_id', $employeeId)->get();
            $kraEmployeeList[] = array(
                "name" => $kraEmployee[0]->full_name,
                "employee_id" => $kraEmployee[0]->employee_id,
                "user_id" => $kraEmployee[0]->user_id,
            );
        }
        if (isset($kraEmployeeList)) {
            foreach ($appraiserTeamplate as $key => $kraTemplate) {
                foreach ($kraTemplate['appraisal_kra_id'] as $trakerData) {
                    foreach ($kraEmployeeList as $key => $empolyee) {
                        $count++;
                        $output .= '<tr>' .
                            '<td>' . $count . '</td>' .
                            '<td class="align-middle">' . $kraEmployeeList[$key]['employee_id'] . '</td>' .
                            '<td class="align-middle">' . $kraEmployeeList[$key]['name'] . '</td>' .
                            '<td class="align-middle">' .
                            '<div class="d-flex justify-content-between align-items-center process_bg mx-3">';
                        if ($trakerData['type'] == '1') {
                            $output .= '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle steps-sucess rounded"></div>' .
                                '<span>Appraisee</span>' .
                                '</div>' .
                                '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle bg-warning rounded"></div>' .
                                '<span>Appraiser</span>' .
                                '</div>' .
                                '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle bg-warning rounded"></div>' .
                                '<span>Reveiwer</span>' .
                                '</div>';
                        }
                        if ($trakerData['type'] == '2') {
                            $output .= '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle steps-sucess rounded"></div>' .
                                '<span>Appraisee</span>' .
                                '</div>' .
                                '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle steps-sucess rounded"></div>' .
                                '<span>Appraiser</span>' .
                                '</div>' .
                                '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle bg-warning rounded"></div>' .
                                '<span>Reveiwer</span>' .
                                '</div>';
                        }
                        if ($trakerData['type'] == '3') {
                            $output .= '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle steps-sucess rounded"></div>' .
                                '<span>Appraisee</span>' .
                                '</div>' .
                                '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle steps-sucess rounded"></div>' .
                                '<span>Appraiser</span>' .
                                '</div>' .
                                '<div class="d-flex flex-column align-items-center">' .
                                '<div class="process_bar_circle steps-sucess rounded"></div>' .
                                '<span>Reveiwer</span>' .
                                '</div>';
                        }
                        $output .= '</div>' .
                            '</td>' .
                            '<td>' .
                            ' <div class="progress-bg">' .
                            '</div>' .
                            '<progress class="progress-bar" id="file" value="' . $trakerData['total_performance_score'] . '" max="5"></progress>' .
                            '<p class="performance-score">' . $trakerData['total_performance_score'] . '/5</p>';
                        if ($trakerData['total_performance_score'] <= '1') {
                            $output .= '<b>Below Average<b><i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Below Average/Poor. Did Not meet Expectations." aria-hidden="true"></i>';
                        } elseif ($trakerData['total_performance_score'] <= '2.5' && $trakerData['total_performance_score'] >= '1.5') {
                            $output .= '<b>Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Average. Met expectations sometimes only. Improvement needed." aria-hidden="true"></i>';
                        } elseif ($trakerData['total_performance_score'] <= '3.5' && $trakerData['total_performance_score'] >= '2.5') {
                            $output .= ' <b>Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Good. Met expectations. Satisfactory." aria-hidden="true"></i>';
                        } elseif ($trakerData['total_performance_score'] <= '4.5' && $trakerData['total_performance_score'] >= '3.5') {
                            $output .= ' <b>Very Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Very Good. Exceeded expectations. Achieved greater-than-expected results." aria-hidden="true"></i>';
                        } elseif ($trakerData['total_performance_score'] <= '5' && $trakerData['total_performance_score'] >= '4.5') {
                            $output .= ' <b>Outstanding<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Outstanding. Excellent, setting standard for others to follow." aria-hidden="true"></i>';
                        }
                        $output .= '</td>';

                        // filter for appraiser
                        foreach ($kraTemplate['appraisal_kra_id'] as $kraFinal) {
                            if ($kraEmployeeList[$key]['user_id'] == $kraTemplate['appraisee_id'] && $kraFinal['type'] == '3') {
                                $output .= '<td>' .
                                    '<a class="btn btn-success" target="_blank" href="' . route('kra-form', $kraTemplate['id']) . '">Final View</a><br><br> ' .
                                    '<a class="btn btn-success" target="_blank" href="' . route('employee-performance-score', $kraTemplate['id']) . '">View Performance Score</a>' .
                                    '</td>';
                            }
                            if ($kraEmployeeList[$key]['user_id'] == $kraTemplate['appraisee_id'] && $kraFinal['type'] < '3') {
                                $output .= '<td>' .
                                    '<a class="btn btn-success" target="_blank" href="' . route('kra-form', $kraTemplate['id']) . '">Add Review</a>' .
                                    '</td>';
                            }
                        }
                        if (empty($kraTemplate['appraisal_kra_id'])) {
                            $output .= '<td>' .
                                '<a class="btn btn-success" target="_blank" href="' . route('kra-form', $kraTemplate['id']) . '">Add Review</a>' .
                                '</td>';
                        }

                        $output .= '</tr>';
                    }
                }
            }
        }
        return $output;
    }

    /**
     * appraisalResponsefilter filter for Reviewer
     *
     * @return void
     */
    public function appraisalReviewerfilter(Request $request)
    {
        $userId = Auth::id();
        $output = "";
        $count = 0;
        $appraiserTeamplate = DB::table('appraisal_trackers')
            ->join('appraisal_employee_kra_templates', 'appraisal_employee_kra_templates.id', '=', 'appraisal_trackers.kra_id')
            ->join('employees', 'employees.user_id', '=', 'appraisal_trackers.user_id')
            ->where(['appraisal_trackers.department_id' => [$request->department]])
            ->where(['appraisal_trackers.type' => [$request->status]])
            ->where(['appraisal_employee_kra_templates.financial_year' => [$request->financial]])
            ->select('appraisal_trackers.*', 'appraisal_employee_kra_templates.*', 'employees.*')
            ->get()->toArray();
        if (isset($appraiserTeamplate)) {
            foreach ($appraiserTeamplate as $key => $kraTemplate) {
                $count++;
                $output .= '<tr>' .
                    '<td>' . $count . '</td>' .
                    '<td class="align-middle">' . $kraTemplate->employee_id . '</td>' .
                    '<td class="align-middle">' . $kraTemplate->full_name . '</td>' .
                    '<td class="align-middle">' .
                    '<div class="d-flex justify-content-between align-items-center process_bg mx-3">';
                if ($kraTemplate->type == '1') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }
                if ($kraTemplate->type == '2') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }
                if ($kraTemplate->type == '3') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }

                $output .= '</div>' .
                    '</td>' .
                    '<td>' .
                    ' <div class="progress-bg">' .
                    '</div>' .
                    '<progress class="progress-bar" id="file" value="' . $kraTemplate->total_performance_score . '" max="5"></progress>' .
                    '<p class="performance-score">' . $kraTemplate->total_performance_score . '/5</p>';
                if ($kraTemplate->total_performance_score <= '1') {
                    $output .= '<b>Below Average<b><i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Below Average/Poor. Did Not meet Expectations." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '2.5' && $kraTemplate->total_performance_score >= '1.5') {
                    $output .= '<b>Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Average. Met expectations sometimes only. Improvement needed." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '3.5' && $kraTemplate->total_performance_score >= '2.5') {
                    $output .= ' <b>Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Good. Met expectations. Satisfactory." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '4.5' && $kraTemplate->total_performance_score >= '3.5') {
                    $output .= ' <b>Very Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Very Good. Exceeded expectations. Achieved greater-than-expected results." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '5' && $kraTemplate->total_performance_score >= '4.5') {
                    $output .= ' <b>Outstanding<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Outstanding. Excellent, setting standard for others to follow." aria-hidden="true"></i>';
                }
                $output .= '</td>';

                // '<td class="align-middle">' . $kraTemplate->financial_year . '</td>';
                // print_r($kraTemplate);
                // die;
                // filter for appraiser
                if ($kraTemplate->user_id == $kraTemplate->user_id && $kraTemplate->type == '3') {
                    $output .= '<td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-reviewer-response', $kraTemplate->kra_id) . '">Final View</a><br><br> ' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-performance-score', $kraTemplate->kra_id) . '">View Performance Score</a>' .
                        '</td>';
                }
                if ($kraTemplate->user_id == $kraTemplate->user_id && $kraTemplate->type < '3') {
                    $output .= '<td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-reviewer-response', $kraTemplate->kra_id) . '">Add Review</a>' .
                        '</td>';
                }
                // if ($kraTemplate->user_id == $kraTemplate->user_id && $kraTemplate->type == '1') {
                //     $output .= '<td>' .
                //         '<a class="btn btn-success bg-warning " href="javascript:void()">Process</a>' .
                //         '</td>';
                // }

                $output .= '</tr>';
            }
        }

        return $output;
    }


    /**
     * appraisalAppraiserfilter
     * filter for appraiser 
     * @param  mixed $request
     * @return void
     */
    public function appraisalAppraiserfilter(Request $request)
    {

        $userId = Auth::id();
        $output = "";
        $count = 0;

        $employee = Employee::Where('user_id', $userId)->get();
        foreach ($employee as $emp) {
            $empId = $emp->id;
        }
        $empProfile = EmployeeProfile::Where('id', $empId)->get();
        foreach ($empProfile as $profile) {
            $departmentId = $profile->department_id;
        }

        $appraiserTeamplate = DB::table('appraisal_trackers')
            ->join('appraisal_employee_kra_templates', 'appraisal_employee_kra_templates.id', '=', 'appraisal_trackers.kra_id')
            ->join('employees', 'employees.user_id', '=', 'appraisal_trackers.user_id')
            ->where(['appraisal_trackers.type' => [$request->status]])
            ->where(['appraisal_trackers.department_id' => [$departmentId]])
            ->where(['appraisal_employee_kra_templates.financial_year' => [$request->financial]])
            ->select('appraisal_trackers.*', 'appraisal_employee_kra_templates.*', 'employees.*')
            ->get()->toArray();

        if (isset($appraiserTeamplate)) {
            foreach ($appraiserTeamplate as $key => $kraTemplate) {
                $count++;
                $output .= '<tr>' .
                    '<td>' . $count . '</td>' .
                    '<td class="align-middle">' . $kraTemplate->employee_id . '</td>' .
                    '<td class="align-middle">' . $kraTemplate->full_name . '</td>' .
                    '<td class="align-middle">' .
                    '<div class="d-flex justify-content-between align-items-center process_bg mx-3">';
                if ($kraTemplate->type == '1') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }
                if ($kraTemplate->type == '2') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }
                if ($kraTemplate->type == '3') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }

                $output .= '</div>' .
                    '</td>' .
                    '<td>' .
                    ' <div class="progress-bg">' .
                    '</div>' .
                    '<progress class="progress-bar" id="file" value="' . $kraTemplate->total_performance_score . '" max="5"></progress>' .
                    '<p class="performance-score">' . $kraTemplate->total_performance_score . '/5</p>';
                if ($kraTemplate->total_performance_score <= '1') {
                    $output .= '<b>Below Average<b><i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Below Average/Poor. Did Not meet Expectations." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '2.5' && $kraTemplate->total_performance_score >= '1.5') {
                    $output .= '<b>Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Average. Met expectations sometimes only. Improvement needed." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '3.5' && $kraTemplate->total_performance_score >= '2.5') {
                    $output .= ' <b>Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Good. Met expectations. Satisfactory." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '4.5' && $kraTemplate->total_performance_score >= '3.5') {
                    $output .= ' <b>Very Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Very Good. Exceeded expectations. Achieved greater-than-expected results." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '5' && $kraTemplate->total_performance_score >= '4.5') {
                    $output .= ' <b>Outstanding<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Outstanding. Excellent, setting standard for others to follow." aria-hidden="true"></i>';
                }
                $output .= '</td>';

                // filter for appraiser
                if ($kraTemplate->user_id == $kraTemplate->appraisee_id && $kraTemplate->type == '3') {
                    $output .= '<td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-kra-response', $kraTemplate->kra_id) . '">Final View</a><br><br>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-performance-score', $kraTemplate->kra_id) . '">View Performance Score</a>' .
                        '</td>';
                }
                if ($kraTemplate->user_id == $kraTemplate->appraisee_id && $kraTemplate->type < '3') {
                    $output .= '<td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-kra-response', $kraTemplate->kra_id) . '">Add Review</a>' .
                        '</td>';
                }
                $output .= '</tr>';
            }
        }
        return $output;
    }


    /**
     * appraisalEmployeeForm
     *
     * @param  mixed $id
     * @return void
     */
    public function appraisalEmployeeForm($id)
    {
        $employeeData = AppraisalTracker::where('kra_id', $id)->get();
        foreach ($employeeData as $empDetail) {
            $userId = $empDetail->user_id;
        }
        $employeeDetail = Employee::where('user_id', $userId)->get();
        $appraisalKra = AppraisalTracker::with('employeeKraDetail')
            ->with('appraisalCompetenciesDetail')
            ->with('appraisalTrainingDetail')
            ->with('commentDetail')
            ->with('strengthLimitationDetail')
            ->with('strengthImprovementDetail')
            ->where(['kra_id' => [$id]])
            ->get()->toArray();
        foreach ($appraisalKra as $empList) {
            $countryId = $empList['country_id'];
            $stateId = $empList['state_id'];
            $departnameId = $empList['department_id'];
            $appraiserId = $empList['appraiser_id'];
            $trakerId = $empList['id'];
        }
        $department = Department::where('id', $departnameId)->get();
        $appraiser = Employee::where('user_id', $appraiserId)->get();
        $country = Country::where('id', $countryId)->get();
        $state = State::where('id', $stateId)->get();
        // $checkFormStatus = AppraisalTracker::where('appraiser_id',$appraiser_id)->get()->toArray();
        $reviewerData = LeaveAuthority::where('user_id', $appraiserId)->where('priority', '4')->get();
        foreach ($reviewerData as $reviewer) {
            $reviewerId = $reviewer['manager_id'];
        }
        $dialogue = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Appraiser')->get();
        $reviewerDetail = Employee::where('user_id', $reviewerId)->get();
        return view('appraisal::appraisal.Form.show_employee_form', compact('appraisalKra', 'employeeDetail', 'department', 'appraiser', 'country', 'state', 'reviewerDetail', 'dialogue'));
    }


    /**
     * appraisalEmployeeFormUpdate
     * update appraser and reviewer Form 
     * @param  mixed $id
     * @return void
     */
    public function appraisalEmployeeFormUpdate(Request $request)
    {
        $AppraisalTrakerId = AppraisalTracker::where('kra_id', $request->kra_id)->update([
            'department_id' => $request->department_id,
            'country_id'      =>  $request->country_id,
            'state_id'      =>  $request->state_id,
            'reviewer_id'  => $request->reviewer_id,
            'projects_assigned'      =>  $request->projects_assigned,
            'appraiser_id'      =>  $request->appraiser_id,
            'type' => $request->type,
            'total_weightage' => $request->total_weightage,
            'total_weighted_score' => $request->appraisee_total_weightage,
            'total_appraiser_weighted_score' => $request->appraiser_total_weightage,
            'competencies_appraiser_total' => $request->total_appraiser,
        ]);
        $trakerId = AppraisalTracker::where('user_id', $request->employee_id)->get();
        foreach ($trakerId as $employeeTraker) {
            $employeeTrakerId = $employeeTraker->id;
        }
        $kraDetail = AppraisalEmployeeKra::where('appraisal_tracker_id', $employeeTrakerId)->get();

        foreach ($kraDetail as $i => $data) {
            $AppraisalUpdate = AppraisalEmployeeKra::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $data->id)->update([
                'kra' => $request->kra[$i],
                'target' => $request->target[$i],
                'weightage' => $request->weightage[$i],
                'achievement' => $request->achievement[$i],
                'remark' => $request->remark[$i],
                'score_by_appraisee' => $request->score_by_appraisee[$i],
                'weighted_score' => $request->weighted_score[$i],
                'score_by_appraiser' => $request->score_by_appraiser[$i],
                'appraiser_weighted_score' => $request->appraiser_weighted_score[$i],
            ]);
        }

        // update appraiser comment
        $commentDetail = AppraisalComment::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($commentDetail as $i => $commentData) {
            $AppraisalUpdate = AppraisalComment::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $commentData->id)->update([
                'appraiser_comment' => $request->appraiser_comment,
            ]);
        }

        // update COMPETENCIES REVIEW
        $competenciesDetail = AppraisalCompetencies::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($competenciesDetail as $i => $competenciesData) {
            $AppraisalUpdate = AppraisalCompetencies::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $competenciesData->id)->update([
                'appraiser' => $request->appraiser[$i],
            ]);
        }

        // update and save SPECIFIC STRENGTHS / AREAS OF IMPROVEMENT OF THE EMPLOYEE          
        $improvementDetail = AppraisalStrengthImprovement::where('appraisal_tracker_id', $employeeTrakerId)->get();
        if ($improvementDetail->count()) {
            foreach ($improvementDetail as $key => $improvementData) {
                $trakerId = $improvementData->id;
                $AppraisalUpdate = AppraisalStrengthImprovement::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $trakerId)->update([
                    'area_of_strength' => $request->area_strength[$key],
                    'area_of_improvement' => $request->area_improvement[$key],
                ]);
            }
        } else {
            foreach ($request->area_strength as $key => $compentenciesData) {
                $task = new AppraisalStrengthImprovement();
                $task->appraisal_tracker_id = $employeeTrakerId;
                $task->area_of_strength = $request->area_strength[$key];
                $task->area_of_improvement = $request->area_improvement[$key];
                $task->save();
            }
        }
        // update  and save  PERFORMANCE DIALOGUE
        $trakerId = '';
        $DialogueDetail = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($DialogueDetail as $i => $DialogueData) {
            $trakerId = $DialogueData->appraisal_tracker_id;
        }
        if ($trakerId == $employeeTrakerId) {
            $AppraisalUpdate = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $trakerId)->update([
                'sign_type' => $request->performance_appraiser_sign,
                'comment' => $request->performance_appraiser_comment,
            ]);
        } else {
            $task = new AppraisalPerformanceDialogue();
            $task->appraisal_tracker_id = $employeeTrakerId;
            $task->sign_type = $request->performance_appraiser_sign;
            $task->comment = $request->performance_appraiser_comment;
            $task->save();
        }

        // update TRAINING NEEDS IDENTIFICATION
        $TrainingDetail = AppraisalTrainingIdentification::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($TrainingDetail as $i => $TrainingData) {
            $AppraisalUpdate = AppraisalTrainingIdentification::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $TrainingData->id)->update([
                'recommended_by_appraiser' => $request->appraiser_msg[$i],
            ]);
        }

        if ($AppraisalUpdate) {
            return redirect()->back()->with('success', 'Data save successfull');
        } else {
            return redirect()->back()->with('unsuccess', 'Opps Something wrong!');
        }
    }


    /**
     * appraisalReviewerForm
     *
     * @param  mixed $request
     * @param  mixed $id
     * @return void
     */
    public function appraisalReviewerForm(Request $request, $id)
    {
        $employeeData = AppraisalTracker::where('kra_id', $id)->get();
        foreach ($employeeData as $empDetail) {
            $userId = $empDetail->user_id;
        }
        $employeeDetail = Employee::where('user_id', $userId)->get();
        $appraisalKra = AppraisalTracker::with('employeeKraDetail')
            ->with('appraisalCompetenciesDetail')
            ->with('appraisalTrainingDetail')
            ->with('commentDetail')
            ->with('strengthLimitationDetail')
            ->with('strengthImprovementDetail')
            ->with('performanceDialogueDetail')
            ->where(['kra_id' => [$id]])
            ->get()->toArray();
        foreach ($appraisalKra as $empList) {
            $country_id = $empList['country_id'];
            $state_id = $empList['state_id'];
            $departname_id = $empList['department_id'];
            $appraiser_id = $empList['appraiser_id'];
            $trakerId = $empList['id'];
        }
        $department = Department::where('id', $departname_id)->get();
        $appraiser = Employee::where('user_id', $appraiser_id)->get();
        $country = Country::where('id', $country_id)->get();
        $state = State::where('id', $state_id)->get();
        $reviewerData = LeaveAuthority::where('user_id', $appraiser_id)->where('priority', '4')->get();
        foreach ($reviewerData as $reviewer) {
            $reviewer_id = $reviewer['manager_id'];
        }
        $performanceRecord = AppraisalPerformanceScore::where('appraisal_tracker_id', $trakerId)->get();
        $dialogue = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Appraiser')->get();
        $dialogueReviewer = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Reviewer')->get();
        $reviewerDetail = Employee::where('user_id', $reviewer_id)->get();
        return view('appraisal::appraisal.Form.appraisal_reviewer_form', compact('appraisalKra', 'employeeDetail', 'department', 'appraiser', 'country', 'state', 'reviewerDetail', 'dialogue', 'dialogueReviewer', 'performanceRecord'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function appraisalReviewerFormUpdate(Request $request)
    {
        // print_r($request->all());
        // die;
        $AppraisalTrakerId = AppraisalTracker::where('kra_id', $request->kra_id)->update([
            'projects_assigned' =>  $request->projects_assigned,
            'type' => $request->type,
            'reviewer_id'  => $request->reviewer_id,
            'final_weighted_score' => $request->final_total_weightage,
            'total_appraiser_weighted_score' => $request->appraiser_total_weightage,
            'competencies_appraiser_total' => $request->total_appraiser,
            'competencies_reviewer_total' => $request->total_reviewer,
            'total_competencies' => $request->total_competencies,
            'total_performance_score' => $request->total_performance_score,
        ]);
        $trakerId = AppraisalTracker::where('user_id', $request->employee_id)->get();
        foreach ($trakerId as $employeeTraker) {
            $employeeTrakerId = $employeeTraker->id;
        }
        $kraDetail = AppraisalEmployeeKra::where('appraisal_tracker_id', $employeeTrakerId)->get();

        foreach ($kraDetail as $i => $data) {
            $reviewerUpdate = AppraisalEmployeeKra::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $data->id)->update([
                'remark' => $request->remark[$i],
                'score_by_appraiser' => $request->score_by_appraiser[$i],
                'appraiser_weighted_score' => $request->appraiser_weighted_score[$i],
                'score_by_reviewer' => $request->score_by_reviewer[$i],
                'final_weighted_score' => $request->final_weighted[$i],
            ]);
        }
        // update reviewer comment
        $commentDetail = AppraisalComment::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($commentDetail as $i => $commentData) {
            $reviewerUpdate = AppraisalComment::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $commentData->id)->update([
                'appraiser_comment' => $request->appraiser_comment,
                'reviewer_comment' => $request->reviewer_comment,
            ]);
        }

        // update COMPETENCIES REVIEW
        $competenciesDetail = AppraisalCompetencies::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($competenciesDetail as $i => $competenciesData) {
            $reviewerUpdate = AppraisalCompetencies::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $competenciesData->id)->update([
                'appraiser' => $request->appraiser[$i],
                'reviewer' => $request->reviwer[$i],
            ]);
        }
        // update and save SPECIFIC STRENGTHS / AREAS OF IMPROVEMENT OF THE EMPLOYEE          
        $improvementDetail = AppraisalStrengthImprovement::where('appraisal_tracker_id', $employeeTrakerId)->get();
        if ($improvementDetail->count()) {
            foreach ($improvementDetail as $key => $improvementData) {
                $trakerId = $improvementData->id;
                $AppraisalUpdate = AppraisalStrengthImprovement::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $trakerId)->update([
                    'area_of_strength' => $request->area_strength[$key],
                    'area_of_improvement' => $request->area_improvement[$key],
                ]);
            }
        } else {
            foreach ($request->area_strength as $key => $compentenciesData) {
                $task = new AppraisalStrengthImprovement();
                $task->appraisal_tracker_id = $employeeTrakerId;
                $task->area_of_strength = $request->area_strength[$key];
                $task->area_of_improvement = $request->area_improvement[$key];
                $task->save();
            }
        }
        // update  and save  PERFORMANCE DIALOGUE
        $task = new AppraisalPerformanceDialogue();
        $task->appraisal_tracker_id = $employeeTrakerId;
        $task->sign_type = $request->performance_reviewer_sign;
        $task->comment = $request->performance_reviewer_comment;
        $task->save();

        // update TRAINING NEEDS IDENTIFICATION
        $TrainingDetail = AppraisalTrainingIdentification::where('appraisal_tracker_id', $employeeTrakerId)->get();
        foreach ($TrainingDetail as $i => $TrainingData) {
            $reviewerUpdate = AppraisalTrainingIdentification::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $TrainingData->id)->update([
                'recommended_by_appraiser' => $request->appraiser_msg[$i],
                'comments_by_reviewer' => $request->reviewer_comment_training[$i],
            ]);
        }

        // update  PERFORMANCE SCORE
        $trakerId = '';;
        $performanceDetail = AppraisalPerformanceScore::where('appraisal_tracker_id', $employeeTrakerId)->get();
        if ($performanceDetail->count()) {
            foreach ($performanceDetail as $i => $performanceData) {
                $trakerId = $performanceData->appraisal_tracker_id;
                $id = $performanceData->id;
                $reviewerUpdate = AppraisalPerformanceScore::where('appraisal_tracker_id', $employeeTrakerId)->where('id', $id)->update([
                    'by_appraiser' => $request->by_appraiser[$i],
                    'score' => $request->score_performance[$i],
                    'weightage' => $request->performance_weightage[$i],
                    'final' => $request->final_performance[$i],
                ]);
            }
        } else {
            foreach ($request->score_performance as $i => $performanceData) {
                $task = new AppraisalPerformanceScore();
                $task->appraisal_tracker_id = $employeeTrakerId;
                $task->by_appraiser = $request->by_appraiser[$i];
                $task->score = $request->score_performance[$i];
                $task->weightage = $request->performance_weightage[$i];
                $task->final = $request->final_performance[$i];
                $task->save();
            }
        }
        if ($reviewerUpdate) {
            return redirect()->back()->with('success', 'Data save successfull');
        } else {
            return redirect()->back()->with('unsuccess', 'Opps Something wrong!');
        }
    }

    /**
     * performanceScore 
     *
     * @param  mixed $id
     * @return void
     */
    public function performanceScore($id)
    {
        // print_r($id);
        // die;
        $employeeDetail = AppraisalTracker::where('kra_id', $id)->get();
        foreach ($employeeDetail as $empDetail) {
            $userId = $empDetail->user_id;
        }
        if ($employeeDetail->count()) {
            $employeeDetail = Employee::where('user_id', $userId)->get();
            $appraisalKra = AppraisalTracker::with('employeeKraDetail')
                ->with('appraisalCompetenciesDetail')
                ->with('appraisalTrainingDetail')
                ->with('commentDetail')
                ->with('strengthLimitationDetail')
                ->where(['kra_id' => [$id]])
                ->get()->toArray();
            foreach ($appraisalKra as $empList) {
                $country_id = $empList['country_id'];
                $state_id = $empList['state_id'];
                $departname_id = $empList['department_id'];
                $appraiser_id = $empList['appraiser_id'];
            }
            $department = Department::where('id', $departname_id)->get();
            $appraiser = Employee::where('user_id', $appraiser_id)->get();
            $country = Country::where('id', $country_id)->get();
            $state = State::where('id', $state_id)->get();
            // $checkFormStatus = AppraisalTracker::where('appraiser_id',$appraiser_id)->get()->toArray();
            $reviewerData = LeaveAuthority::where('user_id', $appraiser_id)->where('priority', '4')->get();
            foreach ($reviewerData as $reviewer) {
                $reviewer_id = $reviewer['manager_id'];
            }
            $reviewerDetail = Employee::where('user_id', $reviewer_id)->get();

            $AppraisalTrakerId = AppraisalTracker::where('kra_id', $id)->get();
            foreach ($AppraisalTrakerId as $traker_list) {
                $trakerId = $traker_list->id;
            }
            $performanceRecord = AppraisalPerformanceScore::where('appraisal_tracker_id', $trakerId)->get();
            return view('appraisal::appraisal.Form.performance_score', compact('appraisalKra', 'employeeDetail', 'department', 'appraiser', 'country', 'state', 'reviewerDetail', 'performanceRecord'));
        } else {
            return redirect('appraisal/kra-form')->with('unsuccess', 'Your Appraisal Form pending !');
        }
    }
}
