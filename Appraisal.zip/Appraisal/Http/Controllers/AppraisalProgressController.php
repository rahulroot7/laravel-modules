<?php

namespace Modules\Appraisal\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Appraisal\Entities\AppraisalEmployeeKraTemplate;
use Modules\Appraisal\Entities\AppraisalEmployeeKraDetail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Employee;
use App\Models\EmployeeProfile;
use App\Models\EmployeeAddress;
use App\Models\LeaveAuthority;
use Modules\Master\Entities\Department;
use Modules\Master\Entities\Country;
use Modules\Master\Entities\State;
use Modules\Master\Entities\Designation;
use Modules\Appraisal\Entities\AppraisalTracker;
use Modules\Appraisal\Entities\AppraisalEmployeeKra;
use Modules\Appraisal\Entities\AppraisalComment;
use Modules\Appraisal\Entities\AppraisalStrengthLimitation;
use Modules\Appraisal\Entities\AppraisalCompetencies;
use Modules\Appraisal\Entities\AppraisalTrainingIdentification;
use Modules\Appraisal\Entities\AppraisalStrengthImprovement;
use Modules\Appraisal\Entities\AppraisalPerformanceDialogue;
use Modules\Appraisal\Entities\AppraisalPerformanceScore;
use Modules\Appraisal\Entities\AppraisalRecordCompentencies;
use PDF;

class AppraisalProgressController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    /**
     * Hrprogress
     *
     * @return void
     */
    public function Hrprogress()
    {
        $userId = Auth::id();
        $appraiserList = AppraisalTracker::get();
        if ($appraiserList->count()) {
            foreach ($appraiserList as $list) {
                $employeeId = $list->user_id;
                $kraEmployee = Employee::where('user_id', $employeeId)->get();
                $kraEmployeeList[] = array(
                    "name" => $kraEmployee[0]->full_name,
                    "employee_id" => $kraEmployee[0]->employee_id,
                    "user_id" => $kraEmployee[0]->user_id,
                );
            }
            $department = Department::get();
            return view('appraisal::appraisal.Progress.progress', compact('kraEmployeeList', 'appraiserList', 'department'));
        } else {
            return redirect('appraisal/list')->with('unsuccess', 'No Response Data !');
        }
    }


    /**
     * appraisalFinalView
     *
     * @param  mixed $request
     * @param  mixed $id
     * @return void
     */
    public function appraisalFinalView(Request $request, $id)
    {
        $employeeData = AppraisalTracker::where('kra_id', $id)->get();
        foreach ($employeeData as $empDetail) {
            $userId = $empDetail->user_id;
        }
        $employeeDetail = Employee::where('user_id', $userId)->get();
        $appraisalKra = AppraisalTracker::with('employeeKraDetail')
            ->with('appraisalCompetenciesDetail')
            ->with('appraisalTrainingDetail')
            ->with('commentDetail')
            ->with('strengthLimitationDetail')
            ->with('strengthImprovementDetail')
            ->with('performanceDialogueDetail')
            ->where(['kra_id' => [$id]])
            ->get()->toArray();
        foreach ($appraisalKra as $empList) {
            $country_id = $empList['country_id'];
            $state_id = $empList['state_id'];
            $departname_id = $empList['department_id'];
            $appraiser_id = $empList['appraiser_id'];
            $trakerId = $empList['id'];
        }
        $department = Department::where('id', $departname_id)->get();
        $appraiser = Employee::where('user_id', $appraiser_id)->get();
        $country = Country::where('id', $country_id)->get();
        $state = State::where('id', $state_id)->get();
        $reviewerData = LeaveAuthority::where('user_id', $appraiser_id)->where('priority', '4')->get();
        foreach ($reviewerData as $reviewer) {
            $reviewer_id = $reviewer['manager_id'];
        }
        $performanceRecord = AppraisalPerformanceScore::where('appraisal_tracker_id', $trakerId)->get();
        $dialogue = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Appraiser')->get();
        $dialogueReviewer = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Reviewer')->get();
        $reviewerDetail = Employee::where('user_id', $reviewer_id)->get();
        return view('appraisal::appraisal.Progress.final', compact('appraisalKra', 'employeeDetail', 'department', 'appraiser', 'country', 'state', 'reviewerDetail', 'dialogue', 'dialogueReviewer', 'performanceRecord'));
    }

    /**
     * finalFilter
     *
     * @param  mixed $request
     * @return void
     */
    public function finalFilter(Request $request)
    {
        $userId = Auth::id();
        $output = "";
        $count = 0;
        $appraiserTeamplate = DB::table('appraisal_trackers')
            ->join('appraisal_employee_kra_templates', 'appraisal_employee_kra_templates.id', '=', 'appraisal_trackers.kra_id')
            ->join('employees', 'employees.user_id', '=', 'appraisal_trackers.user_id')
            ->where(['appraisal_trackers.department_id' => [$request->department]])
            ->where(['appraisal_trackers.type' => [$request->status]])
            ->where(['appraisal_employee_kra_templates.financial_year' => [$request->financial]])
            ->select('appraisal_trackers.*', 'appraisal_employee_kra_templates.*', 'employees.*')
            ->get()->toArray();
        if (isset($appraiserTeamplate)) {
            foreach ($appraiserTeamplate as $key => $kraTemplate) {
                $count++;
                $output .= '<tr>' .
                    '<td>' . $count . '</td>' .
                    '<td class="align-middle">' . $kraTemplate->employee_id . '</td>' .
                    '<td class="align-middle">' . $kraTemplate->full_name . '</td>' .
                    '<td class="align-middle">' .
                    '<div class="d-flex justify-content-between align-items-center process_bg mx-3">';
                if ($kraTemplate->type == '1') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }
                if ($kraTemplate->type == '2') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle bg-warning rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }
                if ($kraTemplate->type == '3') {
                    $output .= '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraisee</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Appraiser</span>' .
                        '</div>' .
                        '<div class="d-flex flex-column align-items-center">' .
                        '<div class="process_bar_circle steps-sucess rounded"></div>' .
                        '<span>Reveiwer</span>' .
                        '</div>';
                }

                $output .= '</div>' .
                    '</td>' .
                    '<td>' .
                    ' <div class="progress-bg">' .
                    '</div>' .
                    '<progress class="progress-bar" id="file" value="' . $kraTemplate->total_performance_score . '" max="5"></progress>' .
                    '<p class="performance-score">' . $kraTemplate->total_performance_score . '/5</p>';
                if ($kraTemplate->total_performance_score <= '1') {
                    $output .= '<b>Below Average<b><i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Below Average/Poor. Did Not meet Expectations." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '2.5' && $kraTemplate->total_performance_score >= '1.5') {
                    $output .= '<b>Average<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Average. Met expectations sometimes only. Improvement needed." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '3.5' && $kraTemplate->total_performance_score >= '2.5') {
                    $output .= ' <b>Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Good. Met expectations. Satisfactory." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '4.5' && $kraTemplate->total_performance_score >= '3.5') {
                    $output .= ' <b>Very Good<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Very Good. Exceeded expectations. Achieved greater-than-expected results." aria-hidden="true"></i>';
                } elseif ($kraTemplate->total_performance_score <= '5' && $kraTemplate->total_performance_score >= '4.5') {
                    $output .= ' <b>Outstanding<b> <i class="fa fa-info-circle" data-toggle="tooltip" data-placement="top" title="Outstanding. Excellent, setting standard for others to follow." aria-hidden="true"></i>';
                }
                $output .= '</td>';

                // '<td class="align-middle">' . $kraTemplate->financial_year . '</td>';
                // print_r($kraTemplate);
                // die;
                // filter for appraiser
                if ($kraTemplate->user_id == $kraTemplate->user_id && $kraTemplate->type == '3') {
                    $output .= '<td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('final-view', $kraTemplate->kra_id) . '">Final View</a><br><br> ' .
                        '<a class="btn btn-success" target="_blank" href="' . route('employee-performance-score', $kraTemplate->kra_id) . '">View Performance Score</a>' .
                        '</td>';
                }
                if ($kraTemplate->user_id == $kraTemplate->user_id && $kraTemplate->type == '2') {
                    $output .= '<td>' .
                        '<a class="btn btn-success" target="_blank" href="' . route('final-view', $kraTemplate->kra_id) . '">Add Review</a>' .
                        '</td>';
                }
                if ($kraTemplate->user_id == $kraTemplate->user_id && $kraTemplate->type == '1') {
                    $output .= '<td>' .
                        '<a class="btn btn-success bg-warning " href="javascript:void()">Process</a>' .
                        '</td>';
                }

                $output .= '</tr>';
            }
        }

        return $output;
    }

    public function downloadPdf($id)
    {
        $employeeData = AppraisalTracker::where('kra_id', $id)->get();
        foreach ($employeeData as $empDetail) {
            $userId = $empDetail->user_id;
        }
        $employeeDetail = Employee::where('user_id', $userId)->get();
        $appraisalKra = AppraisalTracker::with('employeeKraDetail')
            ->with('appraisalCompetenciesDetail')
            ->with('appraisalTrainingDetail')
            ->with('commentDetail')
            ->with('strengthLimitationDetail')
            ->with('strengthImprovementDetail')
            ->with('performanceDialogueDetail')
            ->where(['kra_id' => [$id]])
            ->get()->toArray();
        foreach ($appraisalKra as $empList) {
            $country_id = $empList['country_id'];
            $state_id = $empList['state_id'];
            $departname_id = $empList['department_id'];
            $appraiser_id = $empList['appraiser_id'];
            $trakerId = $empList['id'];
        }
        $department = Department::where('id', $departname_id)->get();
        $appraiser = Employee::where('user_id', $appraiser_id)->get();
        $country = Country::where('id', $country_id)->get();
        $state = State::where('id', $state_id)->get();
        $reviewerData = LeaveAuthority::where('user_id', $appraiser_id)->where('priority', '4')->get();
        foreach ($reviewerData as $reviewer) {
            $reviewer_id = $reviewer['manager_id'];
        }
        $performanceRecord = AppraisalPerformanceScore::where('appraisal_tracker_id', $trakerId)->get();
        $dialogue = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Appraiser')->get();
        $dialogueReviewer = AppraisalPerformanceDialogue::where('appraisal_tracker_id', $trakerId)->where('sign_type', 'Reviewer')->get();
        $reviewerDetail = Employee::where('user_id', $reviewer_id)->get();
        $pdf = PDF::loadView('appraisal::appraisal.Progress.final_print', [
            'appraisalKra' => $appraisalKra,
            'employeeDetail' => $employeeDetail,
            'department' => $department,
            'appraiser' => $appraiser,
            'country' => $country,
            'state' => $state,
            'reviewerDetail' => $reviewerDetail,
            'dialogue' => $dialogue,
            'dialogueReviewer' => $dialogue,
            'performanceRecord' => $dialogue

        ]);
        return $pdf->download('AppraisalForm.pdf');
    }
}
