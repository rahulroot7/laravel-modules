<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalEmployeeKrasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_employee_kras', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisal_tracker_id')->constrained();
            $table->string('kra');
            $table->float('target', 5, 2)->default('0');
            $table->float('weightage', 5, 2)->default('0');
            $table->text('achievement')->nullable();
            $table->string('remark')->nullable();
            $table->float('score_by_appraisee', 3, 2)->nullable();
            $table->float('weighted_score', 3, 2)->nullable();
            $table->float('score_by_appraiser', 3, 2)->nullable();
            $table->float('appraiser_weighted_score', 3, 2)->nullable();  
            $table->float('score_by_reviewer', 3, 2)->nullable(); 
            $table->float('final_weighted_score', 3, 2)->nullable();  
            $table->softDeletes();  
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_employee_kras');
    }
}
