<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalKraTemplateDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_kra_template_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisal_kra_template_id')->constrained();
            $table->string('name');
            $table->float('target', 5, 2);
            $table->float('weight', 5, 2);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_kra_template_details');
    }
}
