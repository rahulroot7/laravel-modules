<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalCompetenciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_competencies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisal_tracker_id')->constrained();
            $table->enum('type', ['1', '2', '3'])->comment('1- Appraisee, 2- Appraiser, 3- Reviever');
            $table->string('factors')->nullable();
            $table->float('self', 3, 2)->nullable();
            $table->float('appraiser', 3, 2)->nullable();
            $table->float('reviewer', 3, 2)->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_competencies');
    }
}
