<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalEmployeeKraDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_employee_kra_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_kra_template_id');
            $table->string('kra');
            $table->float('target', 5, 2)->default('0');
            $table->float('weightage', 5, 2)->default('0');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_employee_kra_details');
    }
}
