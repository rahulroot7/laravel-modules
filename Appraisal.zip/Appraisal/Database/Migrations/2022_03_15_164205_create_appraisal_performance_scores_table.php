<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalPerformanceScoresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_performance_scores', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisal_tracker_id')->constrained();
            $table->enum('type', ['1', '2', '3'])->comment('1- Appraisee, 2- Appraiser, 3- Reviever');
            $table->string('by_appraiser');
            $table->float('score', 3, 2);
            $table->float('weightage', 5, 2);
            $table->float('final', 3, 2);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_performance_scores');
    }
}
