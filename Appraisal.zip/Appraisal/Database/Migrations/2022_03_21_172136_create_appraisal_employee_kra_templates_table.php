<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalEmployeeKraTemplatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_employee_kra_templates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisee_id')->comment('User Id Of Employee');
            $table->foreignId('appraiser_id')->comment('Head Of Department Id');
            $table->foreignId('department_id')->constrained();
            $table->foreignId('category_id');
            $table->enum('status', ['Active', 'In Active'])->default('active');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_employee_kra_templates');
    }
}
