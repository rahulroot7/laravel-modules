<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalStrengthLimitationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_strength_limitations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisal_tracker_id')->constrained();
            $table->enum('type', ['1', '2', '3'])->comment('1- Appraisee, 2- Appraiser, 3- Reviever');
            $table->string('facilitating')->nullable();
            $table->string('hindering')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_strength_limitations');
    }
}
