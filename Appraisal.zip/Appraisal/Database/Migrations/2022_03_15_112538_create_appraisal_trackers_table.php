<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalTrackersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_trackers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade')->unique();
            $table->foreignId('department_id')->constrained();
            $table->string('appraiser_id');
            $table->string('reviewer_id')->nullable();
            $table->enum('type', ['1', '2', '3'])->comment('1- Appraisee, 2- Appraiser, 3- Reviever');
            $table->foreignId('country_id')->constrained();
            $table->foreignId('state_id')->constrained();            
            $table->string('projects_assigned')->nullable();
            $table->text('description')->comment('Description of strength limitation 2')->nullable(); //2. Describe the efforts made by your for your self-development on educational and skills front.
            $table->float('total_weightage',3, 2)->default('0');
            $table->float('total_weighted_score',3, 2)->default('0');
            $table->float('total_appraiser_weighted_score', 3, 2);
            $table->float('final_weighted_score', 3, 2);
            $table->integer('competencies_self_total');
            $table->integer('competencies_appraiser_total');
            $table->integer('competencies_reviewer_total');
            $table->float('total_competencies',3, 2);
            $table->float('total_performance_score',3, 2);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_trackers');
    }
}
