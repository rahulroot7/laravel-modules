<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAppraisalTrainingIdentificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appraisal_training_identifications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('appraisal_tracker_id')->constrained();
            $table->enum('type', ['1', '2', '3'])->comment('1- Appraisee, 2- Appraiser, 3- Reviever');
            $table->string('traning_type')->nullable();
            $table->string('suggested_by_appraisee')->nullable();
            $table->string('recommended_by_appraiser')->nullable();
            $table->string('comments_by_reviewer')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appraisal_training_identifications');
    }
}
