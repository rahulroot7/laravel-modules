<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalKraTemplate;

class AppraisalKraTemplateTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalKraTemplate::create([                   
            'user_id' => '1',
            'department_id' => '2',
            'category' => 'IT',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
