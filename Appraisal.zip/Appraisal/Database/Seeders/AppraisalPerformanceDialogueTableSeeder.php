<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalPerformanceDialogue;

class AppraisalPerformanceDialogueTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalPerformanceDialogue::create([
            'appraisal_tracker_id' => '1',
            'type' => '3', 
            'sign_type' => 'Reviewer',
            'comment' => 'god performance',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
