<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalKraTemplateDetail;

class AppraisalKraTemplateDetailTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalKraTemplateDetail::create([
            'appraisal_kra_template_id' => '1',
            'name' => 'Performance',            
            'target' => '70',
            'weight' => '4',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
