<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalRecordCompentencies;

class AppraisalRecordCompentenciesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalRecordCompentencies::truncate();
        $compentencies =  [
            [
                'name' => 'Customer Focus',
                'is_fixed' => '1',
                'band_id' => '3',
            ],
            [
                'name' => 'Initiative and Drive',
                'is_fixed' => '1',
                'band_id' => '3',
            ],
            [
                'name' => 'Cost Consciousness',
                'is_fixed' => '1',
                'band_id' => '3',
            ],
            [
                'name' => 'Inter-personal Relationship',
                'is_fixed' => '1',
                'band_id' => '3',
            ],
            [
                'name' => 'Emotional Maturity',
                'is_fixed' => '1',
                'band_id' => '3',
            ],
            [
                'name' => 'Work Planning / Time Management',
                'is_fixed' => '1',
                'band_id' => '3',
            ],
            [
                'name' => 'Customer Focus',
                'is_fixed' => '1',
                'band_id' => '1',
            ],
            [
                'name' => 'Initiative and Drive',
                'is_fixed' => '1',
                'band_id' => '1',
            ],
            [
                'name' => 'Cost Consciousness',
                'is_fixed' => '1',
                'band_id' => '1',
            ],
            [
                'name' => 'Inter-personal Relationship',
                'is_fixed' => '1',
                'band_id' => '1',
            ],
            [
                'name' => 'Emotional Maturity',
                'is_fixed' => '1',
                'band_id' => '1',
            ],
            [
                'name' => 'Work Planning / Time Management',
                'is_fixed' => '1',
                'band_id' => '1',
            ],
            [
                'name' => 'Customer Focus',
                'is_fixed' => '1',
                'band_id' => '2',
            ],
            [
                'name' => 'Initiative and Drive',
                'is_fixed' => '1',
                'band_id' => '2',
            ],
            [
                'name' => 'Cost Consciousness',
                'is_fixed' => '1',
                'band_id' => '2',
            ],
            [
                'name' => 'Inter-personal Relationship',
                'is_fixed' => '1',
                'band_id' => '2',
            ],
            [
                'name' => 'Emotional Maturity',
                'is_fixed' => '1',
                'band_id' => '2',
            ],
            [
                'name' => 'Work Planning / Time Management',
                'is_fixed' => '1',
                'band_id' => '2',
            ],
            [
                'name' => 'Customer Focus',
                'is_fixed' => '1',
                'band_id' => '4',
            ],
            [
                'name' => 'Initiative and Drive',
                'is_fixed' => '1',
                'band_id' => '4',
            ],
            [
                'name' => 'Cost Consciousness',
                'is_fixed' => '1',
                'band_id' => '4',
            ],
            [
                'name' => 'Inter-personal Relationship',
                'is_fixed' => '1',
                'band_id' => '4',
            ],
            [
                'name' => 'Emotional Maturity',
                'is_fixed' => '1',
                'band_id' => '4',
            ],
            [
                'name' => 'Work Planning / Time Management',
                'is_fixed' => '1',
                'band_id' => '4',
            ],
            [
                'name' => 'Customer Focus',
                'is_fixed' => '1',
                'band_id' => '5',
            ],
            [
                'name' => 'Initiative and Drive',
                'is_fixed' => '1',
                'band_id' => '5',
            ],
            [
                'name' => 'Cost Consciousness',
                'is_fixed' => '1',
                'band_id' => '5',
            ],
            [
                'name' => 'Inter-personal Relationship',
                'is_fixed' => '1',
                'band_id' => '5',
            ],
            [
                'name' => 'Emotional Maturity',
                'is_fixed' => '1',
                'band_id' => '5',
            ],
            [
                'name' => 'Work Planning / Time Management',
                'is_fixed' => '1',
                'band_id' => '5',
            ],
            [
                'name' => 'Customer Focus',
                'is_fixed' => '1',
                'band_id' => '6',
            ],
            [
                'name' => 'Initiative and Drive',
                'is_fixed' => '1',
                'band_id' => '6',
            ],
            [
                'name' => 'Cost Consciousness',
                'is_fixed' => '1',
                'band_id' => '6',
            ],
            [
                'name' => 'Inter-personal Relationship',
                'is_fixed' => '1',
                'band_id' => '6',
            ],
            [
                'name' => 'Emotional Maturity',
                'is_fixed' => '1',
                'band_id' => '6',
            ],
            [
                'name' => 'Work Planning / Time Management',
                'is_fixed' => '1',
                'band_id' => '6',
            ],
            [
                'name' => 'Managerial / Leadership Skills',
                'is_fixed' => '0',
                'band_id' => '5',
            ],
            [
                'name' => 'Solving Problems',
                'is_fixed' => '0',
                'band_id' => '5',
            ],
            [
                'name' => 'Planning and Reviewing Skills',
                'is_fixed' => '0',
                'band_id' => '5',
            ],
            [
                'name' => 'Result Orientation',
                'is_fixed' => '0',
                'band_id' => '5',
            ],
            [
                'name' => 'Taking Ownership',
                'is_fixed' => '0',
                'band_id' => '5',
            ],
            [
                'name' => 'Influencing Others',
                'is_fixed' => '0',
                'band_id' => '5',
            ],
            // 
            [
                'name' => 'Managerial / Leadership Skills',
                'is_fixed' => '0',
                'band_id' => '6',
            ],
            [
                'name' => 'Solving Problems',
                'is_fixed' => '0',
                'band_id' => '6',
            ],
            [
                'name' => 'Planning and Reviewing Skills',
                'is_fixed' => '0',
                'band_id' => '6',
            ],
            [
                'name' => 'Result Orientation',
                'is_fixed' => '0',
                'band_id' => '6',
            ],
            [
                'name' => 'Taking Ownership',
                'is_fixed' => '0',
                'band_id' => '6',
            ],
            [
                'name' => 'Influencing Others',
                'is_fixed' => '0',
                'band_id' => '6',
            ],
            [
                'name' => 'Managerial / Leadership Skills',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'Analyzing and Interpreting',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'People Development',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'Effective Team Building',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'Influencing Others',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'Decision Making',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'Decision Making',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Managerial / Leadership Skills',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Business & Commercial Accumen',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Planning and Reviewing Skills',
                'is_fixed' => '0',
                'band_id' => '4',
            ],
            [
                'name' => 'Planning and Reviewing Skills',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Stragetic Thinking',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Leadership Development',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Decision Making',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Effective Team Building',
                'is_fixed' => '0',
                'band_id' => '3',
            ],
            [
                'name' => 'Planning and Reviewing Skills',
                'is_fixed' => '0',
                'band_id' => '2',
            ],
            [
                'name' => 'Stragetic Thinking',
                'is_fixed' => '0',
                'band_id' => '2',
            ],
            [
                'name' => 'Leadership Development',
                'is_fixed' => '0',
                'band_id' => '2',
            ],
            [
                'name' => 'Decision Making',
                'is_fixed' => '0',
                'band_id' => '2',
            ],
            [
                'name' => 'Effective Team Building',
                'is_fixed' => '0',
                'band_id' => '2',
            ],
            [
                'name' => 'Planning and Reviewing Skills',
                'is_fixed' => '0',
                'band_id' => '1',
            ],
            [
                'name' => 'Stragetic Thinking',
                'is_fixed' => '0',
                'band_id' => '1',
            ],
            [
                'name' => 'Leadership Development',
                'is_fixed' => '0',
                'band_id' => '1',
            ],
            [
                'name' => 'Decision Making',
                'is_fixed' => '0',
                'band_id' => '1',
            ],
            [
                'name' => 'Effective Team Building',
                'is_fixed' => '0',
                'band_id' => '1',
            ]

        ];
        foreach ($compentencies as $record) {
            AppraisalRecordCompentencies::create($record);
        }
        // $this->call("OthersTableSeeder");
    }
}
