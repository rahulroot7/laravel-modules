<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalTrainingIdentification;

class AppraisalTrainingIdentificationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalTrainingIdentification::create([
            'appraisal_tracker_id' => '1',
            'type' => '1',
            'traning_type' => 'Behavioural',
            'suggested_by_appraisee' => 'Appraisal training identification',
            'recommended_by_appraiser' => 'good',
            'comments_by_reviewer' => 'Good',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
