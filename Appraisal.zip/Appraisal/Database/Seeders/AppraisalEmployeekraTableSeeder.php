<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalEmployeeKra;

class AppraisalEmployeekraTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalEmployeeKra::create([
            'appraisal_tracker_id' => '1',
            'kra' => 'Data Management',            
            'target' => '35.4',
            'weightage' => '75.99',
            'achievement' => '5',
            'remark' => '5',
            'score_by_appraisee' => '5',
            'weighted_score' => '4',
            'score_by_appraiser' => '3',
            'appraiser_weighted_score' => '1.2',
            'score_by_reviewer' => '3.6',
            'final_weighted_score' => '0.32',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
