<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class AppraisalDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        // $this->call("OthersTableSeeder");
        $this->call(AppraisalKraTemplateTableSeeder::class);
        $this->call(AppraisalKraTemplateDetailTableSeeder::class);
        $this->call(AppraisalTrackerTableSeeder::class);
        $this->call(AppraisalEmployeekraTableSeeder::class);
        $this->call(AppraisalCommentTableSeeder::class);
        $this->call(AppraisalPerformanceDialogueTableSeeder::class);
        $this->call(AppraisalStrengthImprovementTableSeeder::class);
        $this->call(AppraisalStrengthLimitationTableSeeder::class);
        $this->call(AppraisalTrainingIdentificationTableSeeder::class);
        $this->call(AppraisalTrainingIdentificationTableSeeder::class);
        $this->call(AppraisalRecordCompentenciesTableSeeder::class);
        $this->call(AppraisalCompentenciesBandTableSeeder::class);
    }
}
