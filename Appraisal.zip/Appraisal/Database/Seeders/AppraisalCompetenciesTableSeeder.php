<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalCompetencies;

class AppraisalCompetenciesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalCompetencies::create([
            'appraisal_tracker_id' => '1',
            'factors' => 'Customer Focus',            
            'self' => '5',
            'appraiser' => '4',
            'reviewer' => '3',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
