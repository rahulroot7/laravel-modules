<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalPerformanceScore;

class AppraisalPerformanceScoreTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalPerformanceScore::create([
            'appraisal_tracker_id' => '1',
            'by_appraiser' => 'Performance Evaluation(From SECTION 1)',            
            'score' => '5',
            'weightage' => '4',
            'final' => '2.5',
        ]);

        // $this->call("OthersTableSeeder");
    }
}
