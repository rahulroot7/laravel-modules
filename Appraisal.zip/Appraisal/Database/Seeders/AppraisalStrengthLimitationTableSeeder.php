<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalStrengthLimitation;

class AppraisalStrengthLimitationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalStrengthLimitation::create([
            'appraisal_tracker_id' => '1',
            'type' => '1',            
            'facilitating' => 'Facilitating',
            'hindering' => 'Hindering',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
