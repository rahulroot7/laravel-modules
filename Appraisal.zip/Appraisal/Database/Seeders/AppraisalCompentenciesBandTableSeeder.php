<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalCompentenciesBand;

class AppraisalCompentenciesBandTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        AppraisalCompentenciesBand::truncate();
        $band =  [
            [
                'appraisal_record_compentencies_id' => '1',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '2',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '3',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '5',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '6',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '1',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '2',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '3',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '5',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '6',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '1',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '2',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '3',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '5',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '6',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '1',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '2',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '3',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '5',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '6',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '1',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '2',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '3',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '5',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '6',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '1',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '2',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '3',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '5',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '6',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '7',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '8',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '9',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '10',
                'band_id' => '6',
            ],
            [
                'appraisal_record_compentencies_id' => '11',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '12',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '13',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '14',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '15',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '16',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '17',
                'band_id' => '5',
            ],
            [
                'appraisal_record_compentencies_id' => '17',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '13',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '18',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '19',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '20',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '21',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '22',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '4',
                'band_id' => '4',
            ],
            [
                'appraisal_record_compentencies_id' => '17',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '13',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '24',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '22',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '26',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '27',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '29',
                'band_id' => '3',
            ],
            [
                'appraisal_record_compentencies_id' => '17',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '13',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '24',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '22',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '26',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '27',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '29',
                'band_id' => '2',
            ],
            [
                'appraisal_record_compentencies_id' => '17',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '13',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '24',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '22',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '26',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '27',
                'band_id' => '1',
            ],
            [
                'appraisal_record_compentencies_id' => '29',
                'band_id' => '1',
            ]


        ];
        foreach ($band as $record) {
            AppraisalCompentenciesBand::create($record);
        }

        // $this->call("OthersTableSeeder");
    }
}
