<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalTracker;

class AppraisalTrackerTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalTracker::create([
            'user_id' => '18778',
            'department_id' => '2',            
            'appraiser_id' => '106',
            'reviewer_id' => '1',
            'type' => '1',
            'country_id' => '1',
            'state_id' => '1',
            'projects_assigned' => 'demo',
            'description' => 'text.....',
            'total_weightage' => '5',
            'total_weighted_score' => '5',
            'total_appraiser_weighted_score' => '5',
            'final_weighted_score' => '5',
            'competencies_self_total' => '5',
            'competencies_appraiser_total' => '5',
            'total_competencies' => '5',
            'total_performance_score' => '5',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
