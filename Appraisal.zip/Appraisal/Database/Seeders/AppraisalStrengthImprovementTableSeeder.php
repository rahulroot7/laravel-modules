<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalStrengthImprovement;

class AppraisalStrengthImprovementTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalStrengthImprovement::create([
            'appraisal_tracker_id' => '1',
            'type' => '1',            
            'area_of_strength' => 'Area Of strength',
            'area_of_improvement' => 'Area Of Improvement',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
