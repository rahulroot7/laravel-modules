<?php

namespace Modules\Appraisal\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Modules\Appraisal\Entities\AppraisalComment;

class AppraisalCommentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();
        AppraisalComment::create([
            'appraisal_tracker_id' => '1',
            'user_id' => '1',            
            'comment' => 'excellent',
            'appraiser_comment' => 'very good',
            'reviewer_comment' => 'good',
        ]);
        // $this->call("OthersTableSeeder");
    }
}
