<?php

return [
    'name' => 'Appraisal',

    'projectId' => ['1', '2', '18', '19', '121']
];
